﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Teradata.Client.Provider;
using System.IO;

namespace CreateNorthwind
{
    public class LoadBlobs
    {
        public static void StartLoad(TdConnection conn, String lobPath)
        {
            TdCommand cmd = conn.CreateCommand();

            LoadCategoryPictureBlob(cmd, lobPath);

            LoadEmployeePhotoBlob(cmd, lobPath);

            LoadPreviousEmployeePhotoBlob(cmd, lobPath);

            cmd.Dispose();
        }

        static public void LoadCategoryPictureBlob(TdCommand cmd, String dataPath)
        {
            cmd.Parameters.Clear();

            cmd.CommandText = "update Categories set picture = ?";
            cmd.Parameters.Add(null, TdType.Blob, 20 * 1024);

            // executable is in tdnetdp\nt-i386\debug
            FileStream fs = new FileStream(dataPath + @"CategoryPicture.dat", FileMode.Open, FileAccess.Read);

            cmd.Parameters[0].Value = fs;
            cmd.ExecuteNonQuery();

            fs.Close();
        }

        static void LoadEmployeePhotoBlob(TdCommand cmd, String dataPath)
        {
            FileStream fs;

            cmd.Parameters.Clear();
            cmd.CommandText = "update Employees set photo = ? where employeeid = ?";

            cmd.Parameters.Add(null, TdType.Blob, 100 * 1024);
            cmd.Parameters.Add(null, TdType.Integer);

            String filename;
            Int32[] employeeList = { 1, 2, 3, 4, 5, 6, 8, 9 };
            foreach (Int32 id in employeeList)
            {
                filename = String.Format(dataPath + @"PhotoEmployeeId{0}.dat", id);
                fs = new FileStream(filename, FileMode.Open, FileAccess.Read);

                cmd.Parameters[0].Value = fs;
                cmd.Parameters[1].Value = id;

                cmd.ExecuteNonQuery();
            }
        }

        static void LoadPreviousEmployeePhotoBlob(TdCommand cmd, String dataPath)
        {
            FileStream fs;

            cmd.Parameters.Clear();
            cmd.CommandText = "update PreviousEmployees set photo = ? where employeeid = ?";

            cmd.Parameters.Add(null, TdType.Blob, 50 * 1024);
            cmd.Parameters.Add(null, TdType.Integer);

            String filename;
            Int32[] employeeList = { 7 };
            foreach (Int32 id in employeeList)
            {
                filename = String.Format(dataPath + @"PhotoPreviousEmployeeId{0}.dat", id);
                fs = new FileStream(filename, FileMode.Open, FileAccess.Read);

                cmd.Parameters[0].Value = fs;
                cmd.Parameters[1].Value = id;

                cmd.ExecuteNonQuery();
            }
        }
    }
}
