﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

using Teradata.Client.Provider;

namespace CreateNorthwind
{
    /// <summary>
    /// ConfigFile operates on the Unit Test configuration file. 
    /// </summary>
    internal class ConfigFile
    {
        /// <summary>
        /// Reads the General Unit Test Configuration settings like User Id, Data Source
        /// and password from the file and transfers the information to a 
        /// TdConnectionStringBuilder class.
        /// </summary>
        /// 
        /// <remarks>
        /// Unit tests can add additional attributes to the TdConnectionStringBuilder class and
        /// later retrieve the ConnectionString property. 
        /// </remarks>
        /// <summary  date="11-17-2008" uid="vk185038">
        /// Modified method to get the value for the Session character set from the Config file
        /// </summary>
        public static TdConnectionStringBuilder ConnectionStringBuilder
        {
            get
            {
                TdConnectionStringBuilder conStrBuilder = new TdConnectionStringBuilder();
                conStrBuilder.PersistSecurityInfo = true;

                // GEN_USER_ID, GEN_PASSWORD, and GEN_DATA_SOURCE are required
                conStrBuilder.UserId = ConfigFile.GetRequiredKey(@"GEN_USER_ID");
                conStrBuilder.Password = ConfigFile.GetRequiredKey(@"GEN_PASSWORD");
                conStrBuilder.DataSource = ConfigFile.GetRequiredKey(@"GEN_DATA_SOURCE");

                // GEN_SESSION_MODE is optional
                String sessionMode = ConfigurationManager.AppSettings.Get(@"GEN_SESSION_MODE");
                if (null != sessionMode)
                {
                    conStrBuilder.SessionMode = sessionMode;
                }

                // GEN_SESSION_CHARACTER_SET is optional
                String sessionCharacterSet = ConfigurationManager.AppSettings.Get(@"GEN_SESSION_CHARACTER_SET");
                if (null != sessionCharacterSet)
                {
                    conStrBuilder.SessionCharacterSet = sessionCharacterSet;
                }

                // GEN_DATA_ENCRYPTION is optional
                String dataEncryption = ConfigurationManager.AppSettings.Get(@"GEN_DATA_ENCRYPTION");
                if (dataEncryption != null && dataEncryption.ToUpper() == "TRUE")
                {
                    conStrBuilder.DataEncryption = true;
                }

                // GEN_DATA_INTEGRITY is optional
                String dataIntegrity = ConfigurationManager.AppSettings.Get(@"GEN_DATA_INTEGRITY");
                if (dataIntegrity != null && dataIntegrity.ToUpper() == "TRUE")
                {
                    conStrBuilder.DataIntegrity = true;
                }

                // GEN_AUTH_MECH is optional
                String authMech = ConfigurationManager.AppSettings.Get(@"GEN_AUTH_MECH");
                if (authMech != null)
                {
                    conStrBuilder.AuthenticationMechanism = authMech;
                }

                // GEN_USE_ENHANCED_SCHEMA_TABLE is optional
                String useEnhancedSchemaTable = ConfigurationManager.AppSettings.Get(@"GEN_USE_ENHANCED_SCHEMA_TABLE");
                if (String.IsNullOrEmpty(useEnhancedSchemaTable) == false)
                {
                    conStrBuilder.UseEnhancedSchemaTable = Convert.ToBoolean(useEnhancedSchemaTable);
                }

                return (conStrBuilder);
            }
        }

        /// <summary>
        /// Gets a required value for a configKey. If the key is not found or is empty, 
        /// an ArgumentNullException exception is thrown.
        /// </summary>
        /// <param name="configKey">The config key to retrieve</param>
        /// <returns>The value defined for the key </returns>
        public static String GetRequiredKey(String configKey)
        {
            String value = ConfigurationManager.AppSettings.Get(configKey);
            if (String.IsNullOrEmpty(value))
            {
                String msg = String.Format(@"Cannot find {0} in unit test configuration file.", configKey);
                throw new ArgumentNullException(msg, ( Exception )null);
            }
            return value;
        }

        /// <summary>
        /// Gets an optional value for a configKey. If the key is not found the value supplied
        /// as defaultValue is returned.  This provides a simple method to set a value in
        /// a unit test file based on whether or not the app key has been defined:
        /// String myOption = ConfigFile.GetOptionalKey("DATASOURCE", "dbc");
        /// </summary>
        /// <param name="configKey">The key to look for</param>
        /// <param name="defaultValue">The default value to return if the key is not found</param>
        /// <returns>The value of configKey or defaultValue</returns>
        public static String GetOptionalKey(String configKey, String defaultValue)
        {
            String value = ConfigurationManager.AppSettings.Get(configKey);
            if (String.IsNullOrEmpty(value))
            {
                value = defaultValue;
            }
            return value;
        }
    }
}
