﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;

using Teradata.Client.Provider;

namespace CreateNorthwind
{
    class Program
    {

        static void Main(string[] args)
        {

            TdConnectionStringBuilder tbuilder = ConfigFile.ConnectionStringBuilder;
            TdConnection conn = new TdConnection(tbuilder.ToString());

            String lobPath = ConfigFile.GetOptionalKey("LOB_DATA", String.Empty);
            if (String.IsNullOrEmpty(lobPath) == true)
            {
                lobPath = @"..\..\data\";
            }

            conn.Open();

            TdCommand cmd = conn.CreateCommand();

            Northwind.CreateDatabase(cmd);

            Northwind.LoadData(cmd);

            cmd.Dispose();

            LoadBlobs.StartLoad(conn, lobPath);

            conn.Close();
        }


    }

    public class Northwind
    {

        public static void CreateDatabase(TdCommand cmd )
        {
            cmd.CommandText = "CREATE TABLE Shippers (" +
	                           "ShipperID INTEGER NOT NULL Generated Always As Identity (Start with 1 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle)," +
	                           "CompanyName VARCHAR (40) NOT NULL ," +
	                           "Phone VARCHAR (24) NULL," +
	                           "CONSTRAINT PK_Shippers PRIMARY KEY (ShipperID)) ";

            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Categories (" +
	                           "CategoryID INTEGER NOT NULL Generated Always As Identity (Start with 1 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle), " +
	                           "CategoryName VARCHAR(15) NOT NULL , " +
                               " Description CLOB, Picture BLOB, " +
                               "CONSTRAINT PK_Categories PRIMARY KEY (CategoryID) ) ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  CategoryName (CategoryName) ON  Categories";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Customers (	CustomerID VARCHAR(5) NOT NULL , " +
	                           "CompanyName VARCHAR(40) NOT NULL , ContactName VARCHAR(30), " +
	                           "ContactTitle VARCHAR(30), Address VARCHAR(60), City VARCHAR(32), " +
                               "Region VARCHAR(15), PostalCode VARCHAR(10), Country VARCHAR(15), " +
	                           "Phone VARCHAR(24), Fax VARCHAR(24), " +
	                           "CONSTRAINT PK_Customers PRIMARY KEY (CustomerID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  City (City) ON  Customers ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  CompanyName (CompanyName) ON  Customers";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  PostalCode (PostalCode) ON  Customers";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  Region (Region) ON  Customers";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Employees ( " +
	                           "EmployeeID INTEGER NOT NULL Generated Always As Identity (Start with 1 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle), " +
	                           "LastName VARCHAR(20) NOT NULL , FirstName VARCHAR(10) NOT NULL , " +
	                           "\"Title\" VARCHAR(30), TitleOfCourtesy VARCHAR(25), BirthDate DATE, " +
	                           "HireDate DATE, Address VARCHAR(60), City VARCHAR(15), Region VARCHAR(15), " +
	                           "PostalCode VARCHAR(10), Country VARCHAR(15), HomePhone VARCHAR(24), Extension VARCHAR(4), " +
	                           "Photo BLOB, Notes CLOB, PhotoPath VARCHAR(255), " +
                               "CONSTRAINT PK_Employees PRIMARY KEY (EmployeeID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  LastName (LastName) ON  Employees";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  PostalCode00000 (PostalCode) ON  Employees";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Orders ( " +
	                           "OrderID INTEGER NOT NULL Generated Always As Identity (Start with 10248 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle), " +
	                           "CustomerID VARCHAR(5), EmployeeID INTEGER, OrderDate TIMESTAMP(6), " +
	                           "RequiredDate TIMESTAMP(3),ShippedDate DATE, ShipVia INTEGER REFERENCES Shippers(ShipperID), " +
                               "Freight DECIMAL(19,4) DEFAULT 0, ShipName VARCHAR(40), ShipAddress VARCHAR(60), " +
	                           "ShipCity VARCHAR(32), ShipRegion VARCHAR(15), ShipPostalCode VARCHAR(10), " +
	                           "ShipCountry VARCHAR(15), CONSTRAINT PK_Orders PRIMARY KEY (OrderID) , " +
	                           "FOREIGN KEY (CustomerID) REFERENCES  Customers (CustomerID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  CustomerID (CustomerID) ON  Orders";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  EmployeeID (EmployeeID) ON  Orders ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  OrderDate (OrderDate) ON  Orders ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  ShipPostalCode (ShipPostalCode) ON  Orders ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  ShippedDate (ShippedDate) ON  Orders ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  PreviousEmployees (	" +
	                           "EmployeeID INTEGER NOT NULL , LastName VARCHAR(20) NOT NULL , " +
	                           "FirstName VARCHAR(10) NOT NULL , \"Title\" VARCHAR(30), TitleOfCourtesy VARCHAR(25), " +
	                           "BirthDate DATE, HireDate DATE, Address VARCHAR(60), City VARCHAR(32), " +
	                           "Region VARCHAR(15), PostalCode VARCHAR(10), Country VARCHAR(32), " +
	                           "HomePhone VARCHAR(24), Extension VARCHAR(4), Photo BLOB, " +
	                           "Notes CLOB, PhotoPath VARCHAR(255), " +
	                           "CONSTRAINT PK_PreviousEmployees PRIMARY KEY (EmployeeID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Suppliers (" +
	                           "SupplierID INTEGER NOT NULL Generated Always As Identity (Start with 1 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle)," +
                               "CompanyName VARCHAR(40) NOT NULL , ContactName VARCHAR(30), ContactTitle VARCHAR(30), " +
	                           "Address VARCHAR(60), City VARCHAR(15), Region VARCHAR(15), " +
	                           "PostalCode VARCHAR(10), Country VARCHAR(15), Phone VARCHAR(24), " +
	                           "Fax VARCHAR(24), HomePage CLOB, " +
	                           "CONSTRAINT PK_Suppliers PRIMARY KEY (SupplierID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  CompanyName00000 (CompanyName) ON  Suppliers ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  PostalCode00001 (PostalCode) ON  Suppliers ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Products (" +
	                           "ProductID INTEGER NOT NULL Generated Always As Identity (Start with 1 Increment by 1 MinValue 1 MaxValue 2147483647 No Cycle)," +
	                           "ProductName VARCHAR(40) NOT NULL , SupplierID INTEGER, CategoryID INTEGER, " +
	                           "QuantityPerUnit VARCHAR(20), UnitPrice DECIMAL(19, 4) DEFAULT 0, " +
	                           "UnitsInStock SMALLINT DEFAULT 0, UnitsOnOrder SMALLINT DEFAULT 0, ReorderLevel SMALLINT DEFAULT 0, " +
	                           "Discontinued BYTEINT DEFAULT 0 NOT NULL , DiscontinuedDate TIMESTAMP, " +
	                           "CONSTRAINT PK_Products PRIMARY KEY (ProductID) , " +
	                           "FOREIGN KEY (CategoryID) REFERENCES  Categories (CategoryID) , " +
	                           "FOREIGN KEY (SupplierID) REFERENCES  Suppliers (SupplierID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  CategoriesProducts (CategoryID)ON  Products ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  ProductName (ProductName) ON  Products ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  SupplierID (SupplierID) ON  Products ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Regions (	" +
	                           "RegionID INTEGER NOT NULL , RegionDescription VARCHAR(50) NOT NULL , " +
	                           "CONSTRAINT PK_Region PRIMARY KEY (RegionID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  Territories (	TerritoryID INTEGER NOT NULL , " +
	                           "TerritoryDescription VARCHAR(50) NOT NULL , RegionID INTEGER NOT NULL , " +
	                           "CONSTRAINT PK_Territories PRIMARY KEY (TerritoryID) , " +
	                           "FOREIGN KEY (RegionID) REFERENCES  Regions (RegionID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  OrderDetails (	OrderID INTEGER NOT NULL , " +
	                           "ProductID INTEGER NOT NULL , UnitPrice DECIMAL(19,4) DEFAULT 0 NOT NULL , " +
	                           "Quantity SMALLINT DEFAULT 1 NOT NULL , Discount FLOAT NOT NULL , " +
	                           "CONSTRAINT PK_Order_Details PRIMARY KEY (OrderID, ProductID) , " +
	                           "FOREIGN KEY (OrderID) REFERENCES  Orders (OrderID) , " +
	                           "FOREIGN KEY (ProductID) REFERENCES  Products (ProductID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  OrderID (OrderID) ON  OrderDetails ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE INDEX  ProductID (ProductID) ON  OrderDetails ";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE TABLE  EmployeesTerritories (	EmployeeID INTEGER NOT NULL , " +
	                           "TerritoryID INTEGER NOT NULL , CONSTRAINT PK_EmployeeTerritories PRIMARY KEY (EmployeeID, TerritoryID) , " +
	                           "FOREIGN KEY (EmployeeID) REFERENCES  Employees (EmployeeID) , " +
	                           "FOREIGN KEY (TerritoryID) REFERENCES  Territories (TerritoryID) )";
            cmd.ExecuteNonQuery();


            cmd.CommandText = "CREATE TABLE  InternationalOrders (	" +
	                           "OrderID INTEGER NOT NULL , CustomsDescription VARCHAR(100) NOT NULL , " +
	                           "ExciseTax DECIMAL(19, 4) NOT NULL , CONSTRAINT PK_InternationalOrders PRIMARY KEY (OrderID) , " +
	                           "FOREIGN KEY (OrderID) REFERENCES  Orders (OrderID) )";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "CREATE VIEW RegionsView AS SELECT * FROM Regions WITH CHECK OPTION";
            cmd.ExecuteNonQuery();
        }

        static public void LoadData( TdCommand cmd)
        {
            LoadRegions(cmd);
            LoadTerritories(cmd);
            LoadSupliers(cmd);
            LoadCategories(cmd);
            LoadShippers(cmd);
            LoadCustomers(cmd);
            LoadOrders(cmd);
            LoadProducts(cmd);
            LoadOrderDetails(cmd);
            LoadInternationalOrders(cmd);

        }


        static private void LoadOrders(TdCommand cmd)
        {
            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VINET',5,TIMESTAMP '1996-07-04 00:00:00',TIMESTAMP '1996-08-01 00:00:00',DATE '1996-07-16',3,32.38,'Vins et alcools Chevalier', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',6,TIMESTAMP '1996-07-05 00:00:00',TIMESTAMP '1996-08-16 00:00:00',DATE '1996-07-10',1,11.61,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',4,TIMESTAMP '1996-07-08 00:00:00',TIMESTAMP '1996-08-05 00:00:00',DATE '1996-07-12',2,65.83,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',3,TIMESTAMP '1996-07-08 00:00:00',TIMESTAMP '1996-08-05 00:00:00',DATE '1996-07-15',1,41.34,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',4,TIMESTAMP '1996-07-09 00:00:00',TIMESTAMP '1996-08-06 00:00:00',DATE '1996-07-11',2,51.30,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',3,TIMESTAMP '1996-07-10 00:00:00',TIMESTAMP '1996-07-24 00:00:00',DATE '1996-07-16',2,58.17,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',5,TIMESTAMP '1996-07-11 00:00:00',TIMESTAMP '1996-08-08 00:00:00',DATE '1996-07-23',2,22.98,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',9,TIMESTAMP '1996-07-12 00:00:00',TIMESTAMP '1996-08-09 00:00:00',DATE '1996-07-15',3,148.33,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',3,TIMESTAMP '1996-07-15 00:00:00',TIMESTAMP '1996-08-12 00:00:00',DATE '1996-07-17',2,13.97,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',4,TIMESTAMP '1996-07-16 00:00:00',TIMESTAMP '1996-08-13 00:00:00',DATE '1996-07-22',3,81.91,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',1,TIMESTAMP '1996-07-17 00:00:00',TIMESTAMP '1996-08-14 00:00:00',DATE '1996-07-23',1,140.51,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CENTC',4,TIMESTAMP '1996-07-18 00:00:00',TIMESTAMP '1996-08-15 00:00:00',DATE '1996-07-25',3,3.25,'Centro comercial Moctezuma', 'Sierras de Granada 9993', 'México D.F.',NULL,'05022', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',4,TIMESTAMP '1996-07-19 00:00:00',TIMESTAMP '1996-08-16 00:00:00',DATE '1996-07-29',1,55.09,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',4,TIMESTAMP '1996-07-19 00:00:00',TIMESTAMP '1996-08-16 00:00:00',DATE '1996-07-30',2,3.05,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',8,TIMESTAMP '1996-07-22 00:00:00',TIMESTAMP '1996-08-19 00:00:00',DATE '1996-07-25',3,48.29,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',9,TIMESTAMP '1996-07-23 00:00:00',TIMESTAMP '1996-08-20 00:00:00',DATE '1996-07-31',3,146.06,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',6,TIMESTAMP '1996-07-24 00:00:00',TIMESTAMP '1996-08-21 00:00:00',DATE '1996-08-23',3,3.67,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',2,TIMESTAMP '1996-07-25 00:00:00',TIMESTAMP '1996-08-22 00:00:00',DATE '1996-08-12',1,55.28,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',3,TIMESTAMP '1996-07-26 00:00:00',TIMESTAMP '1996-09-06 00:00:00',DATE '1996-07-31',3,25.73,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',4,TIMESTAMP '1996-07-29 00:00:00',TIMESTAMP '1996-08-26 00:00:00',DATE '1996-08-06',1,208.58,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GROSR',8,TIMESTAMP '1996-07-30 00:00:00',TIMESTAMP '1996-08-27 00:00:00',DATE '1996-08-02',3,66.29,'GROSELLA-Restaurante', '5ª Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',5,TIMESTAMP '1996-07-31 00:00:00',TIMESTAMP '1996-08-14 00:00:00',DATE '1996-08-09',1,4.56,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',1,TIMESTAMP '1996-08-01 00:00:00',TIMESTAMP '1996-08-29 00:00:00',DATE '1996-08-02',1,136.54,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',6,TIMESTAMP '1996-08-01 00:00:00',TIMESTAMP '1996-08-29 00:00:00',DATE '1996-08-30',2,4.54,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',6,TIMESTAMP '1996-08-02 00:00:00',TIMESTAMP '1996-08-30 00:00:00',DATE '1996-08-06',2,98.03,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',3,TIMESTAMP '1996-08-05 00:00:00',TIMESTAMP '1996-09-02 00:00:00',DATE '1996-08-12',3,76.07,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VINET',6,TIMESTAMP '1996-08-06 00:00:00',TIMESTAMP '1996-09-03 00:00:00',DATE '1996-08-16',1,6.01,'Vins et alcools Chevalier', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',1,TIMESTAMP '1996-08-07 00:00:00',TIMESTAMP '1996-09-04 00:00:00',DATE '1996-08-09',1,26.93,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',8,TIMESTAMP '1996-08-08 00:00:00',TIMESTAMP '1996-08-22 00:00:00',DATE '1996-08-14',3,13.84,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MORGK',2,TIMESTAMP '1996-08-09 00:00:00',TIMESTAMP '1996-09-06 00:00:00',DATE '1996-08-13',3,125.77,'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',8,TIMESTAMP '1996-08-12 00:00:00',TIMESTAMP '1996-09-09 00:00:00',DATE '1996-08-16',2,92.69,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',8,TIMESTAMP '1996-08-13 00:00:00',TIMESTAMP '1996-09-10 00:00:00',DATE '1996-08-16',2,25.83,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',2,TIMESTAMP '1996-08-14 00:00:00',TIMESTAMP '1996-09-11 00:00:00',DATE '1996-09-12',1,8.98,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ROMEY',4,TIMESTAMP '1996-08-14 00:00:00',TIMESTAMP '1996-08-28 00:00:00',DATE '1996-08-21',1,2.94,'Romero y tomillo', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ROMEY',4,TIMESTAMP '1996-08-15 00:00:00',TIMESTAMP '1996-09-12 00:00:00',DATE '1996-08-21',1,12.69,'Romero y tomillo', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',3,TIMESTAMP '1996-08-16 00:00:00',TIMESTAMP '1996-09-13 00:00:00',DATE '1996-08-23',3,84.81,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',4,TIMESTAMP '1996-08-19 00:00:00',TIMESTAMP '1996-09-16 00:00:00',DATE '1996-08-27',1,76.56,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',1,TIMESTAMP '1996-08-20 00:00:00',TIMESTAMP '1996-09-17 00:00:00',DATE '1996-08-26',2,76.83,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',8,TIMESTAMP '1996-08-21 00:00:00',TIMESTAMP '1996-09-18 00:00:00',DATE '1996-08-30',3,229.24,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',8,TIMESTAMP '1996-08-22 00:00:00',TIMESTAMP '1996-09-19 00:00:00',DATE '1996-08-28',3,12.76,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',4,TIMESTAMP '1996-08-23 00:00:00',TIMESTAMP '1996-09-20 00:00:00',DATE '1996-09-03',1,7.45,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',7,TIMESTAMP '1996-08-26 00:00:00',TIMESTAMP '1996-09-23 00:00:00',DATE '1996-08-28',3,22.77,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('COMMI',8,TIMESTAMP '1996-08-27 00:00:00',TIMESTAMP '1996-09-24 00:00:00',DATE '1996-09-03',1,79.70,'Comércio Mineiro', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',6,TIMESTAMP '1996-08-27 00:00:00',TIMESTAMP '1996-09-24 00:00:00',DATE '1996-09-04',2,6.40,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',1,TIMESTAMP '1996-08-28 00:00:00',TIMESTAMP '1996-09-25 00:00:00',DATE '1996-09-02',2,1.35,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',1,TIMESTAMP '1996-08-29 00:00:00',TIMESTAMP '1996-09-26 00:00:00',DATE '1996-09-11',3,21.18,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',4,TIMESTAMP '1996-08-30 00:00:00',TIMESTAMP '1996-09-27 00:00:00',DATE '1996-09-05',2,147.26,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VINET',2,TIMESTAMP '1996-09-02 00:00:00',TIMESTAMP '1996-09-30 00:00:00',DATE '1996-09-10',2,1.15,'Vins et alcools Chevalier', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',6,TIMESTAMP '1996-09-03 00:00:00',TIMESTAMP '1996-10-01 00:00:00',DATE '1996-09-11',1,0.12,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',5,TIMESTAMP '1996-09-04 00:00:00',TIMESTAMP '1996-10-16 00:00:00',DATE '1996-09-10',2,5.74,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',6,TIMESTAMP '1996-09-05 00:00:00',TIMESTAMP '1996-10-03 00:00:00',DATE '1996-09-11',2,168.22,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',4,TIMESTAMP '1996-09-06 00:00:00',TIMESTAMP '1996-10-04 00:00:00',DATE '1996-09-13',2,29.76,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',2,TIMESTAMP '1996-09-09 00:00:00',TIMESTAMP '1996-10-07 00:00:00',DATE '1996-09-18',2,17.68,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',8,TIMESTAMP '1996-09-09 00:00:00',TIMESTAMP '1996-10-07 00:00:00',DATE '1996-09-17',2,45.08,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',4,TIMESTAMP '1996-09-10 00:00:00',TIMESTAMP '1996-10-08 00:00:00',DATE '1996-10-09',2,6.27,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',7,TIMESTAMP '1996-09-11 00:00:00',TIMESTAMP '1996-10-09 00:00:00',DATE '1996-09-18',2,107.83,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',1,TIMESTAMP '1996-09-12 00:00:00',TIMESTAMP '1996-10-10 00:00:00',DATE '1996-09-17',2,63.79,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',8,TIMESTAMP '1996-09-13 00:00:00',TIMESTAMP '1996-10-11 00:00:00',DATE '1996-10-09',3,257.62,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ROMEY',1,TIMESTAMP '1996-09-16 00:00:00',TIMESTAMP '1996-10-14 00:00:00',DATE '1996-09-23',3,7.56,'Romero y tomillo', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',2,TIMESTAMP '1996-09-17 00:00:00',TIMESTAMP '1996-10-15 00:00:00',DATE '1996-09-25',2,0.56,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANATR',7,TIMESTAMP '1996-09-18 00:00:00',TIMESTAMP '1996-10-16 00:00:00',DATE '1996-09-24',3,1.61,'Ana Trujillo Emparedados y helados', 'Avda. de la Constitución 2222', 'México D.F.',NULL,'05021', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',3,TIMESTAMP '1996-09-19 00:00:00',TIMESTAMP '1996-10-17 00:00:00',DATE '1996-10-23',1,47.30,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THEBI',8,TIMESTAMP '1996-09-20 00:00:00',TIMESTAMP '1996-10-18 00:00:00',DATE '1996-09-27',2,17.52,'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DUMON',1,TIMESTAMP '1996-09-20 00:00:00',TIMESTAMP '1996-10-04 00:00:00',DATE '1996-09-26',3,24.69,'Du monde entier', '67,rue des Cinquante Otages', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',2,TIMESTAMP '1996-09-23 00:00:00',TIMESTAMP '1996-10-21 00:00:00',DATE '1996-10-03',2,40.26,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1996-09-24 00:00:00',TIMESTAMP '1996-10-22 00:00:00',DATE '1996-10-04',2,1.96,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',1,TIMESTAMP '1996-09-25 00:00:00',TIMESTAMP '1996-10-23 00:00:00',DATE '1996-10-04',2,74.16,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',4,TIMESTAMP '1996-09-26 00:00:00',TIMESTAMP '1996-10-24 00:00:00',DATE '1996-10-03',2,41.76,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',1,TIMESTAMP '1996-09-27 00:00:00',TIMESTAMP '1996-10-25 00:00:00',DATE '1996-10-08',3,150.15,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',6,TIMESTAMP '1996-09-30 00:00:00',TIMESTAMP '1996-10-28 00:00:00',DATE '1996-10-10',1,12.69,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',8,TIMESTAMP '1996-10-01 00:00:00',TIMESTAMP '1996-10-29 00:00:00',DATE '1996-10-04',2,4.73,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',7,TIMESTAMP '1996-10-02 00:00:00',TIMESTAMP '1996-10-30 00:00:00',DATE '1996-10-11',3,64.50,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',5,TIMESTAMP '1996-10-03 00:00:00',TIMESTAMP '1996-10-17 00:00:00',DATE '1996-10-18',3,34.57,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',3,TIMESTAMP '1996-10-03 00:00:00',TIMESTAMP '1996-10-31 00:00:00',DATE '1996-10-11',2,3.43,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',7,TIMESTAMP '1996-10-04 00:00:00',TIMESTAMP '1996-11-01 00:00:00',DATE '1996-10-23',3,0.40,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',4,TIMESTAMP '1996-10-07 00:00:00',TIMESTAMP '1996-11-04 00:00:00',DATE '1996-10-14',1,4.88,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',9,TIMESTAMP '1996-10-08 00:00:00',TIMESTAMP '1996-11-05 00:00:00',DATE '1996-10-10',1,214.27,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',1,TIMESTAMP '1996-10-09 00:00:00',TIMESTAMP '1996-10-23 00:00:00',DATE '1996-10-14',3,64.86,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOLID',4,TIMESTAMP '1996-10-10 00:00:00',TIMESTAMP '1996-11-07 00:00:00',DATE '1996-10-14',2,77.92,'Bólido Comidas preparadas', 'C/ Araquil,67', 'Madrid',NULL,'28023', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',2,TIMESTAMP '1996-10-11 00:00:00',TIMESTAMP '1996-11-08 00:00:00',DATE '1996-10-14',1,63.36,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',4,TIMESTAMP '1996-10-14 00:00:00',TIMESTAMP '1996-11-11 00:00:00',DATE '1996-10-17',3,87.03,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',4,TIMESTAMP '1996-10-15 00:00:00',TIMESTAMP '1996-11-26 00:00:00',DATE '1996-10-23',2,191.67,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',3,TIMESTAMP '1996-10-16 00:00:00',TIMESTAMP '1996-11-13 00:00:00',DATE '1996-10-28',1,12.75,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',9,TIMESTAMP '1996-10-16 00:00:00',TIMESTAMP '1996-11-27 00:00:00',DATE '1996-10-21',1,10.19,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',3,TIMESTAMP '1996-10-17 00:00:00',TIMESTAMP '1996-11-28 00:00:00',DATE '1996-10-21',2,52.84,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',5,TIMESTAMP '1996-10-18 00:00:00',TIMESTAMP '1996-11-15 00:00:00',DATE '1996-10-25',3,0.59,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',8,TIMESTAMP '1996-10-21 00:00:00',TIMESTAMP '1996-11-18 00:00:00',DATE '1996-10-28',2,8.56,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',7,TIMESTAMP '1996-10-22 00:00:00',TIMESTAMP '1996-11-19 00:00:00',DATE '1996-10-24',2,42.11,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PRINI',7,TIMESTAMP '1996-10-23 00:00:00',TIMESTAMP '1996-11-20 00:00:00',DATE '1996-10-25',2,15.51,'Princesa Isabel Vinhos', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',4,TIMESTAMP '1996-10-24 00:00:00',TIMESTAMP '1996-11-21 00:00:00',DATE '1996-10-29',3,108.26,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',4,TIMESTAMP '1996-10-25 00:00:00',TIMESTAMP '1996-11-22 00:00:00',DATE '1996-10-29',3,84.21,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',2,TIMESTAMP '1996-10-28 00:00:00',TIMESTAMP '1996-11-25 00:00:00',DATE '1996-11-04',2,15.66,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',1,TIMESTAMP '1996-10-29 00:00:00',TIMESTAMP '1996-11-26 00:00:00',DATE '1996-11-08',3,166.31,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',7,TIMESTAMP '1996-10-29 00:00:00',TIMESTAMP '1996-11-26 00:00:00',DATE '1996-11-05',3,26.78,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',4,TIMESTAMP '1996-10-30 00:00:00',TIMESTAMP '1996-11-13 00:00:00',DATE '1996-11-04',2,54.83,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',4,TIMESTAMP '1996-10-31 00:00:00',TIMESTAMP '1996-11-28 00:00:00',DATE '1996-11-06',1,110.37,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',4,TIMESTAMP '1996-11-01 00:00:00',TIMESTAMP '1996-11-29 00:00:00',DATE '1996-11-05',2,23.29,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1996-11-04 00:00:00',TIMESTAMP '1996-12-02 00:00:00',DATE '1996-11-11',2,249.06,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',3,TIMESTAMP '1996-11-05 00:00:00',TIMESTAMP '1996-12-17 00:00:00',DATE '1996-11-08',3,142.08,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',4,TIMESTAMP '1996-11-06 00:00:00',TIMESTAMP '1996-12-04 00:00:00',DATE '1996-11-08',3,3.10,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',4,TIMESTAMP '1996-11-07 00:00:00',TIMESTAMP '1996-12-05 00:00:00',DATE '1996-11-15',2,0.78,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',7,TIMESTAMP '1996-11-08 00:00:00',TIMESTAMP '1996-12-06 00:00:00',DATE '1996-11-15',1,8.63,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',6,TIMESTAMP '1996-11-11 00:00:00',TIMESTAMP '1996-12-09 00:00:00',DATE '1996-12-03',2,64.19,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',1,TIMESTAMP '1996-11-11 00:00:00',TIMESTAMP '1996-12-09 00:00:00',DATE '1996-11-20',1,162.33,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',3,TIMESTAMP '1996-11-12 00:00:00',TIMESTAMP '1996-11-26 00:00:00',DATE '1996-11-18',3,1.30,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',7,TIMESTAMP '1996-11-13 00:00:00',TIMESTAMP '1996-12-11 00:00:00',DATE '1996-11-25',3,360.63,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',8,TIMESTAMP '1996-11-14 00:00:00',TIMESTAMP '1996-12-12 00:00:00',DATE '1996-11-20',3,53.80,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',6,TIMESTAMP '1996-11-15 00:00:00',TIMESTAMP '1996-12-13 00:00:00',DATE '1996-11-20',1,41.95,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',6,TIMESTAMP '1996-11-18 00:00:00',TIMESTAMP '1996-12-16 00:00:00',DATE '1996-11-27',2,36.71,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',1,TIMESTAMP '1996-11-19 00:00:00',TIMESTAMP '1996-12-17 00:00:00',DATE '1996-12-02',3,34.88,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',5,TIMESTAMP '1996-11-20 00:00:00',TIMESTAMP '1996-12-18 00:00:00',DATE '1996-11-27',1,19.64,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',5,TIMESTAMP '1996-11-21 00:00:00',TIMESTAMP '1996-12-19 00:00:00',DATE '1996-11-26',3,288.43,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',4,TIMESTAMP '1996-11-22 00:00:00',TIMESTAMP '1996-12-20 00:00:00',DATE '1996-12-02',3,131.70,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',1,TIMESTAMP '1996-11-22 00:00:00',TIMESTAMP '1996-12-20 00:00:00',DATE '1996-12-03',2,183.17,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',3,TIMESTAMP '1996-11-25 00:00:00',TIMESTAMP '1996-12-23 00:00:00',DATE '1996-11-28',1,96.04,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',4,TIMESTAMP '1996-11-26 00:00:00',TIMESTAMP '1996-12-24 00:00:00',DATE '1996-12-04',3,30.54,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',1,TIMESTAMP '1996-11-26 00:00:00',TIMESTAMP '1997-01-07 00:00:00',DATE '1996-12-04',1,71.97,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',3,TIMESTAMP '1996-11-27 00:00:00',TIMESTAMP '1996-12-25 00:00:00',DATE '1996-12-02',2,22.00,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GALED',8,TIMESTAMP '1996-11-28 00:00:00',TIMESTAMP '1997-01-09 00:00:00',DATE '1996-12-30',2,10.14,'Galería del gastronómo', 'Rambla de Cataluña,23', 'Barcelona',NULL,'8022', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',7,TIMESTAMP '1996-11-28 00:00:00',TIMESTAMP '1996-12-26 00:00:00',DATE '1996-12-02',3,13.55,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',2,TIMESTAMP '1996-11-29 00:00:00',TIMESTAMP '1996-12-27 00:00:00',DATE '1996-12-02',2,101.95,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',8,TIMESTAMP '1996-12-02 00:00:00',TIMESTAMP '1996-12-30 00:00:00',DATE '1996-12-09',2,195.68,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',6,TIMESTAMP '1996-12-03 00:00:00',TIMESTAMP '1996-12-31 00:00:00',DATE '1996-12-27',2,1.17,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',1,TIMESTAMP '1996-12-03 00:00:00',TIMESTAMP '1996-12-31 00:00:00',DATE '1996-12-24',1,0.45,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',5,TIMESTAMP '1996-12-04 00:00:00',TIMESTAMP '1997-01-01 00:00:00',DATE '1996-12-09',2,890.78,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',4,TIMESTAMP '1996-12-05 00:00:00',TIMESTAMP '1997-01-02 00:00:00',DATE '1996-12-11',3,124.12,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',1,TIMESTAMP '1996-12-05 00:00:00',TIMESTAMP '1997-01-02 00:00:00',DATE '1996-12-09',3,3.94,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGC',3,TIMESTAMP '1996-12-06 00:00:00',TIMESTAMP '1997-01-03 00:00:00',DATE '1996-12-09',2,20.12,'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',1,TIMESTAMP '1996-12-09 00:00:00',TIMESTAMP '1997-01-06 00:00:00',DATE '1996-12-13',2,20.39,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',1,TIMESTAMP '1996-12-09 00:00:00',TIMESTAMP '1997-01-06 00:00:00',DATE '1996-12-13',3,22.21,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',5,TIMESTAMP '1996-12-10 00:00:00',TIMESTAMP '1997-01-07 00:00:00',DATE '1996-12-19',3,5.44,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',2,TIMESTAMP '1996-12-11 00:00:00',TIMESTAMP '1997-01-08 00:00:00',DATE '1996-12-13',1,45.03,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',8,TIMESTAMP '1996-12-12 00:00:00',TIMESTAMP '1997-01-09 00:00:00',DATE '1997-01-16',3,35.03,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',3,TIMESTAMP '1996-12-12 00:00:00',TIMESTAMP '1997-01-09 00:00:00',DATE '1996-12-13',3,7.99,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',4,TIMESTAMP '1996-12-13 00:00:00',TIMESTAMP '1997-01-10 00:00:00',DATE '1996-12-16',1,94.77,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',8,TIMESTAMP '1996-12-16 00:00:00',TIMESTAMP '1997-01-13 00:00:00',DATE '1996-12-18',3,34.24,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1996-12-16 00:00:00',TIMESTAMP '1997-01-13 00:00:00',DATE '1996-12-20',3,168.64,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',1,TIMESTAMP '1996-12-17 00:00:00',TIMESTAMP '1997-01-14 00:00:00',DATE '1996-12-23',2,30.96,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',9,TIMESTAMP '1996-12-18 00:00:00',TIMESTAMP '1997-01-01 00:00:00',DATE '1996-12-25',3,13.99,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',1,TIMESTAMP '1996-12-18 00:00:00',TIMESTAMP '1997-01-15 00:00:00',DATE '1996-12-20',2,93.63,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',2,TIMESTAMP '1996-12-19 00:00:00',TIMESTAMP '1997-01-16 00:00:00',DATE '1996-12-20',1,34.86,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',4,TIMESTAMP '1996-12-20 00:00:00',TIMESTAMP '1997-01-17 00:00:00',DATE '1996-12-24',2,47.42,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',6,TIMESTAMP '1996-12-23 00:00:00',TIMESTAMP '1997-01-20 00:00:00',DATE '1996-12-26',1,126.38,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',3,TIMESTAMP '1996-12-23 00:00:00',TIMESTAMP '1997-01-20 00:00:00',DATE '1996-12-31',3,5.45,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',2,TIMESTAMP '1996-12-24 00:00:00',TIMESTAMP '1997-01-21 00:00:00',DATE '1997-01-01',3,122.46,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1996-12-25 00:00:00',TIMESTAMP '1997-01-22 00:00:00',DATE '1997-01-03',3,126.56,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGC',1,TIMESTAMP '1996-12-25 00:00:00',TIMESTAMP '1997-01-22 00:00:00',DATE '1997-01-03',3,30.34,'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',6,TIMESTAMP '1996-12-26 00:00:00',TIMESTAMP '1997-01-23 00:00:00',DATE '1997-01-03',1,184.41,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',1,TIMESTAMP '1996-12-27 00:00:00',TIMESTAMP '1997-01-10 00:00:00',DATE '1997-01-06',3,135.35,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PRINI',5,TIMESTAMP '1996-12-27 00:00:00',TIMESTAMP '1997-01-24 00:00:00',DATE '1997-01-02',1,60.26,'Princesa Isabel Vinhos', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',2,TIMESTAMP '1996-12-30 00:00:00',TIMESTAMP '1997-01-27 00:00:00',DATE '1997-01-09',3,89.16,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',8,TIMESTAMP '1996-12-31 00:00:00',TIMESTAMP '1997-01-14 00:00:00',DATE '1997-01-08',3,27.36,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',1,TIMESTAMP '1997-01-01 00:00:00',TIMESTAMP '1997-01-29 00:00:00',DATE '1997-01-16',3,83.93,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',1,TIMESTAMP '1997-01-01 00:00:00',TIMESTAMP '1997-01-29 00:00:00',DATE '1997-01-10',1,12.51,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',8,TIMESTAMP '1997-01-02 00:00:00',TIMESTAMP '1997-02-13 00:00:00',DATE '1997-01-10',2,67.88,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',4,TIMESTAMP '1997-01-03 00:00:00',TIMESTAMP '1997-01-31 00:00:00',DATE '1997-01-09',3,73.79,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',2,TIMESTAMP '1997-01-03 00:00:00',TIMESTAMP '1997-01-31 00:00:00',DATE '1997-01-08',1,155.97,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',1,TIMESTAMP '1997-01-06 00:00:00',TIMESTAMP '1997-02-03 00:00:00',DATE '1997-01-22',1,34.82,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',7,TIMESTAMP '1997-01-07 00:00:00',TIMESTAMP '1997-02-18 00:00:00',DATE '1997-01-13',1,108.04,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',2,TIMESTAMP '1997-01-07 00:00:00',TIMESTAMP '1997-02-04 00:00:00',DATE '1997-01-30',2,91.48,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLIG',8,TIMESTAMP '1997-01-08 00:00:00',TIMESTAMP '1997-02-05 00:00:00',DATE '1997-01-14',1,11.26,'Folies gourmandes', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OCEAN',3,TIMESTAMP '1997-01-09 00:00:00',TIMESTAMP '1997-02-06 00:00:00',DATE '1997-01-14',1,29.83,'Océano Atlántico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',3,TIMESTAMP '1997-01-10 00:00:00',TIMESTAMP '1997-02-07 00:00:00',DATE '1997-01-15',3,2.40,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',9,TIMESTAMP '1997-01-10 00:00:00',TIMESTAMP '1997-02-07 00:00:00',DATE '1997-01-21',3,23.65,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',8,TIMESTAMP '1997-01-13 00:00:00',TIMESTAMP '1997-02-10 00:00:00',DATE '1997-01-15',2,3.77,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',3,TIMESTAMP '1997-01-14 00:00:00',TIMESTAMP '1997-02-11 00:00:00',DATE '1997-01-16',2,95.66,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',2,TIMESTAMP '1997-01-14 00:00:00',TIMESTAMP '1997-02-11 00:00:00',DATE '1997-01-17',3,21.48,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGC',3,TIMESTAMP '1997-01-15 00:00:00',TIMESTAMP '1997-02-12 00:00:00',DATE '1997-01-24',1,0.20,'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',8,TIMESTAMP '1997-01-16 00:00:00',TIMESTAMP '1997-02-13 00:00:00',DATE '1997-01-27',3,22.72,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',4,TIMESTAMP '1997-01-16 00:00:00',TIMESTAMP '1997-02-13 00:00:00',DATE '1997-01-28',3,70.29,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',4,TIMESTAMP '1997-01-17 00:00:00',TIMESTAMP '1997-02-14 00:00:00',DATE '1997-01-24',1,17.55,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',4,TIMESTAMP '1997-01-20 00:00:00',TIMESTAMP '1997-02-17 00:00:00',DATE '1997-01-30',2,137.35,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',3,TIMESTAMP '1997-01-21 00:00:00',TIMESTAMP '1997-02-18 00:00:00',DATE '1997-01-27',1,44.12,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',8,TIMESTAMP '1997-01-21 00:00:00',TIMESTAMP '1997-03-04 00:00:00',DATE '1997-01-27',1,99.23,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',2,TIMESTAMP '1997-01-22 00:00:00',TIMESTAMP '1997-02-19 00:00:00',DATE '1997-01-31',1,3.02,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',6,TIMESTAMP '1997-01-23 00:00:00',TIMESTAMP '1997-02-06 00:00:00',DATE '1997-02-24',3,24.50,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',7,TIMESTAMP '1997-01-23 00:00:00',TIMESTAMP '1997-02-20 00:00:00',DATE '1997-01-27',2,370.61,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',6,TIMESTAMP '1997-01-24 00:00:00',TIMESTAMP '1997-02-21 00:00:00',DATE '1997-02-14',2,7.93,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GALED',4,TIMESTAMP '1997-01-27 00:00:00',TIMESTAMP '1997-02-24 00:00:00',DATE '1997-02-06',1,18.69,'Galería del gastronómo', 'Rambla de Cataluña,23', 'Barcelona',NULL,'8022', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',4,TIMESTAMP '1997-01-27 00:00:00',TIMESTAMP '1997-02-24 00:00:00',DATE '1997-03-03',2,31.29,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',7,TIMESTAMP '1997-01-28 00:00:00',TIMESTAMP '1997-02-25 00:00:00',DATE '1997-02-04',1,11.09,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',3,TIMESTAMP '1997-01-29 00:00:00',TIMESTAMP '1997-03-12 00:00:00',DATE '1997-02-07',2,56.63,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',4,TIMESTAMP '1997-01-30 00:00:00',TIMESTAMP '1997-02-13 00:00:00',DATE '1997-02-03',1,458.78,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',4,TIMESTAMP '1997-01-30 00:00:00',TIMESTAMP '1997-02-13 00:00:00',DATE '1997-02-07',2,44.17,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',3,TIMESTAMP '1997-01-31 00:00:00',TIMESTAMP '1997-02-14 00:00:00',DATE '1997-02-07',2,4.34,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PRINI',3,TIMESTAMP '1997-02-03 00:00:00',TIMESTAMP '1997-03-03 00:00:00',DATE '1997-03-04',3,73.83,'Princesa Isabel Vinhos', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',3,TIMESTAMP '1997-02-03 00:00:00',TIMESTAMP '1997-03-03 00:00:00',DATE '1997-02-13',2,17.92,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CONSH',8,TIMESTAMP '1997-02-04 00:00:00',TIMESTAMP '1997-03-18 00:00:00',DATE '1997-02-07',2,9.21,'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London',NULL,'WX1 6LT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',3,TIMESTAMP '1997-02-05 00:00:00',TIMESTAMP '1997-03-05 00:00:00',DATE '1997-02-11',2,156.66,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',8,TIMESTAMP '1997-02-05 00:00:00',TIMESTAMP '1997-03-05 00:00:00',DATE '1997-02-12',1,19.97,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',3,TIMESTAMP '1997-02-06 00:00:00',TIMESTAMP '1997-03-06 00:00:00',DATE '1997-02-14',2,8.24,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',6,TIMESTAMP '1997-02-07 00:00:00',TIMESTAMP '1997-03-07 00:00:00',DATE '1997-02-10',3,4.07,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',4,TIMESTAMP '1997-02-10 00:00:00',TIMESTAMP '1997-03-10 00:00:00',DATE '1997-02-28',2,86.53,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',3,TIMESTAMP '1997-02-10 00:00:00',TIMESTAMP '1997-03-24 00:00:00',DATE '1997-03-14',2,73.02,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',3,TIMESTAMP '1997-02-11 00:00:00',TIMESTAMP '1997-03-11 00:00:00',DATE '1997-02-18',2,47.94,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',8,TIMESTAMP '1997-02-12 00:00:00',TIMESTAMP '1997-03-12 00:00:00',DATE '1997-02-14',1,13.95,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1997-02-12 00:00:00',TIMESTAMP '1997-03-12 00:00:00',DATE '1997-02-21',3,3.50,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1997-02-13 00:00:00',TIMESTAMP '1997-03-13 00:00:00',DATE '1997-02-20',1,9.30,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',6,TIMESTAMP '1997-02-14 00:00:00',TIMESTAMP '1997-03-14 00:00:00',DATE '1997-02-19',1,14.68,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',4,TIMESTAMP '1997-02-14 00:00:00',TIMESTAMP '1997-03-14 00:00:00',DATE '1997-03-07',2,68.66,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RANCH',4,TIMESTAMP '1997-02-17 00:00:00',TIMESTAMP '1997-03-17 00:00:00',DATE '1997-02-24',2,38.82,'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',3,TIMESTAMP '1997-02-18 00:00:00',TIMESTAMP '1997-03-18 00:00:00',DATE '1997-02-27',2,53.30,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',8,TIMESTAMP '1997-02-19 00:00:00',TIMESTAMP '1997-03-19 00:00:00',DATE '1997-03-11',2,7.23,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',4,TIMESTAMP '1997-02-19 00:00:00',TIMESTAMP '1997-03-05 00:00:00',DATE '1997-03-12',3,189.09,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',8,TIMESTAMP '1997-02-20 00:00:00',TIMESTAMP '1997-03-20 00:00:00',DATE '1997-02-26',1,140.26,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',1,TIMESTAMP '1997-02-21 00:00:00',TIMESTAMP '1997-03-21 00:00:00',DATE '1997-02-26',2,25.36,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',4,TIMESTAMP '1997-02-21 00:00:00',TIMESTAMP '1997-03-21 00:00:00',DATE '1997-02-25',3,2.74,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',8,TIMESTAMP '1997-02-24 00:00:00',TIMESTAMP '1997-04-07 00:00:00',DATE '1997-03-03',2,180.45,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',8,TIMESTAMP '1997-02-25 00:00:00',TIMESTAMP '1997-04-08 00:00:00',DATE '1997-02-28',2,8.12,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',2,TIMESTAMP '1997-02-25 00:00:00',TIMESTAMP '1997-03-25 00:00:00',DATE '1997-03-03',1,11.57,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',7,TIMESTAMP '1997-02-26 00:00:00',TIMESTAMP '1997-03-26 00:00:00',DATE '1997-03-04',3,147.06,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',4,TIMESTAMP '1997-02-27 00:00:00',TIMESTAMP '1997-03-27 00:00:00',DATE '1997-02-28',2,25.09,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1997-02-28 00:00:00',TIMESTAMP '1997-03-28 00:00:00',DATE '1997-03-03',1,16.27,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',1,TIMESTAMP '1997-02-28 00:00:00',TIMESTAMP '1997-03-28 00:00:00',DATE '1997-03-05',3,148.61,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CONSH',2,TIMESTAMP '1997-03-03 00:00:00',TIMESTAMP '1997-03-31 00:00:00',DATE '1997-03-18',1,6.17,'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London',NULL,'WX1 6LT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',5,TIMESTAMP '1997-03-04 00:00:00',TIMESTAMP '1997-04-01 00:00:00',DATE '1997-03-06',3,14.78,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',4,TIMESTAMP '1997-03-04 00:00:00',TIMESTAMP '1997-04-01 00:00:00',DATE '1997-03-14',2,89.00,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',1,TIMESTAMP '1997-03-05 00:00:00',TIMESTAMP '1997-04-02 00:00:00',DATE '1997-03-14',3,145.04,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('COMMI',4,TIMESTAMP '1997-03-06 00:00:00',TIMESTAMP '1997-04-03 00:00:00',DATE '1997-03-13',1,11.93,'Comércio Mineiro', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',8,TIMESTAMP '1997-03-06 00:00:00',TIMESTAMP '1997-04-03 00:00:00',DATE '1997-03-11',2,4.93,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',3,TIMESTAMP '1997-03-07 00:00:00',TIMESTAMP '1997-04-04 00:00:00',DATE '1997-03-12',3,44.12,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',1,TIMESTAMP '1997-03-10 00:00:00',TIMESTAMP '1997-04-07 00:00:00',DATE '1997-03-14',1,60.18,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',4,TIMESTAMP '1997-03-11 00:00:00',TIMESTAMP '1997-04-08 00:00:00',DATE '1997-03-14',2,64.56,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',2,TIMESTAMP '1997-03-11 00:00:00',TIMESTAMP '1997-04-08 00:00:00',DATE '1997-03-18',3,45.59,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',8,TIMESTAMP '1997-03-12 00:00:00',TIMESTAMP '1997-04-09 00:00:00',DATE '1997-03-19',1,4.20,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',1,TIMESTAMP '1997-03-13 00:00:00',TIMESTAMP '1997-03-27 00:00:00',DATE '1997-03-21',3,16.37,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',5,TIMESTAMP '1997-03-13 00:00:00',TIMESTAMP '1997-04-10 00:00:00',DATE '1997-03-21',2,83.49,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',9,TIMESTAMP '1997-03-14 00:00:00',TIMESTAMP '1997-04-11 00:00:00',DATE '1997-04-04',1,68.52,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',8,TIMESTAMP '1997-03-17 00:00:00',TIMESTAMP '1997-04-14 00:00:00',DATE '1997-03-24',3,4.41,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PRINI',5,TIMESTAMP '1997-03-17 00:00:00',TIMESTAMP '1997-04-14 00:00:00',DATE '1997-03-25',2,13.02,'Princesa Isabel Vinhos', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',2,TIMESTAMP '1997-03-18 00:00:00',TIMESTAMP '1997-04-01 00:00:00',DATE '1997-03-26',3,4.81,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',3,TIMESTAMP '1997-03-19 00:00:00',TIMESTAMP '1997-04-16 00:00:00',DATE '1997-03-21',3,708.95,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLIG',6,TIMESTAMP '1997-03-20 00:00:00',TIMESTAMP '1997-04-17 00:00:00',DATE '1997-03-24',2,1.35,'Folies gourmandes', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',8,TIMESTAMP '1997-03-20 00:00:00',TIMESTAMP '1997-04-17 00:00:00',DATE '1997-03-25',2,64.33,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAZYK',1,TIMESTAMP '1997-03-21 00:00:00',TIMESTAMP '1997-04-18 00:00:00',DATE '1997-04-10',3,7.48,'Lazy K Kountry Store', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',7,TIMESTAMP '1997-03-24 00:00:00',TIMESTAMP '1997-04-21 00:00:00',DATE '1997-04-25',2,15.28,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',3,TIMESTAMP '1997-03-24 00:00:00',TIMESTAMP '1997-04-21 00:00:00',DATE '1997-04-01',3,6.88,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',4,TIMESTAMP '1997-03-25 00:00:00',TIMESTAMP '1997-04-08 00:00:00',DATE '1997-03-31',2,64.45,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',1,TIMESTAMP '1997-03-26 00:00:00',TIMESTAMP '1997-04-23 00:00:00',DATE '1997-04-02',2,30.53,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',2,TIMESTAMP '1997-03-26 00:00:00',TIMESTAMP '1997-04-23 00:00:00',DATE '1997-03-28',2,71.07,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',8,TIMESTAMP '1997-03-27 00:00:00',TIMESTAMP '1997-04-24 00:00:00',DATE '1997-04-02',2,4.93,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',6,TIMESTAMP '1997-03-28 00:00:00',TIMESTAMP '1997-04-25 00:00:00',DATE '1997-04-09',2,5.29,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',7,TIMESTAMP '1997-03-31 00:00:00',TIMESTAMP '1997-04-28 00:00:00',DATE '1997-04-03',2,210.19,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',8,TIMESTAMP '1997-03-31 00:00:00',TIMESTAMP '1997-04-28 00:00:00',DATE '1997-04-08',3,16.96,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',3,TIMESTAMP '1997-04-01 00:00:00',TIMESTAMP '1997-04-29 00:00:00',DATE '1997-04-11',1,62.89,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',4,TIMESTAMP '1997-04-02 00:00:00',TIMESTAMP '1997-04-30 00:00:00',DATE '1997-04-10',3,10.64,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('COMMI',4,TIMESTAMP '1997-04-02 00:00:00',TIMESTAMP '1997-04-30 00:00:00',DATE '1997-04-09',2,65.99,'Comércio Mineiro', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAUGB',3,TIMESTAMP '1997-04-03 00:00:00',TIMESTAMP '1997-05-01 00:00:00',DATE '1997-04-11',3,4.65,'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',7,TIMESTAMP '1997-04-04 00:00:00',TIMESTAMP '1997-05-02 00:00:00',DATE '1997-04-07',2,46.77,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',7,TIMESTAMP '1997-04-04 00:00:00',TIMESTAMP '1997-05-02 00:00:00',DATE '1997-04-07',1,36.21,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',8,TIMESTAMP '1997-04-07 00:00:00',TIMESTAMP '1997-05-05 00:00:00',DATE '1997-04-11',2,29.75,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',4,TIMESTAMP '1997-04-08 00:00:00',TIMESTAMP '1997-05-06 00:00:00',DATE '1997-04-16',2,102.02,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',6,TIMESTAMP '1997-04-09 00:00:00',TIMESTAMP '1997-05-07 00:00:00',DATE '1997-04-17',1,42.68,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',9,TIMESTAMP '1997-04-09 00:00:00',TIMESTAMP '1997-05-07 00:00:00',DATE '1997-04-16',3,8.85,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',2,TIMESTAMP '1997-04-10 00:00:00',TIMESTAMP '1997-05-08 00:00:00',DATE '1997-04-29',1,69.32,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',6,TIMESTAMP '1997-04-11 00:00:00',TIMESTAMP '1997-05-09 00:00:00',DATE '1997-04-16',2,16.74,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',4,TIMESTAMP '1997-04-11 00:00:00',TIMESTAMP '1997-05-09 00:00:00',DATE '1997-04-18',3,59.13,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',3,TIMESTAMP '1997-04-14 00:00:00',TIMESTAMP '1997-05-12 00:00:00',DATE '1997-04-21',3,7.13,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',9,TIMESTAMP '1997-04-15 00:00:00',TIMESTAMP '1997-05-13 00:00:00',DATE '1997-05-02',2,21.19,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',7,TIMESTAMP '1997-04-15 00:00:00',TIMESTAMP '1997-05-13 00:00:00',DATE '1997-04-22',1,47.45,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',1,TIMESTAMP '1997-04-16 00:00:00',TIMESTAMP '1997-05-14 00:00:00',DATE '1997-05-13',2,4.99,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',4,TIMESTAMP '1997-04-17 00:00:00',TIMESTAMP '1997-05-15 00:00:00',DATE '1997-04-29',1,0.15,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',6,TIMESTAMP '1997-04-18 00:00:00',TIMESTAMP '1997-05-16 00:00:00',DATE '1997-04-28',3,367.63,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',4,TIMESTAMP '1997-04-18 00:00:00',TIMESTAMP '1997-05-16 00:00:00',DATE '1997-04-21',3,350.64,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',7,TIMESTAMP '1997-04-21 00:00:00',TIMESTAMP '1997-05-19 00:00:00',DATE '1997-04-24',2,3.53,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',7,TIMESTAMP '1997-04-22 00:00:00',TIMESTAMP '1997-06-03 00:00:00',DATE '1997-04-28',1,105.65,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',3,TIMESTAMP '1997-04-22 00:00:00',TIMESTAMP '1997-05-20 00:00:00',DATE '1997-05-16',2,789.95,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1997-04-23 00:00:00',TIMESTAMP '1997-05-07 00:00:00',DATE '1997-05-23',1,204.47,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',2,TIMESTAMP '1997-04-24 00:00:00',TIMESTAMP '1997-05-22 00:00:00',DATE '1997-05-01',3,62.78,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('NORTS',3,TIMESTAMP '1997-04-24 00:00:00',TIMESTAMP '1997-05-22 00:00:00',DATE '1997-04-29',3,32.07,'North/South', 'South House 300 Queensbridge', 'London',NULL,'SW7 1RZ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',4,TIMESTAMP '1997-04-25 00:00:00',TIMESTAMP '1997-05-09 00:00:00',DATE '1997-05-05',2,218.15,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',6,TIMESTAMP '1997-04-28 00:00:00',TIMESTAMP '1997-05-26 00:00:00',DATE '1997-05-01',3,91.76,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',7,TIMESTAMP '1997-04-29 00:00:00',TIMESTAMP '1997-05-27 00:00:00',DATE '1997-05-01',1,13.37,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',8,TIMESTAMP '1997-04-29 00:00:00',TIMESTAMP '1997-05-27 00:00:00',DATE '1997-05-02',2,17.22,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',4,TIMESTAMP '1997-04-30 00:00:00',TIMESTAMP '1997-05-28 00:00:00',DATE '1997-05-06',1,45.33,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',7,TIMESTAMP '1997-05-01 00:00:00',TIMESTAMP '1997-05-29 00:00:00',DATE '1997-05-30',2,77.63,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',1,TIMESTAMP '1997-05-01 00:00:00',TIMESTAMP '1997-05-29 00:00:00',DATE '1997-05-07',2,244.79,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',1,TIMESTAMP '1997-05-02 00:00:00',TIMESTAMP '1997-05-30 00:00:00',DATE '1997-05-23',2,11.06,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',4,TIMESTAMP '1997-05-05 00:00:00',TIMESTAMP '1997-06-02 00:00:00',DATE '1997-05-15',2,58.59,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',7,TIMESTAMP '1997-05-05 00:00:00',TIMESTAMP '1997-06-02 00:00:00',DATE '1997-05-07',1,41.90,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',6,TIMESTAMP '1997-05-06 00:00:00',TIMESTAMP '1997-05-20 00:00:00',DATE '1997-05-09',2,3.35,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',5,TIMESTAMP '1997-05-07 00:00:00',TIMESTAMP '1997-06-04 00:00:00',DATE '1997-05-09',2,66.69,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',3,TIMESTAMP '1997-05-08 00:00:00',TIMESTAMP '1997-06-05 00:00:00',DATE '1997-05-12',2,339.22,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OCEAN',7,TIMESTAMP '1997-05-08 00:00:00',TIMESTAMP '1997-06-05 00:00:00',DATE '1997-05-19',1,8.12,'Océano Atlántico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',7,TIMESTAMP '1997-05-09 00:00:00',TIMESTAMP '1997-06-06 00:00:00',DATE '1997-05-12',3,74.46,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1997-05-12 00:00:00',TIMESTAMP '1997-06-09 00:00:00',DATE '1997-05-22',1,188.04,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',8,TIMESTAMP '1997-05-12 00:00:00',TIMESTAMP '1997-06-09 00:00:00',DATE '1997-05-14',2,27.94,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',4,TIMESTAMP '1997-05-13 00:00:00',TIMESTAMP '1997-06-10 00:00:00',DATE '1997-05-21',1,15.64,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',3,TIMESTAMP '1997-05-14 00:00:00',TIMESTAMP '1997-06-11 00:00:00',DATE '1997-06-06',2,58.88,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',1,TIMESTAMP '1997-05-14 00:00:00',TIMESTAMP '1997-05-28 00:00:00',DATE '1997-05-19',1,78.85,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',9,TIMESTAMP '1997-05-15 00:00:00',TIMESTAMP '1997-06-12 00:00:00',DATE '1997-05-16',3,4.87,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',6,TIMESTAMP '1997-05-16 00:00:00',TIMESTAMP '1997-06-13 00:00:00',DATE '1997-05-23',3,12.36,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',3,TIMESTAMP '1997-05-19 00:00:00',TIMESTAMP '1997-06-16 00:00:00',DATE '1997-06-13',3,1007.64,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',2,TIMESTAMP '1997-05-19 00:00:00',TIMESTAMP '1997-06-16 00:00:00',DATE '1997-05-29',1,68.65,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',1,TIMESTAMP '1997-05-20 00:00:00',TIMESTAMP '1997-06-17 00:00:00',DATE '1997-05-26',3,10.95,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',8,TIMESTAMP '1997-05-21 00:00:00',TIMESTAMP '1997-06-18 00:00:00',DATE '1997-05-23',2,48.17,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',4,TIMESTAMP '1997-05-21 00:00:00',TIMESTAMP '1997-06-18 00:00:00',DATE '1997-05-30',1,24.91,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAZYK',8,TIMESTAMP '1997-05-22 00:00:00',TIMESTAMP '1997-06-19 00:00:00',DATE '1997-06-26',2,11.92,'Lazy K Kountry Store', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',1,TIMESTAMP '1997-05-23 00:00:00',TIMESTAMP '1997-06-20 00:00:00',DATE '1997-05-27',3,194.72,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',3,TIMESTAMP '1997-05-23 00:00:00',TIMESTAMP '1997-06-20 00:00:00',DATE '1997-06-02',2,178.43,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',3,TIMESTAMP '1997-05-26 00:00:00',TIMESTAMP '1997-06-23 00:00:00',DATE '1997-06-02',2,1.43,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',5,TIMESTAMP '1997-05-27 00:00:00',TIMESTAMP '1997-06-10 00:00:00',DATE '1997-05-30',1,171.24,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',7,TIMESTAMP '1997-05-28 00:00:00',TIMESTAMP '1997-06-25 00:00:00',DATE '1997-06-06',3,4.32,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',4,TIMESTAMP '1997-05-28 00:00:00',TIMESTAMP '1997-07-09 00:00:00',DATE '1997-06-06',3,72.95,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',2,TIMESTAMP '1997-05-29 00:00:00',TIMESTAMP '1997-06-26 00:00:00',DATE '1997-06-05',1,83.22,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',2,TIMESTAMP '1997-05-30 00:00:00',TIMESTAMP '1997-06-27 00:00:00',DATE '1997-06-03',2,149.49,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',4,TIMESTAMP '1997-05-30 00:00:00',TIMESTAMP '1997-06-27 00:00:00',DATE '1997-06-05',3,120.97,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',6,TIMESTAMP '1997-06-02 00:00:00',TIMESTAMP '1997-06-30 00:00:00',DATE '1997-06-04',3,252.49,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',2,TIMESTAMP '1997-06-03 00:00:00',TIMESTAMP '1997-07-15 00:00:00',DATE '1997-06-13',1,9.80,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',9,TIMESTAMP '1997-06-03 00:00:00',TIMESTAMP '1997-06-17 00:00:00',DATE '1997-06-06',2,96.72,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',1,TIMESTAMP '1997-06-04 00:00:00',TIMESTAMP '1997-07-02 00:00:00',DATE '1997-06-10',2,72.97,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',6,TIMESTAMP '1997-06-05 00:00:00',TIMESTAMP '1997-07-03 00:00:00',DATE '1997-06-13',1,8.05,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',8,TIMESTAMP '1997-06-06 00:00:00',TIMESTAMP '1997-07-04 00:00:00',DATE '1997-06-09',1,36.65,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',2,TIMESTAMP '1997-06-06 00:00:00',TIMESTAMP '1997-07-04 00:00:00',DATE '1997-06-09',2,242.21,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',1,TIMESTAMP '1997-06-09 00:00:00',TIMESTAMP '1997-07-07 00:00:00',DATE '1997-06-12',1,22.95,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',2,TIMESTAMP '1997-06-10 00:00:00',TIMESTAMP '1997-07-22 00:00:00',DATE '1997-06-24',2,60.43,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',4,TIMESTAMP '1997-06-10 00:00:00',TIMESTAMP '1997-07-08 00:00:00',DATE '1997-06-16',3,13.75,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',8,TIMESTAMP '1997-06-11 00:00:00',TIMESTAMP '1997-07-09 00:00:00',DATE '1997-06-18',2,7.15,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',9,TIMESTAMP '1997-06-12 00:00:00',TIMESTAMP '1997-07-10 00:00:00',DATE '1997-06-18',1,88.40,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',1,TIMESTAMP '1997-06-12 00:00:00',TIMESTAMP '1997-07-10 00:00:00',DATE '1997-06-17',1,33.97,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GALED',3,TIMESTAMP '1997-06-13 00:00:00',TIMESTAMP '1997-07-11 00:00:00',DATE '1997-07-09',3,6.54,'Galería del gastronómo', 'Rambla de Cataluña,23', 'Barcelona',NULL,'8022', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',5,TIMESTAMP '1997-06-16 00:00:00',TIMESTAMP '1997-07-14 00:00:00',DATE '1997-07-11',1,58.98,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',3,TIMESTAMP '1997-06-17 00:00:00',TIMESTAMP '1997-07-15 00:00:00',DATE '1997-06-19',3,188.99,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',8,TIMESTAMP '1997-06-17 00:00:00',TIMESTAMP '1997-07-29 00:00:00',DATE '1997-07-04',3,26.06,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1997-06-18 00:00:00',TIMESTAMP '1997-07-16 00:00:00',DATE '1997-06-25',2,116.43,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',7,TIMESTAMP '1997-06-19 00:00:00',TIMESTAMP '1997-07-17 00:00:00',DATE '1997-06-20',3,84.84,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRAIH',4,TIMESTAMP '1997-06-19 00:00:00',TIMESTAMP '1997-07-17 00:00:00',DATE '1997-06-30',2,37.60,'Trail''s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MORGK',5,TIMESTAMP '1997-06-20 00:00:00',TIMESTAMP '1997-07-04 00:00:00',DATE '1997-06-30',1,127.34,'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',3,TIMESTAMP '1997-06-23 00:00:00',TIMESTAMP '1997-07-07 00:00:00',DATE '1997-06-30',3,18.56,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); ";
            cmd.ExecuteNonQuery();
            
            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRAIH',9,TIMESTAMP '1997-06-23 00:00:00',TIMESTAMP '1997-08-04 00:00:00',DATE '1997-06-30',2,25.41,'Trail''s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',4,TIMESTAMP '1997-06-24 00:00:00',TIMESTAMP '1997-07-22 00:00:00',DATE '1997-07-25',3,29.60,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LETSS',1,TIMESTAMP '1997-06-25 00:00:00',TIMESTAMP '1997-07-23 00:00:00',DATE '1997-07-04',2,13.73,'Let''s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',4,TIMESTAMP '1997-06-26 00:00:00',TIMESTAMP '1997-07-24 00:00:00',DATE '1997-07-01',3,75.89,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',3,TIMESTAMP '1997-06-26 00:00:00',TIMESTAMP '1997-07-24 00:00:00',DATE '1997-07-02',1,3.01,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',3,TIMESTAMP '1997-06-27 00:00:00',TIMESTAMP '1997-07-25 00:00:00',DATE '1997-07-14',2,27.71,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',2,TIMESTAMP '1997-06-30 00:00:00',TIMESTAMP '1997-07-28 00:00:00',DATE '1997-07-04',2,7.28,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',4,TIMESTAMP '1997-06-30 00:00:00',TIMESTAMP '1997-07-28 00:00:00',DATE '1997-07-04',1,59.14,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',7,TIMESTAMP '1997-07-01 00:00:00',TIMESTAMP '1997-07-29 00:00:00',DATE '1997-07-10',1,13.41,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',9,TIMESTAMP '1997-07-02 00:00:00',TIMESTAMP '1997-07-30 00:00:00',DATE '1997-07-09',1,0.48,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',1,TIMESTAMP '1997-07-02 00:00:00',TIMESTAMP '1997-07-30 00:00:00',DATE '1997-07-09',1,62.52,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1997-07-03 00:00:00',TIMESTAMP '1997-07-31 00:00:00',DATE '1997-07-10',3,194.67,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',8,TIMESTAMP '1997-07-04 00:00:00',TIMESTAMP '1997-08-01 00:00:00',DATE '1997-07-14',2,4.42,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',4,TIMESTAMP '1997-07-07 00:00:00',TIMESTAMP '1997-08-04 00:00:00',DATE '1997-07-14',3,44.77,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',1,TIMESTAMP '1997-07-07 00:00:00',TIMESTAMP '1997-07-21 00:00:00',DATE '1997-07-16',1,55.92,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',3,TIMESTAMP '1997-07-08 00:00:00',TIMESTAMP '1997-08-05 00:00:00',DATE '1997-07-16',1,32.10,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',7,TIMESTAMP '1997-07-09 00:00:00',TIMESTAMP '1997-08-06 00:00:00',DATE '1997-08-13',2,174.20,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',3,TIMESTAMP '1997-07-09 00:00:00',TIMESTAMP '1997-08-06 00:00:00',DATE '1997-07-16',2,5.24,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',2,TIMESTAMP '1997-07-10 00:00:00',TIMESTAMP '1997-08-07 00:00:00',DATE '1997-07-14',1,96.78,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',8,TIMESTAMP '1997-07-11 00:00:00',TIMESTAMP '1997-08-08 00:00:00',DATE '1997-08-12',1,16.34,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',7,TIMESTAMP '1997-07-11 00:00:00',TIMESTAMP '1997-08-08 00:00:00',DATE '1997-07-18',3,35.12,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',1,TIMESTAMP '1997-07-14 00:00:00',TIMESTAMP '1997-08-11 00:00:00',DATE '1997-07-18',3,44.42,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',6,TIMESTAMP '1997-07-15 00:00:00',TIMESTAMP '1997-08-26 00:00:00',DATE '1997-07-21',3,29.98,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGC',4,TIMESTAMP '1997-07-16 00:00:00',TIMESTAMP '1997-08-13 00:00:00',DATE '1997-07-21',1,45.13,'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',7,TIMESTAMP '1997-07-16 00:00:00',TIMESTAMP '1997-08-27 00:00:00',DATE '1997-07-22',1,58.30,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',8,TIMESTAMP '1997-07-17 00:00:00',TIMESTAMP '1997-08-14 00:00:00',DATE '1997-07-22',2,2.92,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',8,TIMESTAMP '1997-07-18 00:00:00',TIMESTAMP '1997-08-15 00:00:00',DATE '1997-08-08',2,48.77,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',1,TIMESTAMP '1997-07-18 00:00:00',TIMESTAMP '1997-08-15 00:00:00',DATE '1997-07-29',1,7.46,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',1,TIMESTAMP '1997-07-21 00:00:00',TIMESTAMP '1997-08-18 00:00:00',DATE '1997-07-29',2,379.13,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',4,TIMESTAMP '1997-07-22 00:00:00',TIMESTAMP '1997-08-19 00:00:00',DATE '1997-07-31',3,79.40,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',5,TIMESTAMP '1997-07-22 00:00:00',TIMESTAMP '1997-08-19 00:00:00',DATE '1997-07-25',1,200.24,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',4,TIMESTAMP '1997-07-23 00:00:00',TIMESTAMP '1997-08-20 00:00:00',DATE '1997-08-01',2,27.79,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DUMON',7,TIMESTAMP '1997-07-24 00:00:00',TIMESTAMP '1997-08-21 00:00:00',DATE '1997-07-30',2,1.85,'Du monde entier', '67,rue des Cinquante Otages', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',8,TIMESTAMP '1997-07-25 00:00:00',TIMESTAMP '1997-08-22 00:00:00',DATE '1997-08-06',1,26.78,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',6,TIMESTAMP '1997-07-25 00:00:00',TIMESTAMP '1997-08-22 00:00:00',DATE '1997-08-01',2,80.65,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1997-07-28 00:00:00',TIMESTAMP '1997-08-25 00:00:00',DATE '1997-08-01',2,544.08,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',4,TIMESTAMP '1997-07-29 00:00:00',TIMESTAMP '1997-08-26 00:00:00',DATE '1997-08-01',2,8.11,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',8,TIMESTAMP '1997-07-29 00:00:00',TIMESTAMP '1997-08-26 00:00:00',DATE '1997-08-01',3,1.93,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',2,TIMESTAMP '1997-07-30 00:00:00',TIMESTAMP '1997-08-27 00:00:00',DATE '1997-08-06',3,0.75,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',1,TIMESTAMP '1997-07-31 00:00:00',TIMESTAMP '1997-08-28 00:00:00',DATE '1997-08-05',2,116.53,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',4,TIMESTAMP '1997-07-31 00:00:00',TIMESTAMP '1997-08-28 00:00:00',DATE '1997-08-04',2,18.53,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',1,TIMESTAMP '1997-08-01 00:00:00',TIMESTAMP '1997-09-12 00:00:00',DATE '1997-08-08',1,154.68,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',3,TIMESTAMP '1997-08-04 00:00:00',TIMESTAMP '1997-09-01 00:00:00',DATE '1997-08-07',3,91.05,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAUGB',2,TIMESTAMP '1997-08-05 00:00:00',TIMESTAMP '1997-09-02 00:00:00',DATE '1997-08-14',3,0.94,'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',4,TIMESTAMP '1997-08-05 00:00:00',TIMESTAMP '1997-09-02 00:00:00',DATE '1997-08-11',2,23.73,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',4,TIMESTAMP '1997-08-06 00:00:00',TIMESTAMP '1997-09-03 00:00:00',DATE '1997-08-11',3,50.97,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',8,TIMESTAMP '1997-08-07 00:00:00',TIMESTAMP '1997-09-04 00:00:00',DATE '1997-08-12',2,97.18,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THECR',4,TIMESTAMP '1997-08-07 00:00:00',TIMESTAMP '1997-09-04 00:00:00',DATE '1997-08-19',2,94.80,'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANATR',3,TIMESTAMP '1997-08-08 00:00:00',TIMESTAMP '1997-09-05 00:00:00',DATE '1997-08-14',1,43.90,'Ana Trujillo Emparedados y helados', 'Avda. de la Constitución 2222', 'México D.F.',NULL,'05021', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',1,TIMESTAMP '1997-08-11 00:00:00',TIMESTAMP '1997-09-08 00:00:00',DATE '1997-08-20',2,138.69,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',8,TIMESTAMP '1997-08-11 00:00:00',TIMESTAMP '1997-09-22 00:00:00',DATE '1997-08-21',3,107.46,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',4,TIMESTAMP '1997-08-12 00:00:00',TIMESTAMP '1997-09-09 00:00:00',DATE '1997-08-20',3,30.36,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',4,TIMESTAMP '1997-08-12 00:00:00',TIMESTAMP '1997-09-09 00:00:00',DATE '1997-08-20',3,85.46,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',1,TIMESTAMP '1997-08-13 00:00:00',TIMESTAMP '1997-09-10 00:00:00',DATE '1997-08-19',2,32.35,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',8,TIMESTAMP '1997-08-14 00:00:00',TIMESTAMP '1997-09-11 00:00:00',DATE '1997-08-15',1,0.87,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',8,TIMESTAMP '1997-08-14 00:00:00',TIMESTAMP '1997-09-11 00:00:00',DATE '1997-08-19',1,41.38,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',7,TIMESTAMP '1997-08-15 00:00:00',TIMESTAMP '1997-09-12 00:00:00',DATE '1997-08-18',3,477.90,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLIG',4,TIMESTAMP '1997-08-15 00:00:00',TIMESTAMP '1997-09-12 00:00:00',DATE '1997-08-21',3,487.38,'Folies gourmandes', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',8,TIMESTAMP '1997-08-18 00:00:00',TIMESTAMP '1997-09-15 00:00:00',DATE '1997-08-21',3,47.46,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',4,TIMESTAMP '1997-08-19 00:00:00',TIMESTAMP '1997-09-16 00:00:00',DATE '1997-08-26',1,1.15,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',6,TIMESTAMP '1997-08-19 00:00:00',TIMESTAMP '1997-09-16 00:00:00',DATE '1997-08-26',1,201.29,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',3,TIMESTAMP '1997-08-20 00:00:00',TIMESTAMP '1997-09-17 00:00:00',DATE '1997-09-01',1,158.44,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',7,TIMESTAMP '1997-08-20 00:00:00',TIMESTAMP '1997-09-17 00:00:00',DATE '1997-08-27',3,38.64,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',4,TIMESTAMP '1997-08-21 00:00:00',TIMESTAMP '1997-09-18 00:00:00',DATE '1997-08-28',1,23.55,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',4,TIMESTAMP '1997-08-22 00:00:00',TIMESTAMP '1997-09-19 00:00:00',DATE '1997-08-26',2,179.61,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',7,TIMESTAMP '1997-08-22 00:00:00',TIMESTAMP '1997-09-19 00:00:00',DATE '1997-09-05',3,41.89,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',6,TIMESTAMP '1997-08-25 00:00:00',TIMESTAMP '1997-09-22 00:00:00',DATE '1997-09-02',1,29.46,'Alfreds Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',3,TIMESTAMP '1997-08-25 00:00:00',TIMESTAMP '1997-09-22 00:00:00',DATE '1997-09-01',2,0.14,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',4,TIMESTAMP '1997-08-26 00:00:00',TIMESTAMP '1997-09-23 00:00:00',DATE '1997-09-02',1,12.41,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',9,TIMESTAMP '1997-08-27 00:00:00',TIMESTAMP '1997-10-08 00:00:00',DATE '1997-09-03',3,142.33,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',4,TIMESTAMP '1997-08-27 00:00:00',TIMESTAMP '1997-09-10 00:00:00',DATE '1997-09-03',2,45.54,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',5,TIMESTAMP '1997-08-28 00:00:00',TIMESTAMP '1997-10-09 00:00:00',DATE '1997-09-09',2,14.25,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',5,TIMESTAMP '1997-08-28 00:00:00',TIMESTAMP '1997-09-25 00:00:00',DATE '1997-08-29',3,6.20,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',5,TIMESTAMP '1997-08-29 00:00:00',TIMESTAMP '1997-09-26 00:00:00',DATE '1997-09-03',3,176.81,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',8,TIMESTAMP '1997-09-01 00:00:00',TIMESTAMP '1997-09-29 00:00:00',DATE '1997-09-11',2,20.60,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',4,TIMESTAMP '1997-09-01 00:00:00',TIMESTAMP '1997-09-29 00:00:00',DATE '1997-09-08',2,7.14,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',1,TIMESTAMP '1997-09-02 00:00:00',TIMESTAMP '1997-09-30 00:00:00',DATE '1997-09-19',1,93.25,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',5,TIMESTAMP '1997-09-02 00:00:00',TIMESTAMP '1997-09-30 00:00:00',DATE '1997-09-11',1,55.26,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',1,TIMESTAMP '1997-09-03 00:00:00',TIMESTAMP '1997-10-01 00:00:00',DATE '1997-09-11',2,4.41,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',6,TIMESTAMP '1997-09-04 00:00:00',TIMESTAMP '1997-10-02 00:00:00',DATE '1997-09-10',1,57.15,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',2,TIMESTAMP '1997-09-04 00:00:00',TIMESTAMP '1997-10-02 00:00:00',DATE '1997-09-15',2,352.69,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',4,TIMESTAMP '1997-09-05 00:00:00',TIMESTAMP '1997-10-03 00:00:00',DATE '1997-09-08',1,364.15,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',7,TIMESTAMP '1997-09-05 00:00:00',TIMESTAMP '1997-10-03 00:00:00',DATE '1997-09-10',2,105.81,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGC',8,TIMESTAMP '1997-09-08 00:00:00',TIMESTAMP '1997-10-06 00:00:00',DATE '1997-10-15',1,111.29,'Hungry Coyote Import Store', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',7,TIMESTAMP '1997-09-09 00:00:00',TIMESTAMP '1997-10-07 00:00:00',DATE '1997-09-15',3,17.55,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',3,TIMESTAMP '1997-09-09 00:00:00',TIMESTAMP '1997-10-07 00:00:00',DATE '1997-09-18',2,1.28,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',2,TIMESTAMP '1997-09-10 00:00:00',TIMESTAMP '1997-09-24 00:00:00',DATE '1997-10-03',2,113.15,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',1,TIMESTAMP '1997-09-10 00:00:00',TIMESTAMP '1997-10-08 00:00:00',DATE '1997-09-19',3,1.27,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',1,TIMESTAMP '1997-09-11 00:00:00',TIMESTAMP '1997-10-09 00:00:00',DATE '1997-09-17',2,26.31,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',7,TIMESTAMP '1997-09-12 00:00:00',TIMESTAMP '1997-10-10 00:00:00',DATE '1997-09-22',2,232.42,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',7,TIMESTAMP '1997-09-12 00:00:00',TIMESTAMP '1997-10-10 00:00:00',DATE '1997-09-19',1,78.09,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',1,TIMESTAMP '1997-09-15 00:00:00',TIMESTAMP '1997-10-13 00:00:00',DATE '1997-09-23',2,47.22,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',2,TIMESTAMP '1997-09-15 00:00:00',TIMESTAMP '1997-10-13 00:00:00',DATE '1997-09-22',1,24.39,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',4,TIMESTAMP '1997-09-16 00:00:00',TIMESTAMP '1997-10-14 00:00:00',DATE '1997-09-18',1,203.48,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANR',1,TIMESTAMP '1997-09-17 00:00:00',TIMESTAMP '1997-10-15 00:00:00',DATE '1997-09-24',1,30.34,'France restauration', '54,rue Royale', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',9,TIMESTAMP '1997-09-17 00:00:00',TIMESTAMP '1997-10-01 00:00:00',DATE '1997-09-26',2,95.75,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',2,TIMESTAMP '1997-09-18 00:00:00',TIMESTAMP '1997-10-16 00:00:00',DATE '1997-09-19',1,22.76,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',4,TIMESTAMP '1997-09-18 00:00:00',TIMESTAMP '1997-10-16 00:00:00',DATE '1997-09-30',2,0.90,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',5,TIMESTAMP '1997-09-19 00:00:00',TIMESTAMP '1997-10-17 00:00:00',DATE '1997-09-23',2,31.85,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',2,TIMESTAMP '1997-09-22 00:00:00',TIMESTAMP '1997-10-20 00:00:00',DATE '1997-09-29',2,2.01,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',1,TIMESTAMP '1997-09-22 00:00:00',TIMESTAMP '1997-10-20 00:00:00',DATE '1997-09-26',3,4.03,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',7,TIMESTAMP '1997-09-23 00:00:00',TIMESTAMP '1997-10-21 00:00:00',DATE '1997-10-16',3,388.98,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',8,TIMESTAMP '1997-09-23 00:00:00',TIMESTAMP '1997-10-21 00:00:00',DATE '1997-09-30',3,27.94,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',1,TIMESTAMP '1997-09-24 00:00:00',TIMESTAMP '1997-10-22 00:00:00',DATE '1997-09-26',1,26.61,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',3,TIMESTAMP '1997-09-25 00:00:00',TIMESTAMP '1997-10-23 00:00:00',DATE '1997-09-30',3,76.13,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',3,TIMESTAMP '1997-09-25 00:00:00',TIMESTAMP '1997-10-23 00:00:00',DATE '1997-10-01',2,36.13,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DUMON',2,TIMESTAMP '1997-09-26 00:00:00',TIMESTAMP '1997-10-24 00:00:00',DATE '1997-10-01',1,4.40,'Du monde entier', '67,rue des Cinquante Otages', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',3,TIMESTAMP '1997-09-26 00:00:00',TIMESTAMP '1997-10-24 00:00:00',DATE '1997-09-30',1,145.63,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',4,TIMESTAMP '1997-09-29 00:00:00',TIMESTAMP '1997-10-13 00:00:00',DATE '1997-10-03',2,33.75,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',2,TIMESTAMP '1997-09-30 00:00:00',TIMESTAMP '1997-10-28 00:00:00',DATE '1997-10-08',1,96.50,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',9,TIMESTAMP '1997-09-30 00:00:00',TIMESTAMP '1997-10-28 00:00:00',DATE '1997-10-30',2,296.43,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',4,TIMESTAMP '1997-10-01 00:00:00',TIMESTAMP '1997-10-15 00:00:00',DATE '1997-10-07',2,299.09,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',1,TIMESTAMP '1997-10-01 00:00:00',TIMESTAMP '1997-10-29 00:00:00',DATE '1997-10-07',2,13.42,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',1,TIMESTAMP '1997-10-02 00:00:00',TIMESTAMP '1997-10-30 00:00:00',DATE '1997-10-03',1,15.80,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1997-10-03 00:00:00',TIMESTAMP '1997-11-14 00:00:00',DATE '1997-10-22',2,810.05,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',4,TIMESTAMP '1997-10-03 00:00:00',TIMESTAMP '1997-10-31 00:00:00',DATE '1997-10-13',2,61.02,'Alfred''s Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',3,TIMESTAMP '1997-10-06 00:00:00',TIMESTAMP '1997-10-20 00:00:00',DATE '1997-10-10',3,139.34,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',8,TIMESTAMP '1997-10-06 00:00:00',TIMESTAMP '1997-11-03 00:00:00',DATE '1997-10-09',3,398.36,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',7,TIMESTAMP '1997-10-07 00:00:00',TIMESTAMP '1997-11-18 00:00:00',DATE '1997-10-14',1,16.72,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',8,TIMESTAMP '1997-10-08 00:00:00',TIMESTAMP '1997-11-19 00:00:00',DATE '1997-10-14',3,102.55,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',3,TIMESTAMP '1997-10-08 00:00:00',TIMESTAMP '1997-11-05 00:00:00',DATE '1997-10-14',1,45.52,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
               "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',4,TIMESTAMP '1997-10-09 00:00:00',TIMESTAMP '1997-11-06 00:00:00',DATE '1997-10-17',1,272.47,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MORGK',3,TIMESTAMP '1997-10-09 00:00:00',TIMESTAMP '1997-11-06 00:00:00',DATE '1997-10-13',3,0.58,'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',3,TIMESTAMP '1997-10-10 00:00:00',TIMESTAMP '1997-11-07 00:00:00',DATE '1997-10-16',1,65.10,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',6,TIMESTAMP '1997-10-13 00:00:00',TIMESTAMP '1997-10-27 00:00:00',DATE '1997-10-15',3,220.31,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',4,TIMESTAMP '1997-10-13 00:00:00',TIMESTAMP '1997-11-24 00:00:00',DATE '1997-10-21',1,23.94,'Alfred''s Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',6,TIMESTAMP '1997-10-14 00:00:00',TIMESTAMP '1997-11-11 00:00:00',DATE '1997-10-20',2,152.30,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',6,TIMESTAMP '1997-10-14 00:00:00',TIMESTAMP '1997-11-11 00:00:00',DATE '1997-11-07',1,4.78,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',9,TIMESTAMP '1997-10-15 00:00:00',TIMESTAMP '1997-11-12 00:00:00',DATE '1997-11-18',2,3.52,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',8,TIMESTAMP '1997-10-16 00:00:00',TIMESTAMP '1997-11-13 00:00:00',DATE '1997-10-21',3,135.63,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',4,TIMESTAMP '1997-10-16 00:00:00',TIMESTAMP '1997-10-30 00:00:00',DATE '1997-10-23',3,21.74,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THEBI',6,TIMESTAMP '1997-10-17 00:00:00',TIMESTAMP '1997-11-28 00:00:00',DATE '1997-11-05',2,2.96,'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',1,TIMESTAMP '1997-10-17 00:00:00',TIMESTAMP '1997-11-14 00:00:00',DATE '1997-11-20',3,210.80,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',1,TIMESTAMP '1997-10-20 00:00:00',TIMESTAMP '1997-11-17 00:00:00',DATE '1997-10-23',1,4.98,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',5,TIMESTAMP '1997-10-21 00:00:00',TIMESTAMP '1997-12-02 00:00:00',DATE '1997-10-29',2,52.41,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',3,TIMESTAMP '1997-10-21 00:00:00',TIMESTAMP '1997-11-18 00:00:00',DATE '1997-10-31',1,89.93,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1997-10-22 00:00:00',TIMESTAMP '1997-11-19 00:00:00',DATE '1997-10-24',1,167.05,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',5,TIMESTAMP '1997-10-22 00:00:00',TIMESTAMP '1997-11-19 00:00:00',DATE '1997-10-27',3,24.49,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',3,TIMESTAMP '1997-10-23 00:00:00',TIMESTAMP '1997-11-06 00:00:00',DATE '1997-10-29',1,63.20,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RANCH',4,TIMESTAMP '1997-10-24 00:00:00',TIMESTAMP '1997-11-21 00:00:00',DATE '1997-10-27',2,22.57,'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',1,TIMESTAMP '1997-10-24 00:00:00',TIMESTAMP '1997-11-21 00:00:00',DATE '1997-10-29',2,59.25,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',1,TIMESTAMP '1997-10-27 00:00:00',TIMESTAMP '1997-11-24 00:00:00',DATE '1997-10-29',3,170.88,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LETSS',8,TIMESTAMP '1997-10-27 00:00:00',TIMESTAMP '1997-11-24 00:00:00',DATE '1997-11-05',2,51.44,'Let''s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',8,TIMESTAMP '1997-10-28 00:00:00',TIMESTAMP '1997-11-11 00:00:00',DATE '1997-11-05',2,9.53,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',5,TIMESTAMP '1997-10-29 00:00:00',TIMESTAMP '1997-11-26 00:00:00',DATE '1997-10-31',3,48.92,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',8,TIMESTAMP '1997-10-29 00:00:00',TIMESTAMP '1997-12-10 00:00:00',DATE '1997-11-04',1,74.58,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',3,TIMESTAMP '1997-10-30 00:00:00',TIMESTAMP '1997-11-27 00:00:00',DATE '1997-11-25',1,21.72,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MEREP',8,TIMESTAMP '1997-10-30 00:00:00',TIMESTAMP '1997-12-11 00:00:00',DATE '1997-11-05',2,57.75,'Mère Paillarde', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FAMIA',4,TIMESTAMP '1997-10-31 00:00:00',TIMESTAMP '1997-11-28 00:00:00',DATE '1997-11-05',3,10.83,'Familia Arquibaldo', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',4,TIMESTAMP '1997-11-03 00:00:00',TIMESTAMP '1997-11-17 00:00:00',DATE '1997-12-05',1,16.56,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',2,TIMESTAMP '1997-11-03 00:00:00',TIMESTAMP '1997-12-01 00:00:00',DATE '1997-12-05',1,89.90,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',4,TIMESTAMP '1997-11-04 00:00:00',TIMESTAMP '1997-12-02 00:00:00',DATE '1997-11-11',2,58.33,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',8,TIMESTAMP '1997-11-04 00:00:00',TIMESTAMP '1997-12-16 00:00:00',DATE '1997-11-14',3,141.06,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',5,TIMESTAMP '1997-11-05 00:00:00',TIMESTAMP '1997-12-03 00:00:00',DATE '1997-11-14',1,20.12,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',7,TIMESTAMP '1997-11-06 00:00:00',TIMESTAMP '1997-12-04 00:00:00',DATE '1997-11-14',1,96.65,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',3,TIMESTAMP '1997-11-06 00:00:00',TIMESTAMP '1997-12-04 00:00:00',DATE '1997-11-07',1,16.97,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',1,TIMESTAMP '1997-11-07 00:00:00',TIMESTAMP '1997-12-05 00:00:00',DATE '1997-11-10',3,110.11,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',2,TIMESTAMP '1997-11-07 00:00:00',TIMESTAMP '1997-12-05 00:00:00',DATE '1997-11-12',3,1.63,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
               "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LETSS',6,TIMESTAMP '1997-11-10 00:00:00',TIMESTAMP '1997-12-08 00:00:00',DATE '1997-11-21',2,45.97,'Let''s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',9,TIMESTAMP '1997-11-11 00:00:00',TIMESTAMP '1997-12-09 00:00:00',DATE '1997-11-21',2,44.10,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VINET',2,TIMESTAMP '1997-11-11 00:00:00',TIMESTAMP '1997-12-09 00:00:00',DATE '1997-11-18',2,7.79,'Vins et alcools Chevalier', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPECD',2,TIMESTAMP '1997-11-12 00:00:00',TIMESTAMP '1997-12-10 00:00:00',DATE '1997-11-18',1,2.91,'Spécialités du monde', '25,rue Lauriston', 'Paris',NULL,'75016', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VINET',3,TIMESTAMP '1997-11-12 00:00:00',TIMESTAMP '1997-12-10 00:00:00',DATE '1997-11-17',3,11.08,'Vins et alcools Chevalier', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',4,TIMESTAMP '1997-11-13 00:00:00',TIMESTAMP '1997-12-11 00:00:00',DATE '1997-11-25',2,81.88,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',4,TIMESTAMP '1997-11-14 00:00:00',TIMESTAMP '1997-11-28 00:00:00',DATE '1997-11-18',3,10.96,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',3,TIMESTAMP '1997-11-14 00:00:00',TIMESTAMP '1997-12-12 00:00:00',DATE '1997-11-18',3,243.73,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',1,TIMESTAMP '1997-11-17 00:00:00',TIMESTAMP '1997-12-15 00:00:00',DATE '1997-11-21',2,23.72,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',6,TIMESTAMP '1997-11-17 00:00:00',TIMESTAMP '1997-12-15 00:00:00',DATE '1997-11-24',1,69.19,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',9,TIMESTAMP '1997-11-18 00:00:00',TIMESTAMP '1997-12-16 00:00:00',DATE '1997-11-27',1,3.52,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',1,TIMESTAMP '1997-11-19 00:00:00',TIMESTAMP '1997-12-17 00:00:00',DATE '1997-11-21',3,31.43,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',6,TIMESTAMP '1997-11-19 00:00:00',TIMESTAMP '1997-12-17 00:00:00',DATE '1997-11-26',1,117.33,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',3,TIMESTAMP '1997-11-20 00:00:00',TIMESTAMP '1997-12-18 00:00:00',DATE '1997-11-28',1,232.55,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',4,TIMESTAMP '1997-11-20 00:00:00',TIMESTAMP '1997-12-18 00:00:00',DATE '1997-12-19',2,61.53,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',9,TIMESTAMP '1997-11-21 00:00:00',TIMESTAMP '1997-12-19 00:00:00',DATE '1997-11-24',1,79.30,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',3,TIMESTAMP '1997-11-24 00:00:00',TIMESTAMP '1997-12-22 00:00:00',DATE '1997-12-03',3,130.79,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('NORTS',2,TIMESTAMP '1997-11-24 00:00:00',TIMESTAMP '1997-12-22 00:00:00',DATE '1997-11-28',3,1.39,'North/South', 'South House 300 Queensbridge', 'London',NULL,'SW7 1RZ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',3,TIMESTAMP '1997-11-25 00:00:00',TIMESTAMP '1997-12-23 00:00:00',DATE '1997-11-27',1,7.70,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',6,TIMESTAMP '1997-11-25 00:00:00',TIMESTAMP '1997-12-23 00:00:00',DATE '1997-11-27',3,2.38,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',4,TIMESTAMP '1997-11-26 00:00:00',TIMESTAMP '1997-12-24 00:00:00',DATE '1997-11-28',2,16.71,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',8,TIMESTAMP '1997-11-27 00:00:00',TIMESTAMP '1997-12-25 00:00:00',DATE '1997-12-02',2,73.21,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',6,TIMESTAMP '1997-11-27 00:00:00',TIMESTAMP '1997-12-25 00:00:00',DATE '1997-12-15',1,8.19,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',3,TIMESTAMP '1997-11-28 00:00:00',TIMESTAMP '1997-12-26 00:00:00',DATE '1997-12-04',3,138.17,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANATR',3,TIMESTAMP '1997-11-28 00:00:00',TIMESTAMP '1997-12-26 00:00:00',DATE '1997-12-12',3,11.99,'Ana Trujillo Emparedados y helados', 'Avda. de la Constitución 2222', 'México D.F.',NULL,'05021', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',4,TIMESTAMP '1997-12-01 00:00:00',TIMESTAMP '1997-12-29 00:00:00',DATE '1997-12-10',1,155.64,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',5,TIMESTAMP '1997-12-02 00:00:00',TIMESTAMP '1997-12-30 00:00:00',DATE '1997-12-08',2,18.66,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',3,TIMESTAMP '1997-12-02 00:00:00',TIMESTAMP '1997-12-30 00:00:00',DATE '1997-12-09',1,328.74,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLIG',3,TIMESTAMP '1997-12-03 00:00:00',TIMESTAMP '1997-12-31 00:00:00',DATE '1997-12-08',3,37.35,'Folies gourmandes', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',6,TIMESTAMP '1997-12-03 00:00:00',TIMESTAMP '1997-12-31 00:00:00',DATE '1997-12-08',3,145.45,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',3,TIMESTAMP '1997-12-04 00:00:00',TIMESTAMP '1998-01-01 00:00:00',DATE '1997-12-09',3,42.74,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',4,TIMESTAMP '1997-12-05 00:00:00',TIMESTAMP '1998-01-02 00:00:00',DATE '1997-12-09',1,157.55,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',4,TIMESTAMP '1997-12-05 00:00:00',TIMESTAMP '1998-01-02 00:00:00',DATE '1997-12-15',3,1.59,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',3,TIMESTAMP '1997-12-08 00:00:00',TIMESTAMP '1998-01-05 00:00:00',DATE '1997-12-15',2,146.32,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',3,TIMESTAMP '1997-12-08 00:00:00',TIMESTAMP '1998-01-05 00:00:00',DATE '1997-12-12',1,65.06,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',8,TIMESTAMP '1997-12-09 00:00:00',TIMESTAMP '1998-01-06 00:00:00',DATE '1997-12-17',3,5.32,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',9,TIMESTAMP '1997-12-10 00:00:00',TIMESTAMP '1998-01-07 00:00:00',DATE '1998-01-02',2,11.19,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',3,TIMESTAMP '1997-12-10 00:00:00',TIMESTAMP '1998-01-07 00:00:00',DATE '1997-12-19',2,91.28,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',1,TIMESTAMP '1997-12-11 00:00:00',TIMESTAMP '1998-01-08 00:00:00',DATE '1997-12-16',3,96.43,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',4,TIMESTAMP '1997-12-11 00:00:00',TIMESTAMP '1997-12-25 00:00:00',DATE '1997-12-12',1,48.20,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THECR',7,TIMESTAMP '1997-12-12 00:00:00',TIMESTAMP '1998-01-09 00:00:00',DATE '1997-12-26',1,20.25,'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',1,TIMESTAMP '1997-12-15 00:00:00',TIMESTAMP '1998-01-12 00:00:00',DATE '1997-12-18',3,351.53,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',7,TIMESTAMP '1997-12-15 00:00:00',TIMESTAMP '1997-12-29 00:00:00',DATE '1998-01-21',2,3.01,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1997-12-16 00:00:00',TIMESTAMP '1998-01-13 00:00:00',DATE '1997-12-24',1,6.79,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MORGK',3,TIMESTAMP '1997-12-16 00:00:00',TIMESTAMP '1998-01-13 00:00:00',DATE '1998-01-14',2,58.13,'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',2,TIMESTAMP '1997-12-16 00:00:00',TIMESTAMP '1997-12-30 00:00:00',DATE '1997-12-25',1,42.13,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',2,TIMESTAMP '1997-12-17 00:00:00',TIMESTAMP '1998-01-14 00:00:00',DATE '1997-12-19',3,73.16,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',9,TIMESTAMP '1997-12-17 00:00:00',TIMESTAMP '1998-01-14 00:00:00',DATE '1997-12-22',3,1.10,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',4,TIMESTAMP '1997-12-18 00:00:00',TIMESTAMP '1998-01-15 00:00:00',DATE '1997-12-19',2,124.98,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',4,TIMESTAMP '1997-12-18 00:00:00',TIMESTAMP '1998-01-15 00:00:00',DATE '1997-12-22',3,70.09,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GROSR',1,TIMESTAMP '1997-12-18 00:00:00',TIMESTAMP '1998-01-15 00:00:00',DATE '1997-12-24',3,1.51,'GROSELLA-Restaurante', '5ª Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',8,TIMESTAMP '1997-12-19 00:00:00',TIMESTAMP '1998-01-16 00:00:00',DATE '1997-12-23',1,110.87,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',2,TIMESTAMP '1997-12-19 00:00:00',TIMESTAMP '1998-01-02 00:00:00',DATE '1997-12-26',1,249.93,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',1,TIMESTAMP '1997-12-22 00:00:00',TIMESTAMP '1998-01-19 00:00:00',DATE '1998-01-19',2,42.70,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLIG',1,TIMESTAMP '1997-12-22 00:00:00',TIMESTAMP '1998-01-19 00:00:00',DATE '1997-12-31',2,100.60,'Folies gourmandes', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',6,TIMESTAMP '1997-12-22 00:00:00',TIMESTAMP '1998-01-19 00:00:00',DATE '1997-12-26',1,28.23,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',6,TIMESTAMP '1997-12-23 00:00:00',TIMESTAMP '1998-01-20 00:00:00',DATE '1998-01-01',2,16.85,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',1,TIMESTAMP '1997-12-23 00:00:00',TIMESTAMP '1998-01-20 00:00:00',DATE '1997-12-31',3,23.79,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',3,TIMESTAMP '1997-12-24 00:00:00',TIMESTAMP '1998-01-21 00:00:00',DATE '1998-01-08',3,4.52,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',6,TIMESTAMP '1997-12-24 00:00:00',TIMESTAMP '1998-01-21 00:00:00',DATE '1998-01-02',1,21.49,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',8,TIMESTAMP '1997-12-24 00:00:00',TIMESTAMP '1998-01-21 00:00:00',DATE '1998-01-20',2,126.66,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',3,TIMESTAMP '1997-12-25 00:00:00',TIMESTAMP '1998-01-22 00:00:00',DATE '1998-01-14',1,26.52,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',7,TIMESTAMP '1997-12-25 00:00:00',TIMESTAMP '1998-01-22 00:00:00',DATE '1998-01-05',2,33.35,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',2,TIMESTAMP '1997-12-26 00:00:00',TIMESTAMP '1998-01-23 00:00:00',DATE '1998-01-05',1,2.33,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',9,TIMESTAMP '1997-12-26 00:00:00',TIMESTAMP '1998-02-06 00:00:00',DATE '1998-01-05',3,30.76,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',1,TIMESTAMP '1997-12-26 00:00:00',TIMESTAMP '1998-01-23 00:00:00',DATE '1998-01-05',3,137.44,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOLID',4,TIMESTAMP '1997-12-29 00:00:00',TIMESTAMP '1998-01-26 00:00:00',DATE '1997-12-31',2,97.09,'Bólido Comidas preparadas', 'C/ Araquil,67', 'Madrid',NULL,'28023', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',4,TIMESTAMP '1997-12-29 00:00:00',TIMESTAMP '1998-01-26 00:00:00',DATE '1998-01-02',2,257.26,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',4,TIMESTAMP '1997-12-30 00:00:00',TIMESTAMP '1998-01-27 00:00:00',DATE '1998-01-06',1,55.23,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',6,TIMESTAMP '1997-12-30 00:00:00',TIMESTAMP '1998-01-27 00:00:00',DATE '1998-01-07',2,27.33,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THEBI',2,TIMESTAMP '1997-12-30 00:00:00',TIMESTAMP '1998-01-27 00:00:00',DATE '1998-01-09',3,237.34,'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',3,TIMESTAMP '1997-12-31 00:00:00',TIMESTAMP '1998-01-28 00:00:00',DATE '1998-01-05',2,22.11,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',4,TIMESTAMP '1997-12-31 00:00:00',TIMESTAMP '1998-01-28 00:00:00',DATE '1998-01-30',1,1.36,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',2,TIMESTAMP '1998-01-01 00:00:00',TIMESTAMP '1998-01-29 00:00:00',DATE '1998-01-09',3,45.53,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',7,TIMESTAMP '1998-01-01 00:00:00',TIMESTAMP '1998-01-29 00:00:00',DATE '1998-01-07',1,4.87,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAUGB',2,TIMESTAMP '1998-01-01 00:00:00',TIMESTAMP '1998-01-29 00:00:00',DATE '1998-01-07',3,4.33,'Laughing Bacchus Wine Cellars', '2319 Elm St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',8,TIMESTAMP '1998-01-02 00:00:00',TIMESTAMP '1998-01-30 00:00:00',DATE '1998-01-08',1,31.22,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',5,TIMESTAMP '1998-01-02 00:00:00',TIMESTAMP '1998-01-30 00:00:00',DATE '1998-01-12',1,59.78,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',1,TIMESTAMP '1998-01-05 00:00:00',TIMESTAMP '1998-02-02 00:00:00',DATE '1998-01-09',1,47.38,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',3,TIMESTAMP '1998-01-05 00:00:00',TIMESTAMP '1998-02-02 00:00:00',DATE '1998-01-14',3,130.94,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',2,TIMESTAMP '1998-01-05 00:00:00',TIMESTAMP '1998-02-02 00:00:00',DATE '1998-01-14',3,14.62,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',4,TIMESTAMP '1998-01-06 00:00:00',TIMESTAMP '1998-02-03 00:00:00',DATE '1998-02-04',2,719.78,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',3,TIMESTAMP '1998-01-06 00:00:00',TIMESTAMP '1998-01-20 00:00:00',DATE '1998-01-13',2,306.07,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',7,TIMESTAMP '1998-01-07 00:00:00',TIMESTAMP '1998-02-04 00:00:00',DATE '1998-01-12',3,65.48,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',2,TIMESTAMP '1998-01-07 00:00:00',TIMESTAMP '1998-02-04 00:00:00',DATE '1998-01-16',3,19.76,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',3,TIMESTAMP '1998-01-07 00:00:00',TIMESTAMP '1998-02-04 00:00:00',DATE '1998-01-13',2,37.52,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',1,TIMESTAMP '1998-01-08 00:00:00',TIMESTAMP '1998-02-05 00:00:00',DATE '1998-01-15',1,36.68,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRAIH',6,TIMESTAMP '1998-01-08 00:00:00',TIMESTAMP '1998-02-05 00:00:00',DATE '1998-01-16',3,7.00,'Trail''s Head Gourmet Provisioners', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',5,TIMESTAMP '1998-01-09 00:00:00',TIMESTAMP '1998-02-06 00:00:00',DATE '1998-01-13',2,163.97,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1998-01-09 00:00:00',TIMESTAMP '1998-02-06 00:00:00',DATE '1998-01-30',1,1.23,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',1,TIMESTAMP '1998-01-09 00:00:00',TIMESTAMP '1998-02-06 00:00:00',DATE '1998-01-14',1,79.25,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLONP',6,TIMESTAMP '1998-01-12 00:00:00',TIMESTAMP '1998-02-09 00:00:00',DATE '1998-02-06',1,7.09,'Blondel père et fils', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',1,TIMESTAMP '1998-01-12 00:00:00',TIMESTAMP '1998-01-26 00:00:00',DATE '1998-02-06',2,63.54,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RANCH',9,TIMESTAMP '1998-01-13 00:00:00',TIMESTAMP '1998-01-27 00:00:00',DATE '1998-02-04',1,90.85,'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',9,TIMESTAMP '1998-01-13 00:00:00',TIMESTAMP '1998-02-10 00:00:00',DATE '1998-01-23',1,154.72,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',4,TIMESTAMP '1998-01-13 00:00:00',TIMESTAMP '1998-02-24 00:00:00',DATE '1998-01-21',2,81.83,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',3,TIMESTAMP '1998-01-14 00:00:00',TIMESTAMP '1998-02-11 00:00:00',DATE '1998-01-23',2,72.19,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',2,TIMESTAMP '1998-01-14 00:00:00',TIMESTAMP '1998-02-11 00:00:00',DATE '1998-01-19',2,43.26,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',6,TIMESTAMP '1998-01-15 00:00:00',TIMESTAMP '1998-02-12 00:00:00',DATE '1998-01-23',2,71.49,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',1,TIMESTAMP '1998-01-15 00:00:00',TIMESTAMP '1998-02-12 00:00:00',DATE '1998-01-19',3,29.78,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',1,TIMESTAMP '1998-01-15 00:00:00',TIMESTAMP '1998-02-12 00:00:00',DATE '1998-01-21',3,69.53,'Alfred''s Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',7,TIMESTAMP '1998-01-16 00:00:00',TIMESTAMP '1998-02-13 00:00:00',DATE '1998-01-21',1,411.88,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',9,TIMESTAMP '1998-01-16 00:00:00',TIMESTAMP '1998-02-13 00:00:00',DATE '1998-01-23',3,13.32,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',3,TIMESTAMP '1998-01-19 00:00:00',TIMESTAMP '1998-02-16 00:00:00',DATE '1998-01-23',3,59.28,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TRADH',3,TIMESTAMP '1998-01-19 00:00:00',TIMESTAMP '1998-02-16 00:00:00',DATE '1998-01-22',3,35.43,'Tradiçao Hipermercados', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',4,TIMESTAMP '1998-01-19 00:00:00',TIMESTAMP '1998-03-02 00:00:00',DATE '1998-02-16',2,2.71,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',5,TIMESTAMP '1998-01-20 00:00:00',TIMESTAMP '1998-02-17 00:00:00',DATE '1998-01-29',2,424.30,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',1,TIMESTAMP '1998-01-20 00:00:00',TIMESTAMP '1998-02-17 00:00:00',DATE '1998-01-29',3,54.42,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',4,TIMESTAMP '1998-01-21 00:00:00',TIMESTAMP '1998-02-18 00:00:00',DATE '1998-01-26',2,9.26,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',8,TIMESTAMP '1998-01-21 00:00:00',TIMESTAMP '1998-02-18 00:00:00',DATE '1998-01-26',2,25.22,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',8,TIMESTAMP '1998-01-21 00:00:00',TIMESTAMP '1998-02-04 00:00:00',DATE '1998-01-30',1,212.98,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',2,TIMESTAMP '1998-01-22 00:00:00',TIMESTAMP '1998-03-05 00:00:00',DATE '1998-01-23',3,56.46,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',4,TIMESTAMP '1998-01-22 00:00:00',TIMESTAMP '1998-02-05 00:00:00',DATE '1998-02-10',3,487.57,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CONSH',7,TIMESTAMP '1998-01-23 00:00:00',TIMESTAMP '1998-02-20 00:00:00',DATE '1998-01-29',2,38.24,'Consolidated Holdings', 'Berkeley Gardens 12 Brewery', 'London',NULL,'WX1 6LT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',9,TIMESTAMP '1998-01-23 00:00:00',TIMESTAMP '1998-02-20 00:00:00',DATE '1998-01-30',2,0.56,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VICTE',1,TIMESTAMP '1998-01-23 00:00:00',TIMESTAMP '1998-03-06 00:00:00',DATE '1998-01-30',1,49.19,'Victuailles en stock', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
               "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',5,TIMESTAMP '1998-01-26 00:00:00',TIMESTAMP '1998-02-23 00:00:00',DATE '1998-02-02',1,160.55,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',8,TIMESTAMP '1998-01-26 00:00:00',TIMESTAMP '1998-02-09 00:00:00',DATE '1998-01-30',1,174.05,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',9,TIMESTAMP '1998-01-27 00:00:00',TIMESTAMP '1998-02-24 00:00:00',DATE '1998-02-03',2,53.83,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',3,TIMESTAMP '1998-01-27 00:00:00',TIMESTAMP '1998-02-24 00:00:00',DATE '1998-02-05',2,100.22,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',3,TIMESTAMP '1998-01-27 00:00:00',TIMESTAMP '1998-02-24 00:00:00',DATE '1998-02-04',1,170.97,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANTON',3,TIMESTAMP '1998-01-28 00:00:00',TIMESTAMP '1998-02-25 00:00:00',DATE '1998-02-10',2,58.43,'Antonio Moreno Taquería', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',8,TIMESTAMP '1998-01-28 00:00:00',TIMESTAMP '1998-02-25 00:00:00',DATE '1998-02-06',2,188.85,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LACOR',2,TIMESTAMP '1998-01-29 00:00:00',TIMESTAMP '1998-02-26 00:00:00',DATE '1998-02-03',1,52.51,'La corne d''abondance', '67,avenue de l''Europe', 'Versailles',NULL,'78000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',1,TIMESTAMP '1998-01-29 00:00:00',TIMESTAMP '1998-02-26 00:00:00',DATE '1998-02-02',2,76.10,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANR',3,TIMESTAMP '1998-01-29 00:00:00',TIMESTAMP '1998-02-26 00:00:00',DATE '1998-02-04',3,19.26,'France restauration', '54,rue Royale', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',4,TIMESTAMP '1998-01-30 00:00:00',TIMESTAMP '1998-02-27 00:00:00',DATE '1998-02-17',2,14.93,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',8,TIMESTAMP '1998-01-30 00:00:00',TIMESTAMP '1998-03-13 00:00:00',DATE '1998-02-02',2,53.23,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',4,TIMESTAMP '1998-02-02 00:00:00',TIMESTAMP '1998-03-02 00:00:00',DATE '1998-02-17',2,30.26,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',4,TIMESTAMP '1998-02-02 00:00:00',TIMESTAMP '1998-03-02 00:00:00',DATE '1998-02-09',2,3.04,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',2,TIMESTAMP '1998-02-02 00:00:00',TIMESTAMP '1998-02-16 00:00:00',DATE '1998-02-12',1,348.14,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',5,TIMESTAMP '1998-02-03 00:00:00',TIMESTAMP '1998-03-03 00:00:00',DATE '1998-02-12',1,109.11,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',6,TIMESTAMP '1998-02-03 00:00:00',TIMESTAMP '1998-03-17 00:00:00',DATE '1998-02-11',1,1.93,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',7,TIMESTAMP '1998-02-04 00:00:00',TIMESTAMP '1998-03-04 00:00:00',DATE '1998-02-23',2,191.27,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SEVES',5,TIMESTAMP '1998-02-04 00:00:00',TIMESTAMP '1998-03-04 00:00:00',DATE '1998-02-09',1,143.28,'Seven Seas Imports', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',5,TIMESTAMP '1998-02-04 00:00:00',TIMESTAMP '1998-03-04 00:00:00',DATE '1998-02-13',3,12.04,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',9,TIMESTAMP '1998-02-05 00:00:00',TIMESTAMP '1998-03-05 00:00:00',DATE '1998-02-10',2,112.27,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',5,TIMESTAMP '1998-02-05 00:00:00',TIMESTAMP '1998-03-05 00:00:00',DATE '1998-02-09',2,175.32,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',4,TIMESTAMP '1998-02-06 00:00:00',TIMESTAMP '1998-03-06 00:00:00',DATE '1998-02-09',1,0.82,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',5,TIMESTAMP '1998-02-06 00:00:00',TIMESTAMP '1998-03-06 00:00:00',DATE '1998-02-11',2,19.58,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',4,TIMESTAMP '1998-02-06 00:00:00',TIMESTAMP '1998-03-06 00:00:00',DATE '1998-03-03',2,32.37,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',7,TIMESTAMP '1998-02-09 00:00:00',TIMESTAMP '1998-03-09 00:00:00',DATE '1998-02-12',3,60.42,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',1,TIMESTAMP '1998-02-09 00:00:00',TIMESTAMP '1998-03-09 00:00:00',DATE '1998-02-19',1,38.06,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',4,TIMESTAMP '1998-02-10 00:00:00',TIMESTAMP '1998-03-10 00:00:00',DATE '1998-02-12',1,46.69,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',3,TIMESTAMP '1998-02-10 00:00:00',TIMESTAMP '1998-03-10 00:00:00',DATE '1998-02-12',3,8.50,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',7,TIMESTAMP '1998-02-10 00:00:00',TIMESTAMP '1998-03-24 00:00:00',DATE '1998-02-18',1,88.01,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',4,TIMESTAMP '1998-02-11 00:00:00',TIMESTAMP '1998-03-11 00:00:00',DATE '1998-02-18',1,2.84,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',4,TIMESTAMP '1998-02-11 00:00:00',TIMESTAMP '1998-03-11 00:00:00',DATE '1998-02-20',3,23.10,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',8,TIMESTAMP '1998-02-12 00:00:00',TIMESTAMP '1998-03-12 00:00:00',DATE '1998-02-20',3,0.53,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LETSS',4,TIMESTAMP '1998-02-12 00:00:00',TIMESTAMP '1998-03-12 00:00:00',DATE '1998-02-13',2,90.97,'Let''s Stop N Shop', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',6,TIMESTAMP '1998-02-12 00:00:00',TIMESTAMP '1998-03-12 00:00:00',DATE '1998-02-18',3,5.64,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',1,TIMESTAMP '1998-02-13 00:00:00',TIMESTAMP '1998-03-13 00:00:00',DATE '1998-03-02',1,4.99,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GALED',8,TIMESTAMP '1998-02-13 00:00:00',TIMESTAMP '1998-03-13 00:00:00',DATE '1998-02-16',3,1.25,'Galería del gastronómo', 'Rambla de Cataluña,23', 'Barcelona',NULL,'8022', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',1,TIMESTAMP '1998-02-16 00:00:00',TIMESTAMP '1998-03-16 00:00:00',DATE '1998-02-23',2,51.87,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',9,TIMESTAMP '1998-02-16 00:00:00',TIMESTAMP '1998-03-16 00:00:00',DATE '1998-02-23',3,280.61,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DUMON',7,TIMESTAMP '1998-02-16 00:00:00',TIMESTAMP '1998-03-16 00:00:00',DATE '1998-02-18',1,32.76,'Du monde entier', '67,rue des Cinquante Otages', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',7,TIMESTAMP '1998-02-17 00:00:00',TIMESTAMP '1998-03-17 00:00:00',DATE '1998-02-19',2,20.37,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',4,TIMESTAMP '1998-02-17 00:00:00',TIMESTAMP '1998-03-17 00:00:00',DATE '1998-02-19',2,120.27,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',9,TIMESTAMP '1998-02-18 00:00:00',TIMESTAMP '1998-03-18 00:00:00',DATE '1998-02-20',2,77.78,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1998-02-18 00:00:00',TIMESTAMP '1998-03-18 00:00:00',DATE '1998-02-20',1,116.13,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',3,TIMESTAMP '1998-02-18 00:00:00',TIMESTAMP '1998-03-18 00:00:00',DATE '1998-02-23',1,162.75,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',7,TIMESTAMP '1998-02-19 00:00:00',TIMESTAMP '1998-03-19 00:00:00',DATE '1998-02-27',3,32.45,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',3,TIMESTAMP '1998-02-19 00:00:00',TIMESTAMP '1998-03-19 00:00:00',DATE '1998-02-25',2,603.54,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OCEAN',4,TIMESTAMP '1998-02-20 00:00:00',TIMESTAMP '1998-03-20 00:00:00',DATE '1998-03-06',2,1.27,'Océano Atlántico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',5,TIMESTAMP '1998-02-20 00:00:00',TIMESTAMP '1998-03-20 00:00:00',DATE '1998-02-26',3,1.21,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',1,TIMESTAMP '1998-02-20 00:00:00',TIMESTAMP '1998-03-20 00:00:00',DATE '1998-03-04',2,1.66,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
               "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',4,TIMESTAMP '1998-02-23 00:00:00',TIMESTAMP '1998-03-23 00:00:00',DATE '1998-02-26',1,62.09,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',1,TIMESTAMP '1998-02-23 00:00:00',TIMESTAMP '1998-03-23 00:00:00',DATE '1998-03-03',1,44.15,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',3,TIMESTAMP '1998-02-24 00:00:00',TIMESTAMP '1998-03-24 00:00:00',DATE '1998-03-04',3,36.71,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',3,TIMESTAMP '1998-02-24 00:00:00',TIMESTAMP '1998-03-24 00:00:00',DATE '1998-02-27',3,162.95,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',9,TIMESTAMP '1998-02-24 00:00:00',TIMESTAMP '1998-03-24 00:00:00',DATE '1998-03-06',2,13.72,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',4,TIMESTAMP '1998-02-25 00:00:00',TIMESTAMP '1998-03-11 00:00:00',DATE '1998-03-03',3,26.29,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPECD',6,TIMESTAMP '1998-02-25 00:00:00',TIMESTAMP '1998-03-25 00:00:00',DATE '1998-02-27',3,9.19,'Spécialités du monde', '25,rue Lauriston', 'Paris',NULL,'75016', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',4,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-06',2,32.96,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',1,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-10',2,53.05,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',1,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-04',3,38.11,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',3,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-05',1,38.19,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',2,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-18',2,580.91,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',4,TIMESTAMP '1998-02-26 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-04',1,33.05,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',6,TIMESTAMP '1998-02-27 00:00:00',TIMESTAMP '1998-03-27 00:00:00',DATE '1998-03-02',1,21.19,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',2,TIMESTAMP '1998-02-27 00:00:00',TIMESTAMP '1998-03-27 00:00:00',DATE '1998-03-02',2,3.51,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RANCH',1,TIMESTAMP '1998-02-27 00:00:00',TIMESTAMP '1998-03-27 00:00:00',DATE '1998-03-09',2,63.77,'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ROMEY',4,TIMESTAMP '1998-03-02 00:00:00',TIMESTAMP '1998-03-30 00:00:00',DATE '1998-03-11',2,8.29,'Romero y tomillo', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',3,TIMESTAMP '1998-03-02 00:00:00',TIMESTAMP '1998-03-30 00:00:00',DATE '1998-03-11',3,48.83,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',2,TIMESTAMP '1998-03-02 00:00:00',TIMESTAMP '1998-03-30 00:00:00',DATE '1998-03-04',2,19.80,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',4,TIMESTAMP '1998-03-03 00:00:00',TIMESTAMP '1998-03-31 00:00:00',DATE '1998-03-09',2,29.61,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',1,TIMESTAMP '1998-03-03 00:00:00',TIMESTAMP '1998-04-14 00:00:00',DATE '1998-03-09',1,176.48,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',5,TIMESTAMP '1998-03-03 00:00:00',TIMESTAMP '1998-03-31 00:00:00',DATE '1998-03-05',3,62.74,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',7,TIMESTAMP '1998-03-03 00:00:00',TIMESTAMP '1998-04-14 00:00:00',DATE '1998-03-13',3,68.26,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BERGS',3,TIMESTAMP '1998-03-04 00:00:00',TIMESTAMP '1998-04-01 00:00:00',DATE '1998-04-08',2,151.52,'Berglunds snabbköp', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',3,TIMESTAMP '1998-03-04 00:00:00',TIMESTAMP '1998-04-01 00:00:00',DATE '1998-03-13',1,2.27,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ANATR',4,TIMESTAMP '1998-03-04 00:00:00',TIMESTAMP '1998-04-01 00:00:00',DATE '1998-03-11',3,39.92,'Ana Trujillo Emparedados y helados', 'Avda. de la Constitución 2222', 'México D.F.',NULL,'05021', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LACOR',4,TIMESTAMP '1998-03-05 00:00:00',TIMESTAMP '1998-04-02 00:00:00',DATE '1998-04-08',1,19.79,'La corne d''abondance', '67,avenue de l''Europe', 'Versailles',NULL,'78000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GALED',1,TIMESTAMP '1998-03-05 00:00:00',TIMESTAMP '1998-04-02 00:00:00',DATE '1998-03-18',1,1.36,'Galería del gastronómo', 'Rambla de Cataluña,23', 'Barcelona',NULL,'8022', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',6,TIMESTAMP '1998-03-05 00:00:00',TIMESTAMP '1998-04-02 00:00:00',DATE '1998-03-12',1,33.93,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',4,TIMESTAMP '1998-03-06 00:00:00',TIMESTAMP '1998-04-17 00:00:00',DATE '1998-03-18',3,15.55,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',4,TIMESTAMP '1998-03-06 00:00:00',TIMESTAMP '1998-03-20 00:00:00',DATE '1998-03-19',2,13.60,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',8,TIMESTAMP '1998-03-06 00:00:00',TIMESTAMP '1998-04-03 00:00:00',DATE '1998-03-24',1,134.64,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ISLAT',6,TIMESTAMP '1998-03-06 00:00:00',TIMESTAMP '1998-04-03 00:00:00',DATE '1998-03-16',3,54.15,'Island Trading', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',3,TIMESTAMP '1998-03-09 00:00:00',TIMESTAMP '1998-04-06 00:00:00',DATE '1998-03-12',3,32.01,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WELLI',4,TIMESTAMP '1998-03-09 00:00:00',TIMESTAMP '1998-04-06 00:00:00',DATE '1998-03-18',3,47.59,'Wellington Importadora', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',3,TIMESTAMP '1998-03-09 00:00:00',TIMESTAMP '1998-04-06 00:00:00',DATE '1998-03-18',2,33.68,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',7,TIMESTAMP '1998-03-10 00:00:00',TIMESTAMP '1998-03-24 00:00:00',DATE '1998-03-13',3,31.51,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',3,TIMESTAMP '1998-03-10 00:00:00',TIMESTAMP '1998-04-07 00:00:00',DATE '1998-03-16',2,31.89,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',2,TIMESTAMP '1998-03-10 00:00:00',TIMESTAMP '1998-04-07 00:00:00',DATE '1998-03-13',2,76.33,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',8,TIMESTAMP '1998-03-11 00:00:00',TIMESTAMP '1998-04-08 00:00:00',DATE '1998-03-23',3,19.77,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',7,TIMESTAMP '1998-03-11 00:00:00',TIMESTAMP '1998-04-08 00:00:00',DATE '1998-03-20',2,400.81,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',9,TIMESTAMP '1998-03-11 00:00:00',TIMESTAMP '1998-04-08 00:00:00',DATE '1998-03-18',3,17.95,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',4,TIMESTAMP '1998-03-11 00:00:00',TIMESTAMP '1998-04-08 00:00:00',DATE '1998-03-19',2,2.17,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',6,TIMESTAMP '1998-03-12 00:00:00',TIMESTAMP '1998-03-26 00:00:00',DATE '1998-03-13',3,52.92,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MORGK',4,TIMESTAMP '1998-03-12 00:00:00',TIMESTAMP '1998-04-09 00:00:00',DATE '1998-03-18',1,10.22,'Morgenstern Gesundkost', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',1,TIMESTAMP '1998-03-12 00:00:00',TIMESTAMP '1998-04-09 00:00:00',DATE '1998-03-19',2,27.20,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',3,TIMESTAMP '1998-03-13 00:00:00',TIMESTAMP '1998-04-10 00:00:00',DATE '1998-03-16',2,3.26,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',3,TIMESTAMP '1998-03-13 00:00:00',TIMESTAMP '1998-04-10 00:00:00',DATE '1998-03-19',3,23.39,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',2,TIMESTAMP '1998-03-13 00:00:00',TIMESTAMP '1998-04-10 00:00:00',DATE '1998-03-17',3,74.44,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAGAA',1,TIMESTAMP '1998-03-16 00:00:00',TIMESTAMP '1998-04-13 00:00:00',DATE '1998-03-23',2,2.50,'Magazzini Alimentari Riuniti', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',9,TIMESTAMP '1998-03-16 00:00:00',TIMESTAMP '1998-04-27 00:00:00',DATE '1998-04-07',2,30.85,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',1,TIMESTAMP '1998-03-16 00:00:00',TIMESTAMP '1998-04-27 00:00:00',DATE '1998-03-24',1,40.42,'Alfred''s Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',9,TIMESTAMP '1998-03-16 00:00:00',TIMESTAMP '1998-03-30 00:00:00',DATE '1998-03-25',2,23.72,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',5,TIMESTAMP '1998-03-17 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-03-20',1,27.91,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1998-03-17 00:00:00',TIMESTAMP '1998-04-14 00:00:00',DATE '1998-03-20',2,3.26,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',6,TIMESTAMP '1998-03-17 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-03-20',2,44.65,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',8,TIMESTAMP '1998-03-18 00:00:00',TIMESTAMP '1998-04-15 00:00:00',DATE '1998-03-27',3,105.36,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OCEAN',7,TIMESTAMP '1998-03-18 00:00:00',TIMESTAMP '1998-04-15 00:00:00',DATE '1998-03-27',2,49.56,'Océano Atlántico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',6,TIMESTAMP '1998-03-18 00:00:00',TIMESTAMP '1998-04-29 00:00:00',DATE '1998-03-23',2,4.98,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',3,TIMESTAMP '1998-03-19 00:00:00',TIMESTAMP '1998-04-02 00:00:00',DATE '1998-04-08',1,2.08,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',8,TIMESTAMP '1998-03-19 00:00:00',TIMESTAMP '1998-04-16 00:00:00',DATE '1998-03-30',1,104.47,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',8,TIMESTAMP '1998-03-19 00:00:00',TIMESTAMP '1998-04-16 00:00:00',DATE '1998-03-23',2,275.79,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FURIB',9,TIMESTAMP '1998-03-19 00:00:00',TIMESTAMP '1998-04-16 00:00:00',DATE '1998-03-26',3,2.70,'Furia Bacalhau e Frutos do Mar', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPECD',3,TIMESTAMP '1998-03-20 00:00:00',TIMESTAMP '1998-04-17 00:00:00',DATE '1998-03-24',2,87.38,'Spécialités du monde', '25,rue Lauriston', 'Paris',NULL,'75016', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',6,TIMESTAMP '1998-03-20 00:00:00',TIMESTAMP '1998-04-17 00:00:00',DATE '1998-03-30',3,144.38,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',4,TIMESTAMP '1998-03-20 00:00:00',TIMESTAMP '1998-04-17 00:00:00',DATE '1998-04-08',1,27.19,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TOMSP',2,TIMESTAMP '1998-03-23 00:00:00',TIMESTAMP '1998-04-20 00:00:00',DATE '1998-04-02',2,62.22,'Toms Spezialitäten', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',1,TIMESTAMP '1998-03-23 00:00:00',TIMESTAMP '1998-04-20 00:00:00',DATE '1998-04-01',3,74.60,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('COMMI',1,TIMESTAMP '1998-03-23 00:00:00',TIMESTAMP '1998-04-20 00:00:00',DATE '1998-03-30',2,0.21,'Comércio Mineiro', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOLID',9,TIMESTAMP '1998-03-24 00:00:00',TIMESTAMP '1998-04-07 00:00:00',DATE '1998-04-24',1,16.16,'Bólido Comidas preparadas', 'C/ Araquil,67', 'Madrid',NULL,'28023', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANR',2,TIMESTAMP '1998-03-24 00:00:00',TIMESTAMP '1998-04-21 00:00:00',DATE '1998-04-02',2,121.82,'France restauration', '54,rue Royale', 'Nantes',NULL,'44000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LACOR',4,TIMESTAMP '1998-03-24 00:00:00',TIMESTAMP '1998-04-21 00:00:00',DATE '1998-03-26',2,0.02,'La corne d''abondance', '67,avenue de l''Europe', 'Versailles',NULL,'78000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LACOR',6,TIMESTAMP '1998-03-24 00:00:00',TIMESTAMP '1998-04-21 00:00:00',DATE '1998-03-27',2,15.17,'La corne d''abondance', '67,avenue de l''Europe', 'Versailles',NULL,'78000', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPLIR',3,TIMESTAMP '1998-03-25 00:00:00',TIMESTAMP '1998-04-08 00:00:00',DATE '1998-04-03',3,12.96,'Split Rail Beer & Ale', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',1,TIMESTAMP '1998-03-25 00:00:00',TIMESTAMP '1998-04-22 00:00:00',DATE '1998-03-27',3,32.27,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',1,TIMESTAMP '1998-03-25 00:00:00',TIMESTAMP '1998-05-06 00:00:00',DATE '1998-04-03',1,37.97,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1998-03-26 00:00:00',TIMESTAMP '1998-04-23 00:00:00',DATE '1998-04-10',3,208.50,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',9,TIMESTAMP '1998-03-26 00:00:00',TIMESTAMP '1998-04-23 00:00:00',DATE '1998-04-23',2,32.82,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',8,TIMESTAMP '1998-03-26 00:00:00',TIMESTAMP '1998-04-23 00:00:00',DATE '1998-03-31',2,353.07,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',4,TIMESTAMP '1998-03-27 00:00:00',TIMESTAMP '1998-05-08 00:00:00',DATE '1998-04-17',1,1.26,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',1,TIMESTAMP '1998-03-27 00:00:00',TIMESTAMP '1998-04-24 00:00:00',DATE '1998-04-02',2,193.37,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',2,TIMESTAMP '1998-03-27 00:00:00',TIMESTAMP '1998-04-24 00:00:00',DATE '1998-04-08',1,14.01,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',2,TIMESTAMP '1998-03-27 00:00:00',TIMESTAMP '1998-04-24 00:00:00',DATE '1998-04-06',2,657.54,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1998-03-30 00:00:00',TIMESTAMP '1998-04-27 00:00:00',DATE '1998-04-03',3,211.22,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',2,TIMESTAMP '1998-03-30 00:00:00',TIMESTAMP '1998-04-27 00:00:00',DATE '1998-04-02',1,91.51,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OCEAN',8,TIMESTAMP '1998-03-30 00:00:00',TIMESTAMP '1998-04-27 00:00:00',DATE '1998-04-21',2,217.86,'Océano Atlántico Ltda.', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',8,TIMESTAMP '1998-03-31 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-04-06',1,185.48,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',3,TIMESTAMP '1998-03-31 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-04-10',2,61.14,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEDE',2,TIMESTAMP '1998-03-31 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-04-02',1,34.76,'Que Delícia', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',2,TIMESTAMP '1998-04-01 00:00:00',TIMESTAMP '1998-05-13 00:00:00',DATE '1998-04-07',3,117.61,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',1,TIMESTAMP '1998-04-01 00:00:00',TIMESTAMP '1998-04-29 00:00:00',DATE '1998-04-07',1,38.51,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THEBI',1,TIMESTAMP '1998-04-01 00:00:00',TIMESTAMP '1998-04-29 00:00:00',DATE '1998-04-03',3,4.27,'The Big Cheese', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',7,TIMESTAMP '1998-04-01 00:00:00',TIMESTAMP '1998-04-29 00:00:00',DATE '1998-04-10',3,8.81,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('VAFFE',2,TIMESTAMP '1998-04-02 00:00:00',TIMESTAMP '1998-04-16 00:00:00',DATE '1998-04-09',3,65.53,'Vaffeljernet', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',1,TIMESTAMP '1998-04-02 00:00:00',TIMESTAMP '1998-04-30 00:00:00',DATE '1998-04-06',3,46.00,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',4,TIMESTAMP '1998-04-02 00:00:00',TIMESTAMP '1998-04-30 00:00:00',DATE '1998-04-10',2,1.12,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',8,TIMESTAMP '1998-04-03 00:00:00',TIMESTAMP '1998-05-15 00:00:00',DATE '1998-04-13',2,73.91,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',8,TIMESTAMP '1998-04-03 00:00:00',TIMESTAMP '1998-04-17 00:00:00',DATE '1998-04-17',2,20.31,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',6,TIMESTAMP '1998-04-03 00:00:00',TIMESTAMP '1998-05-01 00:00:00',DATE '1998-04-10',2,96.35,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',2,TIMESTAMP '1998-04-06 00:00:00',TIMESTAMP '1998-05-04 00:00:00',DATE '1998-04-14',3,55.12,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',2,TIMESTAMP '1998-04-06 00:00:00',TIMESTAMP '1998-05-04 00:00:00',DATE '1998-04-14',2,197.30,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',4,TIMESTAMP '1998-04-06 00:00:00',TIMESTAMP '1998-05-04 00:00:00',DATE '1998-04-16',1,141.16,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
               "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('THECR',3,TIMESTAMP '1998-04-06 00:00:00',TIMESTAMP '1998-05-04 00:00:00',DATE '1998-04-08',3,14.91,'The Cracker Box', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('MAISD',3,TIMESTAMP '1998-04-07 00:00:00',TIMESTAMP '1998-05-05 00:00:00',DATE '1998-04-20',1,44.84,'Maison Dewey', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WILMK',2,TIMESTAMP '1998-04-07 00:00:00',TIMESTAMP '1998-05-05 00:00:00',DATE '1998-04-10',1,0.75,'Wilman Kala', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',3,TIMESTAMP '1998-04-07 00:00:00',TIMESTAMP '1998-05-05 00:00:00',DATE '1998-04-15',2,25.19,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PRINI',8,TIMESTAMP '1998-04-08 00:00:00',TIMESTAMP '1998-05-06 00:00:00',DATE '1998-04-13',2,202.24,'Princesa Isabel Vinhos', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',7,TIMESTAMP '1998-04-08 00:00:00',TIMESTAMP '1998-05-06 00:00:00',NULL,3,79.46,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',2,TIMESTAMP '1998-04-08 00:00:00',TIMESTAMP '1998-05-06 00:00:00',DATE '1998-04-10',1,59.11,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',2,TIMESTAMP '1998-04-09 00:00:00',TIMESTAMP '1998-05-07 00:00:00',DATE '1998-04-21',2,28.71,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ALFKI',3,TIMESTAMP '1998-04-09 00:00:00',TIMESTAMP '1998-05-07 00:00:00',DATE '1998-04-13',1,1.21,'Alfred''s Futterkiste', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANK',1,TIMESTAMP '1998-04-09 00:00:00',TIMESTAMP '1998-04-23 00:00:00',DATE '1998-04-17',3,242.95,'Frankenversand', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ROMEY',2,TIMESTAMP '1998-04-09 00:00:00',TIMESTAMP '1998-05-07 00:00:00',DATE '1998-04-10',1,32.99,'Romero y tomillo', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',2,TIMESTAMP '1998-04-10 00:00:00',TIMESTAMP '1998-05-08 00:00:00',DATE '1998-04-15',3,23.60,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SANTG',2,TIMESTAMP '1998-04-10 00:00:00',TIMESTAMP '1998-04-24 00:00:00',DATE '1998-04-20',2,4.62,'Santé Gourmet', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('AROUT',9,TIMESTAMP '1998-04-10 00:00:00',TIMESTAMP '1998-05-08 00:00:00',DATE '1998-04-13',2,33.80,'Around the Horn', 'Brook Farm Stratford St. Mary', 'Colchester', 'Essex', 'CO7 6JX', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',9,TIMESTAMP '1998-04-13 00:00:00',TIMESTAMP '1998-05-11 00:00:00',DATE '1998-04-20',2,754.26,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LONEP',4,TIMESTAMP '1998-04-13 00:00:00',TIMESTAMP '1998-05-11 00:00:00',DATE '1998-04-16',2,11.65,'Lonesome Pine Restaurant', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RANCH',6,TIMESTAMP '1998-04-13 00:00:00',TIMESTAMP '1998-05-11 00:00:00',NULL,3,3.17,'Rancho grande', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OTTIK',2,TIMESTAMP '1998-04-14 00:00:00',TIMESTAMP '1998-05-12 00:00:00',DATE '1998-04-16',2,43.30,'Ottilies Käseladen', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUICK',3,TIMESTAMP '1998-04-14 00:00:00',TIMESTAMP '1998-05-12 00:00:00',DATE '1998-04-21',1,297.18,'QUICK-Stop', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',9,TIMESTAMP '1998-04-14 00:00:00',TIMESTAMP '1998-05-12 00:00:00',DATE '1998-05-04',2,6.27,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BSBEV',1,TIMESTAMP '1998-04-14 00:00:00',TIMESTAMP '1998-04-28 00:00:00',DATE '1998-04-24',2,123.83,'B''s Beverages', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',4,TIMESTAMP '1998-04-15 00:00:00',TIMESTAMP '1998-05-13 00:00:00',DATE '1998-04-20',1,74.36,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WARTH',6,TIMESTAMP '1998-04-15 00:00:00',TIMESTAMP '1998-05-13 00:00:00',DATE '1998-04-24',3,29.17,'Wartian Herkku', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',4,TIMESTAMP '1998-04-15 00:00:00',TIMESTAMP '1998-05-13 00:00:00',DATE '1998-04-28',1,47.09,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',1,TIMESTAMP '1998-04-16 00:00:00',TIMESTAMP '1998-05-14 00:00:00',DATE '1998-04-20',1,52.52,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('KOENE',2,TIMESTAMP '1998-04-16 00:00:00',TIMESTAMP '1998-05-14 00:00:00',DATE '1998-04-22',1,29.59,'Königlich Essen', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',4,TIMESTAMP '1998-04-16 00:00:00',TIMESTAMP '1998-05-14 00:00:00',DATE '1998-04-27',1,47.84,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',7,TIMESTAMP '1998-04-17 00:00:00',TIMESTAMP '1998-05-15 00:00:00',DATE '1998-04-27',2,830.75,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',6,TIMESTAMP '1998-04-17 00:00:00',TIMESTAMP '1998-05-15 00:00:00',DATE '1998-04-24',2,227.22,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',2,TIMESTAMP '1998-04-17 00:00:00',TIMESTAMP '1998-05-15 00:00:00',DATE '1998-04-23',3,606.19,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',7,TIMESTAMP '1998-04-17 00:00:00',TIMESTAMP '1998-05-15 00:00:00',DATE '1998-04-23',3,84.74,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('OLDWO',8,TIMESTAMP '1998-04-20 00:00:00',TIMESTAMP '1998-06-01 00:00:00',DATE '1998-04-27',1,40.32,'Old World Delicatessen', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',2,TIMESTAMP '1998-04-20 00:00:00',TIMESTAMP '1998-05-18 00:00:00',DATE '1998-04-24',2,0.17,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',8,TIMESTAMP '1998-04-20 00:00:00',TIMESTAMP '1998-05-18 00:00:00',DATE '1998-04-22',3,149.47,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GODOS',7,TIMESTAMP '1998-04-21 00:00:00',TIMESTAMP '1998-05-19 00:00:00',DATE '1998-04-27',1,3.20,'Godos Cocina Típica', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SUPRD',1,TIMESTAMP '1998-04-21 00:00:00',TIMESTAMP '1998-05-19 00:00:00',DATE '1998-04-30',2,29.59,'Suprêmes délices', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LINOD',1,TIMESTAMP '1998-04-21 00:00:00',TIMESTAMP '1998-05-19 00:00:00',NULL,2,65.00,'LINO-Delicateses', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',4,TIMESTAMP '1998-04-22 00:00:00',TIMESTAMP '1998-05-20 00:00:00',NULL,3,18.84,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CHOPS',3,TIMESTAMP '1998-04-22 00:00:00',TIMESTAMP '1998-05-20 00:00:00',DATE '1998-04-28',2,48.22,'Chop-suey Chinese', 'Hauptstr. 31', 'Bern',NULL,'3012', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('COMMI',2,TIMESTAMP '1998-04-22 00:00:00',TIMESTAMP '1998-05-06 00:00:00',DATE '1998-05-01',1,29.99,'Comércio Mineiro', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SPECD',5,TIMESTAMP '1998-04-22 00:00:00',TIMESTAMP '1998-05-20 00:00:00',DATE '1998-04-29',2,8.80,'Spécialités du monde', '25,rue Lauriston', 'Paris',NULL,'75016', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WOLZA',4,TIMESTAMP '1998-04-23 00:00:00',TIMESTAMP '1998-05-21 00:00:00',DATE '1998-05-01',1,8.72,'Wolski Zajazd', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',6,TIMESTAMP '1998-04-23 00:00:00',TIMESTAMP '1998-05-21 00:00:00',NULL,2,70.58,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WANDK',8,TIMESTAMP '1998-04-23 00:00:00',TIMESTAMP '1998-05-21 00:00:00',DATE '1998-04-24',2,71.64,'Die Wandernde Kuh', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',7,TIMESTAMP '1998-04-24 00:00:00',TIMESTAMP '1998-05-22 00:00:00',DATE '1998-05-01',3,46.62,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BOTTM',7,TIMESTAMP '1998-04-24 00:00:00',TIMESTAMP '1998-05-22 00:00:00',DATE '1998-04-30',3,24.12,'Bottom-Dollar Markets', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GOURL',3,TIMESTAMP '1998-04-24 00:00:00',TIMESTAMP '1998-05-22 00:00:00',DATE '1998-05-04',1,8.34,'Gourmet Lanchonetes', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FOLKO',8,TIMESTAMP '1998-04-27 00:00:00',TIMESTAMP '1998-05-25 00:00:00',DATE '1998-05-05',2,59.41,'Folk och fä HB', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LAMAI',7,TIMESTAMP '1998-04-27 00:00:00',TIMESTAMP '1998-05-25 00:00:00',NULL,3,2.79,'La maison d''Asie', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HANAR',3,TIMESTAMP '1998-04-27 00:00:00',TIMESTAMP '1998-05-25 00:00:00',DATE '1998-05-01',1,67.26,'Hanari Carnes', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PICCO',2,TIMESTAMP '1998-04-27 00:00:00',TIMESTAMP '1998-05-25 00:00:00',DATE '1998-04-29',2,53.05,'Piccolo und mehr', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('CACTU',8,TIMESTAMP '1998-04-28 00:00:00',TIMESTAMP '1998-05-26 00:00:00',NULL,1,0.33,'Cactus Comidas para llevar', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HILAA',7,TIMESTAMP '1998-04-28 00:00:00',TIMESTAMP '1998-05-26 00:00:00',DATE '1998-05-05',2,120.92,'HILARION-Abastos', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('EASTC',8,TIMESTAMP '1998-04-28 00:00:00',TIMESTAMP '1998-05-12 00:00:00',DATE '1998-05-01',2,278.96,'Eastern Connection', '35 King George', 'London',NULL,'WX3 6FW', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('NORTS',3,TIMESTAMP '1998-04-29 00:00:00',TIMESTAMP '1998-05-27 00:00:00',DATE '1998-05-01',3,4.13,'North/South', 'South House 300 Queensbridge', 'London',NULL,'SW7 1RZ', 'UK'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BLAUS',9,TIMESTAMP '1998-04-29 00:00:00',TIMESTAMP '1998-05-27 00:00:00',NULL,3,31.14,'Blauer See Delikatessen', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICAR',2,TIMESTAMP '1998-04-29 00:00:00',TIMESTAMP '1998-06-10 00:00:00',NULL,2,85.80,'Ricardo Adocicados', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('FRANS',2,TIMESTAMP '1998-04-30 00:00:00',TIMESTAMP '1998-05-28 00:00:00',DATE '1998-05-04',2,10.98,'Franchi S.p.A.', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('GREAL',4,TIMESTAMP '1998-04-30 00:00:00',TIMESTAMP '1998-06-11 00:00:00',NULL,3,14.01,'Great Lakes Food Market', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('REGGC',4,TIMESTAMP '1998-04-30 00:00:00',TIMESTAMP '1998-05-28 00:00:00',NULL,2,29.93,'Reggiani Caseifici', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('HUNGO',3,TIMESTAMP '1998-04-30 00:00:00',TIMESTAMP '1998-05-28 00:00:00',DATE '1998-05-06',2,81.73,'Hungry Owl All-Night Grocers', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SAVEA',1,TIMESTAMP '1998-05-01 00:00:00',TIMESTAMP '1998-05-29 00:00:00',DATE '1998-05-04',1,30.09,'Save-a-lot Markets', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',8,TIMESTAMP '1998-05-01 00:00:00',TIMESTAMP '1998-05-29 00:00:00',NULL,1,12.91,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('WHITC',7,TIMESTAMP '1998-05-01 00:00:00',TIMESTAMP '1998-05-29 00:00:00',DATE '1998-05-04',2,44.72,'White Clover Markets', '1029 - 12th Ave. S.', 'Seattle', 'WA', '98124', 'USA'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('DRACD',1,TIMESTAMP '1998-05-04 00:00:00',TIMESTAMP '1998-05-18 00:00:00',DATE '1998-05-06',2,7.98,'Drachenblut Delikatessen', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('QUEEN',8,TIMESTAMP '1998-05-04 00:00:00',TIMESTAMP '1998-06-01 00:00:00',NULL,2,81.75,'Queen Cozinha', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('TORTU',1,TIMESTAMP '1998-05-04 00:00:00',TIMESTAMP '1998-06-01 00:00:00',DATE '1998-05-06',2,15.67,'Tortuga Restaurante', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LEHMS',2,TIMESTAMP '1998-05-05 00:00:00',TIMESTAMP '1998-06-02 00:00:00',NULL,1,136.00,'Lehmanns Marktstand', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('LILAS',1,TIMESTAMP '1998-05-05 00:00:00',TIMESTAMP '1998-06-02 00:00:00',NULL,1,0.93,'LILA-Supermercado', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('ERNSH',4,TIMESTAMP '1998-05-05 00:00:00',TIMESTAMP '1998-06-02 00:00:00',NULL,2,258.64,'Ernst Handel', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('PERIC',2,TIMESTAMP '1998-05-05 00:00:00',TIMESTAMP '1998-06-02 00:00:00',NULL,2,24.95,'Pericles Comidas clásicas', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('SIMOB',7,TIMESTAMP '1998-05-06 00:00:00',TIMESTAMP '1998-06-03 00:00:00',NULL,2,18.44,'Simons bistro', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RICSU',8,TIMESTAMP '1998-05-06 00:00:00',TIMESTAMP '1998-06-03 00:00:00',NULL,2,6.19,'Richter Supermarkt', 'Starenweg 5', 'Genève',NULL,'1204', 'Switzerland'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('BONAP',4,TIMESTAMP '1998-05-06 00:00:00',TIMESTAMP '1998-06-03 00:00:00',NULL,2,38.28,'Bon app''', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France'); " +
                "INSERT INTO Orders (CustomerID,EmployeeID,OrderDate,RequiredDate,ShippedDate,ShipVia,Freight,ShipName,ShipAddress,ShipCity,ShipRegion,ShipPostalCode,ShipCountry) VALUES ('RATTC',1,TIMESTAMP '1998-05-06 00:00:00',TIMESTAMP '1998-06-03 00:00:00',NULL,2,8.53,'Rattlesnake Canyon Grocery', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA'); ";
            cmd.ExecuteNonQuery();

        }

        static private void LoadCustomers(TdCommand cmd)
        {
            cmd.CommandText =
                    "INSERT INTO Customers VALUES('ALFKI', 'Alfreds Futterkiste', 'Maria Anders', 'Sales Representative', 'Obere Str. 57', 'Berlin',NULL,'12209', 'Germany', '030-0074321', '030-0076545'); " +
                    "INSERT INTO Customers VALUES('ANATR', 'Ana Trujillo Emparedados y helados', 'Ana Trujillo', 'Owner', 'Avda. de la Constitución 2222', 'México D.F.',NULL,'05021', 'Mexico', '(5) 555-4729', '(5) 555-3745'); " +
                    "INSERT INTO Customers VALUES('ANTON', 'Antonio Moreno Taquería', 'Antonio Moreno', 'Owner', 'Mataderos 2312', 'México D.F.',NULL,'05023', 'Mexico', '(5) 555-3932',NULL); " +
                    "INSERT INTO Customers VALUES('AROUT', 'Around the Horn', 'Thomas Hardy', 'Sales Representative', '120 Hanover Sq.', 'London',NULL,'WA1 1DP', 'UK', '(171) 555-7788', '(171) 555-6750'); " +
                    "INSERT INTO Customers VALUES('BERGS', 'Berglunds snabbköp', 'Christina Berglund', 'Order Administrator', 'Berguvsvägen 8', 'Luleå',NULL,'S-958 22', 'Sweden', '0921-12 34 65', '0921-12 34 67'); " +
                    "INSERT INTO Customers VALUES('BLAUS', 'Blauer See Delikatessen', 'Hanna Moos', 'Sales Representative', 'Forsterstr. 57', 'Mannheim',NULL,'68306', 'Germany', '0621-08460', '0621-08924'); " +
                    "INSERT INTO Customers VALUES('BLONP', 'Blondesddsl père et fils', 'Frédérique Citeaux', 'Marketing Manager', '24,place Kléber', 'Strasbourg',NULL,'67000', 'France', '88.60.15.31', '88.60.15.32'); " +
                    "INSERT INTO Customers VALUES('BOLID', 'Bólido Comidas preparadas', 'Martín Sommer', 'Owner', 'C/ Araquil,67', 'Madrid',NULL,'28023', 'Spain', '(91) 555 22 82', '(91) 555 91 99'); " +
                    "INSERT INTO Customers VALUES('BONAP', 'Bon app''', 'Laurence Lebihan', 'Owner', '12,rue des Bouchers', 'Marseille',NULL,'13008', 'France', '91.24.45.40', '91.24.45.41'); " +
                    "INSERT INTO Customers VALUES('BOTTM', 'Bottom-Dollar Markets', 'Elizabeth Lincoln', 'Accounting Manager', '23 Tsawassen Blvd.', 'Tsawassen', 'BC', 'T2F 8M4', 'Canada', '(604) 555-4729', '(604) 555-3745'); " +
                    "INSERT INTO Customers VALUES('BSBEV', 'B''s Beverages', 'Victoria Ashworth', 'Sales Representative', 'Fauntleroy Circus', 'London',NULL,'EC2 5NT', 'UK', '(171) 555-1212',NULL); " +
                    "INSERT INTO Customers VALUES('CACTU', 'Cactus Comidas para llevar', 'Patricio Simpson', 'Sales Agent', 'Cerrito 333', 'Buenos Aires',NULL,'1010', 'Argentina', '(1) 135-5555', '(1) 135-4892'); " +
                    "INSERT INTO Customers VALUES('CENTC', 'Centro comercial Moctezuma', 'Francisco Chang', 'Marketing Manager', 'Sierras de Granada 9993', 'México D.F.',NULL,'05022', 'Mexico', '(5) 555-3392', '(5) 555-7293'); " +
                    "INSERT INTO Customers VALUES('CHOPS', 'Chop-suey Chinese', 'Yang Wang', 'Owner', 'Hauptstr. 29', 'Bern',NULL,'3012', 'Switzerland', '0452-076545',NULL); " +
                    "INSERT INTO Customers VALUES('COMMI', 'Comércio Mineiro', 'Pedro Afonso', 'Sales Associate', 'Av. dos Lusíadas,23', 'Sao Paulo', 'SP', '05432-043', 'Brazil', '(11) 555-7647',NULL); " +
                    "INSERT INTO Customers VALUES('CONSH', 'Consolidated Holdings', 'Elizabeth Brown', 'Sales Representative', 'Berkeley Gardens 12 Brewery', 'London',NULL,'WX1 6LT', 'UK', '(171) 555-2282', '(171) 555-9199'); " +
                    "INSERT INTO Customers VALUES('DRACD', 'Drachenblut Delikatessen', 'Sven Ottlieb', 'Order Administrator', 'Walserweg 21', 'Aachen',NULL,'52066', 'Germany', '0241-039123', '0241-059428'); " +
                    "INSERT INTO Customers VALUES('DUMON', 'Du monde entier', 'Janine Labrune', 'Owner', '67,rue des Cinquante Otages', 'Nantes',NULL,'44000', 'France', '40.67.88.88', '40.67.89.89'); " +
                    "INSERT INTO Customers VALUES('EASTC', 'Eastern Connection', 'Ann Devon', 'Sales Agent', '35 King George', 'London',NULL,'WX3 6FW', 'UK', '(171) 555-0297', '(171) 555-3373'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO Customers VALUES('ERNSH', 'Ernst Handel', 'Roland Mendel', 'Sales Manager', 'Kirchgasse 6', 'Graz',NULL,'8010', 'Austria', '7675-3425', '7675-3426'); " +
                    "INSERT INTO Customers VALUES('FAMIA', 'Familia Arquibaldo', 'Aria Cruz', 'Marketing Assistant', 'Rua Orós,92', 'Sao Paulo', 'SP', '05442-030', 'Brazil', '(11) 555-9857',NULL); " +
                    "INSERT INTO Customers VALUES('FISSA', 'FISSA Fabrica Inter. Salchichas S.A.', 'Diego Roel', 'Accounting Manager', 'C/ Moralzarzal,86', 'Madrid',NULL,'28034', 'Spain', '(91) 555 94 44', '(91) 555 55 93'); " +
                    "INSERT INTO Customers VALUES('FOLIG', 'Folies gourmandes', 'Martine Rancé', 'Assistant Sales Agent', '184,chaussée de Tournai', 'Lille',NULL,'59000', 'France', '20.16.10.16', '20.16.10.17'); " +
                    "INSERT INTO Customers VALUES('FOLKO', 'Folk och fä HB', 'Maria Larsson', 'Owner', 'Åkergatan 24', 'Bräcke',NULL,'S-844 67', 'Sweden', '0695-34 67 21',NULL); " +
                    "INSERT INTO Customers VALUES('FRANK', 'Frankenversand', 'Peter Franken', 'Marketing Manager', 'Berliner Platz 43', 'München',NULL,'80805', 'Germany', '089-0877310', '089-0877451'); " +
                    "INSERT INTO Customers VALUES('FRANR', 'France restauration', 'Carine Schmitt', 'Marketing Manager', '54,rue Royale', 'Nantes',NULL,'44000', 'France', '40.32.21.21', '40.32.21.20'); " +
                    "INSERT INTO Customers VALUES('FRANS', 'Franchi S.p.A.', 'Paolo Accorti', 'Sales Representative', 'Via Monte Bianco 34', 'Torino',NULL,'10100', 'Italy', '011-4988260', '011-4988261'); " +
                    "INSERT INTO Customers VALUES('FURIB', 'Furia Bacalhau e Frutos do Mar', 'Lino Rodriguez', 'Sales Manager', 'Jardim das rosas n. 32', 'Lisboa',NULL,'1675', 'Portugal', '(1) 354-2534', '(1) 354-2535'); " +
                    "INSERT INTO Customers VALUES('GALED', 'Galería del gastrónomo', 'Eduardo Saavedra', 'Marketing Manager', 'Rambla de Cataluña,23', 'Barcelona',NULL,'08022', 'Spain', '(93) 203 4560', '(93) 203 4561'); " +
                    "INSERT INTO Customers VALUES('GODOS', 'Godos Cocina Típica', 'José Pedro Freyre', 'Sales Manager', 'C/ Romero,33', 'Sevilla',NULL,'41101', 'Spain', '(95) 555 82 82',NULL); " +
                    "INSERT INTO Customers VALUES('GOURL', 'Gourmet Lanchonetes', 'André Fonseca', 'Sales Associate', 'Av. Brasil,442', 'Campinas', 'SP', '04876-786', 'Brazil', '(11) 555-9482',NULL); " +
                    "INSERT INTO Customers VALUES('GREAL', 'Great Lakes Food Market', 'Howard Snyder', 'Marketing Manager', '2732 Baker Blvd.', 'Eugene', 'OR', '97403', 'USA', '(503) 555-7555',NULL); " +
                    "INSERT INTO Customers VALUES('GROSR', 'GROSELLA-Restaurante', 'Manuel Pereira', 'Owner', '5ª Ave. Los Palos Grandes', 'Caracas', 'DF', '1081', 'Venezuela', '(2) 283-2951', '(2) 283-3397'); " +
                    "INSERT INTO Customers VALUES('HANAR', 'Hanari Carnes', 'Mario Pontes', 'Accounting Manager', 'Rua do Paço,67', 'Rio de Janeiro', 'RJ', '05454-876', 'Brazil', '(21) 555-0091', '(21) 555-8765'); " +
                    "INSERT INTO Customers VALUES('HILAA', 'HILARION-Abastos', 'Carlos Hernández', 'Sales Representative', 'Carrera 22 con Ave. Carlos Soublette #8-35', 'San Cristóbal', 'Táchira', '5022', 'Venezuela', '(5) 555-1340', '(5) 555-1948'); " +
                    "INSERT INTO Customers VALUES('HUNGC', 'Hungry Coyote Import Store', 'Yoshi Latimer', 'Sales Representative', 'City Center Plaza 516 Main St.', 'Elgin', 'OR', '97827', 'USA', '(503) 555-6874', '(503) 555-2376'); " +
                    "INSERT INTO Customers VALUES('HUNGO', 'Hungry Owl All-Night Grocers', 'Patricia McKenna', 'Sales Associate', '8 Johnstown Road', 'Cork', 'Co. Cork',NULL,'Ireland', '2967 542', '2967 3333'); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO Customers VALUES('ISLAT', 'Island Trading', 'Helen Bennett', 'Marketing Manager', 'Garden House Crowther Way', 'Cowes', 'Isle of Wight', 'PO31 7PJ', 'UK', '(198) 555-8888',NULL); " +
                    "INSERT INTO Customers VALUES('KOENE', 'Königlich Essen', 'Philip Cramer', 'Sales Associate', 'Maubelstr. 90', 'Brandenburg',NULL,'14776', 'Germany', '0555-09876',NULL); " +
                    "INSERT INTO Customers VALUES('LACOR', 'La corne d''abondance', 'Daniel Tonini', 'Sales Representative', '67,avenue de l''Europe', 'Versailles',NULL,'78000', 'France', '30.59.84.10', '30.59.85.11'); " +
                    "INSERT INTO Customers VALUES('LAMAI', 'La maison d''Asie', 'Annette Roulet', 'Sales Manager', '1 rue Alsace-Lorraine', 'Toulouse',NULL,'31000', 'France', '61.77.61.10', '61.77.61.11'); " +
                    "INSERT INTO Customers VALUES('LAUGB', 'Laughing Bacchus Wine Cellars', 'Yoshi Tannamuri', 'Marketing Assistant', '1900 Oak St.', 'Vancouver', 'BC', 'V3F 2K1', 'Canada', '(604) 555-3392', '(604) 555-7293'); " +
                    "INSERT INTO Customers VALUES('LAZYK', 'Lazy K Kountry Store', 'John Steel', 'Marketing Manager', '12 Orchestra Terrace', 'Walla Walla', 'WA', '99362', 'USA', '(509) 555-7969', '(509) 555-6221'); " +
                    "INSERT INTO Customers VALUES('LEHMS', 'Lehmanns Marktstand', 'Renate Messner', 'Sales Representative', 'Magazinweg 7', 'Frankfurt a.M.',NULL,'60528', 'Germany', '069-0245984', '069-0245874'); " +
                    "INSERT INTO Customers VALUES('LETSS', 'Let''s Stop N Shop', 'Jaime Yorres', 'Owner', '87 Polk St. Suite 5', 'San Francisco', 'CA', '94117', 'USA', '(415) 555-5938',NULL); " +
                    "INSERT INTO Customers VALUES('LILAS', 'LILA-Supermercado', 'Carlos González', 'Accounting Manager', 'Carrera 52 con Ave. Bolívar #65-98 Llano Largo', 'Barquisimeto', 'Lara', '3508', 'Venezuela', '(9) 331-6954', '(9) 331-7256'); " +
                    "INSERT INTO Customers VALUES('LINOD', 'LINO-Delicateses', 'Felipe Izquierdo', 'Owner', 'Ave. 5 de Mayo Porlamar', 'I. de Margarita', 'Nueva Esparta', '4980', 'Venezuela', '(8) 34-56-12', '(8) 34-93-93'); " +
                    "INSERT INTO Customers VALUES('LONEP', 'Lonesome Pine Restaurant', 'Fran Wilson', 'Sales Manager', '89 Chiaroscuro Rd.', 'Portland', 'OR', '97219', 'USA', '(503) 555-9573', '(503) 555-9646'); " +
                    "INSERT INTO Customers VALUES('MAGAA', 'Magazzini Alimentari Riuniti', 'Giovanni Rovelli', 'Marketing Manager', 'Via Ludovico il Moro 22', 'Bergamo',NULL,'24100', 'Italy', '035-640230', '035-640231'); " +
                    "INSERT INTO Customers VALUES('MAISD', 'Maison Dewey', 'Catherine Dewey', 'Sales Agent', 'Rue Joseph-Bens 532', 'Bruxelles',NULL,'B-1180', 'Belgium', '(02) 201 24 67', '(02) 201 24 68'); " +
                    "INSERT INTO Customers VALUES('MEREP', 'Mère Paillarde', 'Jean Fresnière', 'Marketing Assistant', '43 rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada', '(514) 555-8054', '(514) 555-8055'); " +
                    "INSERT INTO Customers VALUES('MORGK', 'Morgenstern Gesundkost', 'Alexander Feuer', 'Marketing Assistant', 'Heerstr. 22', 'Leipzig',NULL,'04179', 'Germany', '0342-023176',NULL); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO Customers VALUES('NORTS', 'North/South', 'Simon Crowther', 'Sales Associate', 'South House 300 Queensbridge', 'London',NULL,'SW7 1RZ', 'UK', '(171) 555-7733', '(171) 555-2530'); " +
                    "INSERT INTO Customers VALUES('OCEAN', 'Océano Atlántico Ltda.', 'Yvonne Moncada', 'Sales Agent', 'Ing. Gustavo Moncada 8585 Piso 20-A', 'Buenos Aires',NULL,'1010', 'Argentina', '(1) 135-5333', '(1) 135-5535'); " +
                    "INSERT INTO Customers VALUES('OLDWO', 'Old World Delicatessen', 'Rene Phillips', 'Sales Representative', '2743 Bering St.', 'Anchorage', 'AK', '99508', 'USA', '(907) 555-7584', '(907) 555-2880'); " +
                    "INSERT INTO Customers VALUES('OTTIK', 'Ottilies Käseladen', 'Henriette Pfalzheim', 'Owner', 'Mehrheimerstr. 369', 'Köln',NULL,'50739', 'Germany', '0221-0644327', '0221-0765721'); " +
                    "INSERT INTO Customers VALUES('PARIS', 'Paris spécialités', 'Marie Bertrand', 'Owner', '265,boulevard Charonne', 'Paris',NULL,'75012', 'France', '(1) 42.34.22.66', '(1) 42.34.22.77'); " +
                    "INSERT INTO Customers VALUES('PERIC', 'Pericles Comidas clásicas', 'Guillermo Fernández', 'Sales Representative', 'Calle Dr. Jorge Cash 321', 'México D.F.',NULL,'05033', 'Mexico', '(5) 552-3745', '(5) 545-3745'); " +
                    "INSERT INTO Customers VALUES('PICCO', 'Piccolo und mehr', 'Georg Pipps', 'Sales Manager', 'Geislweg 14', 'Salzburg',NULL,'5020', 'Austria', '6562-9722', '6562-9723'); " +
                    "INSERT INTO Customers VALUES('PRINI', 'Princesa Isabel Vinhos', 'Isabel de Castro', 'Sales Representative', 'Estrada da saúde n. 58', 'Lisboa',NULL,'1756', 'Portugal', '(1) 356-5634',NULL); " +
                    "INSERT INTO Customers VALUES('QUEDE', 'Que Delícia', 'Bernardo Batista', 'Accounting Manager', 'Rua da Panificadora,12', 'Rio de Janeiro', 'RJ', '02389-673', 'Brazil', '(21) 555-4252', '(21) 555-4545'); " +
                    "INSERT INTO Customers VALUES('QUEEN', 'Queen Cozinha', 'Lúcia Carvalho', 'Marketing Assistant', 'Alameda dos Canàrios,891', 'Sao Paulo', 'SP', '05487-020', 'Brazil', '(11) 555-1189',NULL); " +
                    "INSERT INTO Customers VALUES('QUICK', 'QUICK-Stop', 'Horst Kloss', 'Accounting Manager', 'Taucherstraße 10', 'Cunewalde',NULL,'01307', 'Germany', '0372-035188',NULL); " +
                    "INSERT INTO Customers VALUES('RANCH', 'Rancho grande', 'Sergio Gutiérrez', 'Sales Representative', 'Av. del Libertador 900', 'Buenos Aires',NULL,'1010', 'Argentina', '(1) 123-5555', '(1) 123-5556'); " +
                    "INSERT INTO Customers VALUES('RATTC', 'Rattlesnake Canyon Grocery', 'Paula Wilson', 'Assistant Sales Representative', '2817 Milton Dr.', 'Albuquerque', 'NM', '87110', 'USA', '(505) 555-5939', '(505) 555-3620'); " +
                    "INSERT INTO Customers VALUES('REGGC', 'Reggiani Caseifici', 'Maurizio Moroni', 'Sales Associate', 'Strada Provinciale 124', 'Reggio Emilia',NULL,'42100', 'Italy', '0522-556721', '0522-556722'); " +
                    "INSERT INTO Customers VALUES('RICAR', 'Ricardo Adocicados', 'Janete Limeira', 'Assistant Sales Agent', 'Av. Copacabana,267', 'Rio de Janeiro', 'RJ', '02389-890', 'Brazil', '(21) 555-3412',NULL); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO Customers VALUES('RICSU', 'Richter Supermarkt', 'Michael Holz', 'Sales Manager', 'Grenzacherweg 237', 'Genève',NULL,'1203', 'Switzerland', '0897-034214',NULL); " +
                    "INSERT INTO Customers VALUES('ROMEY', 'Romero y tomillo', 'Alejandra Camino', 'Accounting Manager', 'Gran Vía,1', 'Madrid',NULL,'28001', 'Spain', '(91) 745 6200', '(91) 745 6210'); " +
                    "INSERT INTO Customers VALUES('SANTG', 'Santé Gourmet', 'Jonas Bergulfsen', 'Owner', 'Erling Skakkes gate 78', 'Stavern',NULL,'4110', 'Norway', '07-98 92 35', '07-98 92 47'); " +
                    "INSERT INTO Customers VALUES('SAVEA', 'Save-a-lot Markets', 'Jose Pavarotti', 'Sales Representative', '187 Suffolk Ln.', 'Boise', 'ID', '83720', 'USA', '(208) 555-8097',NULL); " +
                    "INSERT INTO Customers VALUES('SEVES', 'Seven Seas Imports', 'Hari Kumar', 'Sales Manager', '90 Wadhurst Rd.', 'London',NULL,'OX15 4NB', 'UK', '(171) 555-1717', '(171) 555-5646'); " +
                    "INSERT INTO Customers VALUES('SIMOB', 'Simons bistro', 'Jytte Petersen', 'Owner', 'Vinbæltet 34', 'Kobenhavn',NULL,'1734', 'Denmark', '31 12 34 56', '31 13 35 57'); " +
                    "INSERT INTO Customers VALUES('SPECD', 'Spécialités du monde', 'Dominique Perrier', 'Marketing Manager', '25,rue Lauriston', 'Paris',NULL,'75016', 'France', '(1) 47.55.60.10', '(1) 47.55.60.20'); " +
                    "INSERT INTO Customers VALUES('SPLIR', 'Split Rail Beer & Ale', 'Art Braunschweiger', 'Sales Manager', 'P.O. Box 555', 'Lander', 'WY', '82520', 'USA', '(307) 555-4680', '(307) 555-6525'); " +
                    "INSERT INTO Customers VALUES('SUPRD', 'Suprêmes délices', 'Pascale Cartrain', 'Accounting Manager', 'Boulevard Tirou,255', 'Charleroi',NULL,'B-6000', 'Belgium', '(071) 23 67 22 20', '(071) 23 67 22 21'); " +
                    "INSERT INTO Customers VALUES('THEBI', 'The Big Cheese', 'Liz Nixon', 'Marketing Manager', '89 Jefferson Way Suite 2', 'Portland', 'OR', '97201', 'USA', '(503) 555-3612',NULL); " +
                    "INSERT INTO Customers VALUES('THECR', 'The Cracker Box', 'Liu Wong', 'Marketing Assistant', '55 Grizzly Peak Rd.', 'Butte', 'MT', '59801', 'USA', '(406) 555-5834', '(406) 555-8083'); " +
                    "INSERT INTO Customers VALUES('TOMSP', 'Toms Spezialitäten', 'Karin Josephs', 'Marketing Manager', 'Luisenstr. 48', 'Münster',NULL,'44087', 'Germany', '0251-031259', '0251-035695'); " +
                    "INSERT INTO Customers VALUES('TORTU', 'Tortuga Restaurante', 'Miguel Angel Paolino', 'Owner', 'Avda. Azteca 123', 'México D.F.',NULL,'05033', 'Mexico', '(5) 555-2933',NULL); " +
                    "INSERT INTO Customers VALUES('TRADH', 'Tradição Hipermercados', 'Anabela Domingues', 'Sales Representative', 'Av. Inês de Castro,414', 'Sao Paulo', 'SP', '05634-030', 'Brazil', '(11) 555-2167', '(11) 555-2168'); " +
                    "INSERT INTO Customers VALUES('TRAIH', 'Trail''s Head Gourmet Provisioners', 'Helvetius Nagy', 'Sales Associate', '722 DaVinci Blvd.', 'Kirkland', 'WA', '98034', 'USA', '(206) 555-8257', '(206) 555-2174'); " +
                    "INSERT INTO Customers VALUES('VAFFE', 'Vaffeljernet', 'Palle Ibsen', 'Sales Manager', 'Smagsloget 45', 'Århus',NULL,'8200', 'Denmark', '86 21 32 43', '86 22 33 44'); " +
                    "INSERT INTO Customers VALUES('VICTE', 'Victuailles en stock', 'Mary Saveley', 'Sales Agent', '2,rue du Commerce', 'Lyon',NULL,'69004', 'France', '78.32.54.86', '78.32.54.87'); " +
                    "INSERT INTO Customers VALUES('VINET', 'Vins et alcools Chevalier', 'Paul Henriot', 'Accounting Manager', '59 rue de l''Abbaye', 'Reims',NULL,'51100', 'France', '26.47.15.10', '26.47.15.11'); " +
                    "INSERT INTO Customers VALUES('WANDK', 'Die Wandernde Kuh', 'Rita Müller', 'Sales Representative', 'Adenauerallee 900', 'Stuttgart',NULL,'70563', 'Germany', '0711-020361', '0711-035428'); " +
                    "INSERT INTO Customers VALUES('WARTH', 'Wartian Herkku', 'Pirkko Koskitalo', 'Accounting Manager', 'Torikatu 38', 'Oulu',NULL,'90110', 'Finland', '981-443655', '981-443655'); " +
                    "INSERT INTO Customers VALUES('WELLI', 'Wellington Importadora', 'Paula Parente', 'Sales Manager', 'Rua do Mercado,12', 'Resende', 'SP', '08737-363', 'Brazil', '(14) 555-8122',NULL); " +
                    "INSERT INTO Customers VALUES('WHITC', 'White Clover Markets', 'Karl Jablonski', 'Owner', '305 - 14th Ave. S. Suite 3B', 'Seattle', 'WA', '98128', 'USA', '(206) 555-4112', '(206) 555-4115'); " +
                    "INSERT INTO Customers VALUES('WILMK', 'Wilman Kala', 'Matti Karttunen', 'Owner/Marketing Assistant', 'Keskuskatu 45', 'Helsinki',NULL,'21240', 'Finland', '90-224 8858', '90-224 8858'); " +
                    "INSERT INTO Customers VALUES('WOLZA', 'Wolski Zajazd', 'Zbyszek Piestrzeniewicz', 'Owner', 'ul. Filtrowa 68', 'Warszawa',NULL,'01-012', 'Poland', '(26) 642-7012', '(26) 642-7012'); ";
            cmd.ExecuteNonQuery();

        }

        static private void LoadOrderDetails(TdCommand cmd)
        {
            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10248,11,14,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10248,42,9.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10248,72,34.8,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10249,14,18.6,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10249,51,42.4,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10250,41,7.7,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10250,51,42.4,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10250,65,16.8,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10251,22,16.8,6,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10251,57,15.6,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10251,65,16.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10252,20,64.8,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10252,33,2,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10252,60,27.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10253,31,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10253,39,14.4,42,0); " +
                    "INSERT INTO OrderDetails VALUES(10253,49,16,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10254,24,3.6,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10254,55,19.2,21,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10254,74,8,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10255,2,15.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10255,16,13.9,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10255,36,15.2,25,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10256,53,26.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10256,77,10.4,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10257,27,35.1,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10257,39,14.4,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10257,77,10.4,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10258,2,15.2,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10258,5,17,65,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10258,32,25.6,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10259,21,8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10259,37,20.8,1,0); " +
                    "INSERT INTO OrderDetails VALUES(10260,41,7.7,16,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10260,57,15.6,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10260,62,39.4,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10260,70,12,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10261,21,8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10261,35,14.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10262,5,17,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10262,7,24,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10262,56,30.4,2,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10263,16,13.9,60,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10263,24,3.6,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10263,30,20.7,60,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10263,74,8,36,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10264,2,15.2,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10264,41,7.7,25,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10265,17,31.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10265,70,12,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10266,12,30.4,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10267,40,14.7,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10267,59,44,70,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10267,76,14.4,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10268,29,99,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10268,72,27.8,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10269,33,2,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10269,72,27.8,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10270,36,15.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10270,43,36.8,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10271,33,2,24,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10272,20,64.8,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10272,31,10,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10272,72,27.8,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10273,10,24.8,24,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10273,31,10,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10273,33,2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10273,40,14.7,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10273,76,14.4,33,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10274,71,17.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10274,72,27.8,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10275,24,3.6,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10275,59,44,6,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10276,10,24.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10276,13,4.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10277,28,36.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10277,62,39.4,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10278,44,15.5,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10278,59,44,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10278,63,35.1,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10278,73,12,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10279,17,31.2,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10280,24,3.6,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10280,55,19.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10280,75,6.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10281,19,7.3,1,0); " +
                    "INSERT INTO OrderDetails VALUES(10281,24,3.6,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10281,35,14.4,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10282,30,20.7,6,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10282,57,15.6,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10283,15,12.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10283,19,7.3,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10283,60,27.2,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10283,72,27.8,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10284,27,35.1,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10284,44,15.5,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10284,60,27.2,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10284,67,11.2,5,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10285,1,14.4,45,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10285,40,14.7,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10285,53,26.2,36,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10286,35,14.4,100,0); " +
                    "INSERT INTO OrderDetails VALUES(10286,62,39.4,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10287,16,13.9,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10287,34,11.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10287,46,9.6,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10288,54,5.9,10,0.1); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10288,68,10,3,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10289,3,8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10289,64,26.6,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10290,5,17,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10290,29,99,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10290,49,16,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10290,77,10.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10291,13,4.8,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10291,44,15.5,24,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10291,51,42.4,2,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10292,20,64.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10293,18,50,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10293,24,3.6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10293,63,35.1,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10293,75,6.2,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10294,1,14.4,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10294,17,31.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10294,43,36.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10294,60,27.2,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10294,75,6.2,6,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10295,56,30.4,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10296,11,16.8,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10296,16,13.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10296,69,28.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10297,39,14.4,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10297,72,27.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10298,2,15.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10298,36,15.2,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10298,59,44,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10298,62,39.4,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10299,19,7.3,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10299,70,12,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10300,66,13.6,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10300,68,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10301,40,14.7,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10301,56,30.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10302,17,31.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10302,28,36.4,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10302,43,36.8,12,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO OrderDetails VALUES(10303,40,14.7,40,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10303,65,16.8,30,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10303,68,10,15,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10304,49,16,30,0); " +
                   "INSERT INTO OrderDetails VALUES(10304,59,44,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10304,71,17.2,2,0); " +
                   "INSERT INTO OrderDetails VALUES(10305,18,50,25,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10305,29,99,25,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10305,39,14.4,30,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10306,30,20.7,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10306,53,26.2,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10306,54,5.9,5,0); " +
                   "INSERT INTO OrderDetails VALUES(10307,62,39.4,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10307,68,10,3,0); " +
                   "INSERT INTO OrderDetails VALUES(10308,69,28.8,1,0); " +
                   "INSERT INTO OrderDetails VALUES(10308,70,12,5,0); " +
                   "INSERT INTO OrderDetails VALUES(10309,4,17.6,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10309,6,20,30,0); " +
                   "INSERT INTO OrderDetails VALUES(10309,42,11.2,2,0); " +
                   "INSERT INTO OrderDetails VALUES(10309,43,36.8,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10309,71,17.2,3,0); " +
                   "INSERT INTO OrderDetails VALUES(10310,16,13.9,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10310,62,39.4,5,0); " +
                   "INSERT INTO OrderDetails VALUES(10311,42,11.2,6,0); " +
                   "INSERT INTO OrderDetails VALUES(10311,69,28.8,7,0); " +
                   "INSERT INTO OrderDetails VALUES(10312,28,36.4,4,0); " +
                   "INSERT INTO OrderDetails VALUES(10312,43,36.8,24,0); " +
                   "INSERT INTO OrderDetails VALUES(10312,53,26.2,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10312,75,6.2,10,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10313,36,15.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10314,32,25.6,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10314,58,10.6,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10314,62,39.4,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10315,34,11.2,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10315,70,12,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10316,41,7.7,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10316,62,39.4,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10317,1,14.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10318,41,7.7,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10318,76,14.4,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10319,17,31.2,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10319,28,36.4,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10319,76,14.4,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10320,71,17.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10321,35,14.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10322,52,5.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10323,15,12.4,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10323,25,11.2,4,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10323,39,14.4,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10324,16,13.9,21,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10324,35,14.4,70,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10324,46,9.6,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10324,59,44,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10324,63,35.1,80,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10325,6,20,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10325,13,4.8,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10325,14,18.6,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10325,31,10,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10325,72,27.8,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10326,4,17.6,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10326,57,15.6,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10326,75,6.2,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10327,2,15.2,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10327,11,16.8,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10327,30,20.7,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10327,58,10.6,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10328,59,44,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10328,65,16.8,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10328,68,10,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10329,19,7.3,10,0.05); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10329,30,20.7,8,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10329,38,210.8,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10329,56,30.4,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10330,26,24.9,50,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10330,72,27.8,25,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10331,54,5.9,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10332,18,50,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10332,42,11.2,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10332,47,7.6,16,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10333,14,18.6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10333,21,8,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10333,71,17.2,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10334,52,5.6,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10334,68,10,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10335,2,15.2,7,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10335,31,10,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10335,32,25.6,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10335,51,42.4,48,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10336,4,17.6,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10337,23,7.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10337,26,24.9,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10337,36,15.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10337,37,20.8,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10337,72,27.8,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10338,17,31.2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10338,30,20.7,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10339,4,17.6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10339,17,31.2,70,0.05); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10339,62,39.4,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10340,18,50,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10340,41,7.7,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10340,43,36.8,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10341,33,2,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10341,59,44,9,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10342,2,15.2,24,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10342,31,10,56,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10342,36,15.2,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10342,55,19.2,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10343,64,26.6,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10343,68,10,4,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10343,76,14.4,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10344,4,17.6,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10344,8,32,70,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10345,8,32,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10345,19,7.3,80,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10345,42,11.2,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10346,17,31.2,36,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10346,56,30.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10347,25,11.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10347,39,14.4,50,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10347,40,14.7,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10347,75,6.2,6,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10348,1,14.4,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10348,23,7.2,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10349,54,5.9,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10350,50,13,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10350,69,28.8,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10351,38,210.8,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10351,41,7.7,13,0); " +
                    "INSERT INTO OrderDetails VALUES(10351,44,15.5,77,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10351,65,16.8,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10352,24,3.6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10352,54,5.9,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10353,11,16.8,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10353,38,210.8,50,0.2); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO OrderDetails VALUES(10354,1,14.4,12,0); " +
                   "INSERT INTO OrderDetails VALUES(10354,29,99,4,0); " +
                   "INSERT INTO OrderDetails VALUES(10355,24,3.6,25,0); " +
                   "INSERT INTO OrderDetails VALUES(10355,57,15.6,25,0); " +
                   "INSERT INTO OrderDetails VALUES(10356,31,10,30,0); " +
                   "INSERT INTO OrderDetails VALUES(10356,55,19.2,12,0); " +
                   "INSERT INTO OrderDetails VALUES(10356,69,28.8,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10357,10,24.8,30,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10357,26,24.9,16,0); " +
                   "INSERT INTO OrderDetails VALUES(10357,60,27.2,8,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10358,24,3.6,10,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10358,34,11.2,10,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10358,36,15.2,20,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10359,16,13.9,56,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10359,31,10,70,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10359,60,27.2,80,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10360,28,36.4,30,0); " +
                   "INSERT INTO OrderDetails VALUES(10360,29,99,35,0); " +
                   "INSERT INTO OrderDetails VALUES(10360,38,210.8,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10360,49,16,35,0); " +
                   "INSERT INTO OrderDetails VALUES(10360,54,5.9,28,0); " +
                   "INSERT INTO OrderDetails VALUES(10361,39,14.4,54,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10361,60,27.2,55,0.1); " +
                   "INSERT INTO OrderDetails VALUES(10362,25,11.2,50,0); " +
                   "INSERT INTO OrderDetails VALUES(10362,51,42.4,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10362,54,5.9,24,0); " +
                   "INSERT INTO OrderDetails VALUES(10363,31,10,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10363,75,6.2,12,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10363,76,14.4,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10364,69,28.8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10364,71,17.2,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10365,11,16.8,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10366,65,16.8,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10366,77,10.4,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10367,34,11.2,36,0); " +
                    "INSERT INTO OrderDetails VALUES(10367,54,5.9,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10367,65,16.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10367,77,10.4,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10368,21,8,5,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10368,28,36.4,13,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10368,57,15.6,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10368,64,26.6,35,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10369,29,99,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10369,56,30.4,18,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10370,1,14.4,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10370,64,26.6,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10370,74,8,20,0.15); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10371,36,15.2,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10372,20,64.8,12,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10372,38,210.8,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10372,60,27.2,70,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10372,72,27.8,42,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10373,58,10.6,80,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10373,71,17.2,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10374,31,10,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10374,58,10.6,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10375,14,18.6,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10375,54,5.9,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10376,31,10,42,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10377,28,36.4,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10377,39,14.4,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10378,71,17.2,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10379,41,7.7,8,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10379,63,35.1,16,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10379,65,16.8,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10380,30,20.7,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10380,53,26.2,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10380,60,27.2,6,0.1); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10380,70,12,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10381,74,8,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10382,5,17,32,0); " +
                    "INSERT INTO OrderDetails VALUES(10382,18,50,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10382,29,99,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10382,33,2,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10382,74,8,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10383,13,4.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10383,50,13,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10383,56,30.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10384,20,64.8,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10384,60,27.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10385,7,24,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10385,60,27.2,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10385,68,10,8,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10386,24,3.6,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10386,34,11.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10387,24,3.6,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10387,28,36.4,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10387,59,44,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10387,71,17.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10388,45,7.6,15,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10388,52,5.6,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10388,53,26.2,40,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10389,10,24.8,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10389,55,19.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10389,62,39.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10389,70,12,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10390,31,10,60,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10390,35,14.4,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10390,46,9.6,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10390,72,27.8,24,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10391,13,4.8,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10392,69,28.8,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10393,2,15.2,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10393,14,18.6,42,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10393,25,11.2,7,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10393,26,24.9,70,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10393,31,10,32,0); " +
                    "INSERT INTO OrderDetails VALUES(10394,13,4.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10394,62,39.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10395,46,9.6,28,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10395,53,26.2,70,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10395,69,28.8,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10396,23,7.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10396,71,17.2,60,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10396,72,27.8,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10397,21,8,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10397,51,42.4,18,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10398,35,14.4,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10398,55,19.2,120,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10399,68,10,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10399,71,17.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10399,76,14.4,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10399,77,10.4,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10400,29,99,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10400,35,14.4,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10400,49,16,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10401,30,20.7,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10401,56,30.4,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10401,65,16.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10401,71,17.2,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10402,23,7.2,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10402,63,35.1,65,0); ";
                cmd.ExecuteNonQuery();

                cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10403,16,13.9,21,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10403,48,10.2,70,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10404,26,24.9,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10404,42,11.2,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10404,49,16,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10405,3,8,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10406,1,14.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10406,21,8,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10406,28,36.4,42,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10406,36,15.2,5,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10406,40,14.7,2,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10407,11,16.8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10407,69,28.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10407,71,17.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10408,37,20.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10408,54,5.9,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10408,62,39.4,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10409,14,18.6,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10409,21,8,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10410,33,2,49,0); " +
                    "INSERT INTO OrderDetails VALUES(10410,59,44,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10411,41,7.7,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10411,44,15.5,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10411,59,44,9,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10412,14,18.6,20,0.1); ";
              cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10413,1,14.4,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10413,62,39.4,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10413,76,14.4,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10414,19,7.3,18,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10414,33,2,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10415,17,31.2,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10415,33,2,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10416,19,7.3,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10416,53,26.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10416,57,15.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10417,38,210.8,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10417,46,9.6,2,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10417,68,10,36,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10417,77,10.4,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10418,2,15.2,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10418,47,7.6,55,0); " +
                    "INSERT INTO OrderDetails VALUES(10418,61,22.8,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10418,74,8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10419,60,27.2,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10419,69,28.8,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10420,9,77.6,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10420,13,4.8,2,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10420,70,12,8,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10420,73,12,20,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10421,19,7.3,4,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10421,26,24.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10421,53,26.2,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10421,77,10.4,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10422,26,24.9,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10423,31,10,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10423,59,44,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10424,35,14.4,60,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10424,38,210.8,49,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10424,68,10,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10425,55,19.2,10,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10425,76,14.4,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10426,56,30.4,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10426,64,26.6,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10427,14,18.6,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10428,46,9.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10429,50,13,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10429,63,35.1,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10430,17,31.2,45,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10430,21,8,50,0); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                     "INSERT INTO OrderDetails VALUES(10430,56,30.4,30,0); " +
                     "INSERT INTO OrderDetails VALUES(10430,59,44,70,0.2); " +
                     "INSERT INTO OrderDetails VALUES(10431,17,31.2,50,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10431,40,14.7,50,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10431,47,7.6,30,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10432,26,24.9,10,0); " +
                     "INSERT INTO OrderDetails VALUES(10432,54,5.9,40,0); " +
                     "INSERT INTO OrderDetails VALUES(10433,56,30.4,28,0); " +
                     "INSERT INTO OrderDetails VALUES(10434,11,16.8,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10434,76,14.4,18,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10435,2,15.2,10,0); " +
                     "INSERT INTO OrderDetails VALUES(10435,22,16.8,12,0); " +
                     "INSERT INTO OrderDetails VALUES(10435,72,27.8,10,0); " +
                     "INSERT INTO OrderDetails VALUES(10436,46,9.6,5,0); " +
                     "INSERT INTO OrderDetails VALUES(10436,56,30.4,40,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10436,64,26.6,30,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10436,75,6.2,24,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10437,53,26.2,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10438,19,7.3,15,0.2); " +
                     "INSERT INTO OrderDetails VALUES(10438,34,11.2,20,0.2); " +
                     "INSERT INTO OrderDetails VALUES(10438,57,15.6,15,0.2); " +
                     "INSERT INTO OrderDetails VALUES(10439,12,30.4,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10439,16,13.9,16,0); " +
                     "INSERT INTO OrderDetails VALUES(10439,64,26.6,6,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10439,74,8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10440,2,15.2,45,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10440,16,13.9,49,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10440,29,99,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10440,61,22.8,90,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10441,27,35.1,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10442,11,16.8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10442,54,5.9,80,0); " +
                    "INSERT INTO OrderDetails VALUES(10442,66,13.6,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10443,11,16.8,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10443,28,36.4,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10444,17,31.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10444,26,24.9,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10444,35,14.4,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10444,41,7.7,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10445,39,14.4,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10445,54,5.9,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10446,19,7.3,12,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10446,24,3.6,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10446,31,10,3,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10446,52,5.6,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10447,19,7.3,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10447,65,16.8,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10447,71,17.2,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10448,26,24.9,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10448,40,14.7,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10449,10,24.8,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10449,52,5.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10449,62,39.4,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10450,10,24.8,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10450,54,5.9,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10451,55,19.2,120,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10451,64,26.6,35,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10451,65,16.8,28,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10451,77,10.4,55,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10452,28,36.4,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10452,44,15.5,100,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10453,48,10.2,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10453,70,12,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10454,16,13.9,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10454,33,2,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10454,46,9.6,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10455,39,14.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10455,53,26.2,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10455,61,22.8,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10455,71,17.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10456,21,8,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10456,49,16,21,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10457,59,44,36,0); " +
                    "INSERT INTO OrderDetails VALUES(10458,26,24.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10458,28,36.4,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10458,43,36.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10458,56,30.4,15,0); ";
              cmd.ExecuteNonQuery();
            
            cmd.CommandText =
                      "INSERT INTO OrderDetails VALUES(10458,71,17.2,50,0); " +
                      "INSERT INTO OrderDetails VALUES(10459,7,24,16,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10459,46,9.6,20,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10459,72,27.8,40,0); " +
                      "INSERT INTO OrderDetails VALUES(10460,68,10,21,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10460,75,6.2,4,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10461,21,8,40,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10461,30,20.7,28,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10461,55,19.2,60,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10462,13,4.8,1,0); " +
                      "INSERT INTO OrderDetails VALUES(10462,23,7.2,21,0); " +
                      "INSERT INTO OrderDetails VALUES(10463,19,7.3,21,0); " +
                      "INSERT INTO OrderDetails VALUES(10463,42,11.2,50,0); " +
                      "INSERT INTO OrderDetails VALUES(10464,4,17.6,16,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10464,43,36.8,3,0); " +
                      "INSERT INTO OrderDetails VALUES(10464,56,30.4,30,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10464,60,27.2,20,0); " +
                      "INSERT INTO OrderDetails VALUES(10465,24,3.6,25,0); " +
                      "INSERT INTO OrderDetails VALUES(10465,29,99,18,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10465,40,14.7,20,0); " +
                      "INSERT INTO OrderDetails VALUES(10465,45,7.6,30,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10465,50,13,25,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10466,11,16.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10466,46,9.6,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10467,24,3.6,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10467,25,11.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10468,30,20.7,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10468,43,36.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10469,2,15.2,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10469,16,13.9,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10469,44,15.5,2,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10470,18,50,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10470,23,7.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10470,64,26.6,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10471,7,24,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10471,56,30.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10472,24,3.6,80,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10472,51,42.4,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10473,33,2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10473,71,17.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10474,14,18.6,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10474,28,36.4,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10474,40,14.7,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10474,75,6.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10475,31,10,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10475,66,13.6,60,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10475,76,14.4,42,0.15); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10476,55,19.2,2,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10476,70,12,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10477,1,14.4,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10477,21,8,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10477,39,14.4,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10478,10,24.8,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10479,38,210.8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10479,53,26.2,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10479,59,44,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10479,64,26.6,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10480,47,7.6,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10480,59,44,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10481,49,16,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10481,60,27.2,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10482,40,14.7,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10483,34,11.2,35,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10483,77,10.4,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10484,21,8,14,0); ";
              cmd.ExecuteNonQuery();

              cmd.CommandText =
                     "INSERT INTO OrderDetails VALUES(10484,40,14.7,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10484,51,42.4,3,0); " +
                      "INSERT INTO OrderDetails VALUES(10485,2,15.2,20,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10485,3,8,20,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10485,55,19.2,30,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10485,70,12,60,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10486,11,16.8,5,0); " +
                      "INSERT INTO OrderDetails VALUES(10486,51,42.4,25,0); " +
                      "INSERT INTO OrderDetails VALUES(10486,74,8,16,0); " +
                      "INSERT INTO OrderDetails VALUES(10487,19,7.3,5,0); " +
                      "INSERT INTO OrderDetails VALUES(10487,26,24.9,30,0); " +
                      "INSERT INTO OrderDetails VALUES(10487,54,5.9,24,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10488,59,44,30,0); " +
                      "INSERT INTO OrderDetails VALUES(10488,73,12,20,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10489,11,16.8,15,0.25); " +
                      "INSERT INTO OrderDetails VALUES(10489,16,13.9,18,0); " +
                      "INSERT INTO OrderDetails VALUES(10490,59,44,60,0); " +
                      "INSERT INTO OrderDetails VALUES(10490,68,10,30,0); " +
                      "INSERT INTO OrderDetails VALUES(10490,75,6.2,36,0); " +
                      "INSERT INTO OrderDetails VALUES(10491,44,15.5,15,0.15); " +
                      "INSERT INTO OrderDetails VALUES(10491,77,10.4,7,0.15); " +
                      "INSERT INTO OrderDetails VALUES(10492,25,11.2,60,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10492,42,11.2,20,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10493,65,16.8,15,0.1); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10493,66,13.6,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10493,69,28.8,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10494,56,30.4,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10495,23,7.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10495,41,7.7,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10495,77,10.4,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10496,31,10,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10497,56,30.4,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10497,72,27.8,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10497,77,10.4,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10498,24,4.5,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10498,40,18.4,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10498,42,14,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10499,28,45.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10499,49,20,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10500,15,15.5,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10500,28,45.6,8,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10501,54,7.45,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10502,45,9.5,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10502,53,32.8,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10502,67,14,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10503,14,23.25,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10503,65,21.05,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10504,2,19,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10504,21,10,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10504,53,32.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10504,61,28.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10505,62,49.3,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10506,25,14,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10506,70,15,14,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10507,43,46,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10507,48,12.75,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10508,13,6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10508,39,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10509,28,45.6,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10510,29,123.79,36,0); " +
                    "INSERT INTO OrderDetails VALUES(10510,75,7.75,36,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10511,4,22,50,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10511,7,30,50,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10511,8,40,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10512,24,4.5,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10512,46,12,9,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10512,47,9.5,6,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10512,60,34,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10513,21,10,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10513,32,32,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10513,61,28.5,15,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10514,20,81,39,0); " +
                    "INSERT INTO OrderDetails VALUES(10514,28,45.6,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10514,56,38,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10514,65,21.05,39,0); " +
                    "INSERT INTO OrderDetails VALUES(10514,75,7.75,50,0); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10515,9,97,16,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10515,16,17.45,50,0); " +
                     "INSERT INTO OrderDetails VALUES(10515,27,43.9,120,0); " +
                     "INSERT INTO OrderDetails VALUES(10515,33,2.5,16,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10515,60,34,84,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10516,18,62.5,25,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10516,41,9.65,80,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10516,42,14,20,0); " +
                     "INSERT INTO OrderDetails VALUES(10517,52,7,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10517,59,55,4,0); " +
                     "INSERT INTO OrderDetails VALUES(10517,70,15,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10518,24,4.5,5,0); " +
                     "INSERT INTO OrderDetails VALUES(10518,38,263.5,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10518,44,19.45,9,0); " +
                     "INSERT INTO OrderDetails VALUES(10519,10,31,16,0.05); " +
                     "INSERT INTO OrderDetails VALUES(10519,56,38,40,0); " +
                     "INSERT INTO OrderDetails VALUES(10519,60,34,10,0.05); " +
                     "INSERT INTO OrderDetails VALUES(10520,24,4.5,8,0); " +
                     "INSERT INTO OrderDetails VALUES(10520,53,32.8,5,0); " +
                     "INSERT INTO OrderDetails VALUES(10521,35,18,3,0); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10521,41,9.65,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10521,68,12.5,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10522,1,18,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10522,8,40,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10522,30,25.89,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10522,40,18.4,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10523,17,39,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10523,20,81,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10523,37,26,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10523,41,9.65,6,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10524,10,31,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10524,30,25.89,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10524,43,46,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10524,54,7.45,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10525,36,19,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10525,40,18.4,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10526,1,18,8,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10526,13,6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10526,56,38,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10527,4,22,50,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10527,36,19,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10528,11,21,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10528,33,2.5,8,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10528,72,34.8,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10529,55,24,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10529,68,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10529,69,36,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10530,17,39,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10530,43,46,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10530,61,28.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10530,76,18,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10531,59,55,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10532,30,25.89,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10532,66,17,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10533,4,22,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10533,72,34.8,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10533,73,15,24,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10534,30,25.89,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10534,40,18.4,10,0.2); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10534,54,7.45,10,0.2); " +
                     "INSERT INTO OrderDetails VALUES(10535,11,21,50,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10535,40,18.4,10,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10535,57,19.5,5,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10535,59,55,15,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10536,12,38,15,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10536,31,12.5,20,0); " +
                     "INSERT INTO OrderDetails VALUES(10536,33,2.5,30,0); " +
                     "INSERT INTO OrderDetails VALUES(10536,60,34,35,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10537,31,12.5,30,0); " +
                     "INSERT INTO OrderDetails VALUES(10537,51,53,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10537,58,13.25,20,0); " +
                     "INSERT INTO OrderDetails VALUES(10537,72,34.8,21,0); " +
                     "INSERT INTO OrderDetails VALUES(10537,73,15,9,0); " +
                     "INSERT INTO OrderDetails VALUES(10538,70,15,7,0); " +
                     "INSERT INTO OrderDetails VALUES(10538,72,34.8,1,0); " +
                     "INSERT INTO OrderDetails VALUES(10539,13,6,8,0); " +
                     "INSERT INTO OrderDetails VALUES(10539,21,10,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10539,33,2.5,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10539,49,20,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10540,3,10,60,0); " +
                     "INSERT INTO OrderDetails VALUES(10540,26,31.23,40,0); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10540,38,263.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10540,68,12.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10541,24,4.5,35,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10541,38,263.5,4,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10541,65,21.05,36,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10541,71,21.5,9,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10542,11,21,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10542,54,7.45,24,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10543,12,38,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10543,23,9,70,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10544,28,45.6,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10544,67,14,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10545,11,21,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10546,7,30,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10546,35,18,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10546,62,49.3,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10547,32,32,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10547,36,19,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10548,34,14,10,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10548,41,9.65,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10549,31,12.5,55,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10549,45,9.5,100,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10549,51,53,48,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10550,17,39,8,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10550,19,9.2,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10550,21,10,6,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10550,61,28.5,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10551,16,17.45,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10551,35,18,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10551,44,19.45,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10552,69,36,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10552,75,7.75,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10553,11,21,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10553,16,17.45,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10553,22,21,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10553,31,12.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10553,35,18,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10554,16,17.45,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10554,23,9,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10554,62,49.3,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10554,77,13,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10555,14,23.25,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10555,19,9.2,35,0.2); ";
              cmd.ExecuteNonQuery();

            cmd.CommandText =
                 "INSERT INTO OrderDetails VALUES(10555,24,4.5,18,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10555,51,53,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10555,56,38,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10556,72,34.8,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10557,64,33.25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10557,75,7.75,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10558,47,9.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10558,51,53,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10558,52,7,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10558,53,32.8,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10558,73,15,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10559,41,9.65,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10559,55,24,18,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10560,30,25.89,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10560,62,49.3,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10561,44,19.45,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10561,51,53,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10562,33,2.5,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10562,62,49.3,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10563,36,19,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10563,52,7,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10564,17,39,16,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10564,31,12.5,6,0.05); ";
               cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO OrderDetails VALUES(10564,55,24,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10565,24,4.5,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10565,64,33.25,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10566,11,21,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10566,18,62.5,18,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10566,76,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10567,31,12.5,60,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10567,51,53,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10567,59,55,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10568,10,31,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10569,31,12.5,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10569,76,18,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10570,11,21,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10570,56,38,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10571,14,23.25,11,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10571,42,14,28,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10572,16,17.45,12,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10572,32,32,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10572,40,18.4,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10572,75,7.75,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10573,17,39,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10573,34,14,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10573,53,32.8,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10574,33,2.5,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10574,40,18.4,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10574,62,49.3,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10574,64,33.25,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10575,59,55,12,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10575,63,43.9,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10575,72,34.8,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10575,76,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10576,1,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10576,31,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10576,44,19.45,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10577,39,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10577,75,7.75,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10577,77,13,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10578,35,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10578,57,19.5,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10579,15,15.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10579,75,7.75,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10580,14,23.25,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10580,41,9.65,9,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10580,65,21.05,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10581,75,7.75,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10582,57,19.5,4,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10582,76,18,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10583,29,123.79,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10583,60,34,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10583,69,36,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10584,31,12.5,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10585,47,9.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10586,52,7,4,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10587,26,31.23,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10587,35,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10587,77,13,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10588,18,62.5,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10588,42,14,100,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10589,35,18,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10590,1,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10590,77,13,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10591,3,10,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10591,7,30,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10591,54,7.45,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10592,15,15.5,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10592,26,31.23,5,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10593,20,81,21,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10593,69,36,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10593,76,18,4,0.2); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10594,52,7,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10594,58,13.25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10595,35,18,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10595,61,28.5,120,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10595,69,36,65,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10596,56,38,5,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10596,63,43.9,24,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10596,75,7.75,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10597,24,4.5,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10597,57,19.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10597,65,21.05,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10598,27,43.9,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10598,71,21.5,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10599,62,49.3,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10600,54,7.45,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10600,73,15,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10601,13,6,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10601,59,55,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10602,77,13,5,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10603,22,21,48,0); " +
                    "INSERT INTO OrderDetails VALUES(10603,49,20,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10604,48,12.75,6,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10604,76,18,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10605,16,17.45,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10605,59,55,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10605,60,34,70,0.05); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10605,71,21.5,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10606,4,22,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10606,55,24,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10606,62,49.3,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10607,7,30,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10607,17,39,100,0); " +
                    "INSERT INTO OrderDetails VALUES(10607,33,2.5,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10607,40,18.4,42,0); " +
                    "INSERT INTO OrderDetails VALUES(10607,72,34.8,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10608,56,38,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10609,1,18,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10609,10,31,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10609,21,10,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10610,36,19,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10611,1,18,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10611,2,19,10,0); ";
                  cmd.ExecuteNonQuery();

                  cmd.CommandText =
                         "INSERT INTO OrderDetails VALUES(10611,60,34,15,0); " +
                          "INSERT INTO OrderDetails VALUES(10612,10,31,70,0); " +
                          "INSERT INTO OrderDetails VALUES(10612,36,19,55,0); " +
                          "INSERT INTO OrderDetails VALUES(10612,49,20,18,0); " +
                          "INSERT INTO OrderDetails VALUES(10612,60,34,40,0); " +
                          "INSERT INTO OrderDetails VALUES(10612,76,18,80,0); " +
                          "INSERT INTO OrderDetails VALUES(10613,13,6,8,0.1); " +
                          "INSERT INTO OrderDetails VALUES(10613,75,7.75,40,0); " +
                          "INSERT INTO OrderDetails VALUES(10614,11,21,14,0); " +
                          "INSERT INTO OrderDetails VALUES(10614,21,10,8,0); " +
                          "INSERT INTO OrderDetails VALUES(10614,39,18,5,0); " +
                          "INSERT INTO OrderDetails VALUES(10615,55,24,5,0); " +
                          "INSERT INTO OrderDetails VALUES(10616,38,263.5,15,0.05); " +
                          "INSERT INTO OrderDetails VALUES(10616,56,38,14,0); " +
                          "INSERT INTO OrderDetails VALUES(10616,70,15,15,0.05); " +
                          "INSERT INTO OrderDetails VALUES(10616,71,21.5,15,0.05); " +
                          "INSERT INTO OrderDetails VALUES(10617,59,55,30,0.15); " +
                          "INSERT INTO OrderDetails VALUES(10618,6,25,70,0); " +
                          "INSERT INTO OrderDetails VALUES(10618,56,38,20,0); " +
                          "INSERT INTO OrderDetails VALUES(10618,68,12.5,15,0); " +
                          "INSERT INTO OrderDetails VALUES(10619,21,10,42,0); " +
                          "INSERT INTO OrderDetails VALUES(10619,22,21,40,0); " +
                          "INSERT INTO OrderDetails VALUES(10620,24,4.5,5,0); " +
                          "INSERT INTO OrderDetails VALUES(10620,52,7,5,0); " +
                          "INSERT INTO OrderDetails VALUES(10621,19,9.2,5,0); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10621,23,9,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10621,70,15,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10621,71,21.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10622,2,19,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10622,68,12.5,18,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10623,14,23.25,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10623,19,9.2,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10623,21,10,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10623,24,4.5,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10623,35,18,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10624,28,45.6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10624,29,123.79,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10624,44,19.45,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10625,14,23.25,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10625,42,14,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10625,60,34,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10626,53,32.8,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10626,60,34,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10626,71,21.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10627,62,49.3,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10627,73,15,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10628,1,18,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10629,29,123.79,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10629,64,33.25,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10630,55,24,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10630,76,18,35,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10631,75,7.75,8,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10632,2,19,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10632,33,2.5,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10633,12,38,36,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10633,13,6,13,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10633,26,31.23,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10633,62,49.3,80,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10634,7,30,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10634,18,62.5,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10634,51,53,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10634,75,7.75,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10635,4,22,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10635,5,21.35,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10635,22,21,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10636,4,22,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10636,58,13.25,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10637,11,21,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10637,50,16.25,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10637,56,38,60,0.05); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10638,45,9.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10638,65,21.05,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10638,72,34.8,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10639,18,62.5,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10640,69,36,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10640,70,15,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10641,2,19,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10641,40,18.4,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10642,21,10,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10642,61,28.5,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10643,28,45.6,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10643,39,18,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10643,46,12,2,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10644,18,62.5,4,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10644,43,46,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10644,46,12,21,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10645,18,62.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10645,36,19,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10646,1,18,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10646,10,31,18,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10646,71,21.5,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10646,77,13,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10647,19,9.2,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10647,39,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10648,22,21,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10648,24,4.5,15,0.15); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO OrderDetails VALUES(10649,28,45.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10649,72,34.8,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10650,30,25.89,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10650,53,32.8,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10650,54,7.45,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10651,19,9.2,12,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10651,22,21,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10652,30,25.89,2,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10652,42,14,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10653,16,17.45,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10653,60,34,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10654,4,22,12,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10654,39,18,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10654,54,7.45,6,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10655,41,9.65,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10656,14,23.25,3,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10656,44,19.45,28,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10656,47,9.5,6,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10657,15,15.5,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10657,41,9.65,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10657,46,12,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10657,47,9.5,10,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10657,56,38,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10657,60,34,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10658,21,10,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10658,40,18.4,70,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10658,60,34,55,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10658,77,13,70,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10659,31,12.5,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10659,40,18.4,24,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10659,70,15,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10660,20,81,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10661,39,18,3,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10661,58,13.25,49,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10662,68,12.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10663,40,18.4,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10663,42,14,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10663,51,53,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10664,10,31,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10664,56,38,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10664,65,21.05,15,0.15); ";
              cmd.ExecuteNonQuery();

              cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10665,51,53,20,0); " +
                      "INSERT INTO OrderDetails VALUES(10665,59,55,1,0); " +
                      "INSERT INTO OrderDetails VALUES(10665,76,18,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10666,29,123.79,36,0); " +
                      "INSERT INTO OrderDetails VALUES(10666,65,21.05,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10667,69,36,45,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10667,71,21.5,14,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10668,31,12.5,8,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10668,55,24,4,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10668,64,33.25,15,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10669,36,19,30,0); " +
                      "INSERT INTO OrderDetails VALUES(10670,23,9,32,0); " +
                      "INSERT INTO OrderDetails VALUES(10670,46,12,60,0); " +
                      "INSERT INTO OrderDetails VALUES(10670,67,14,25,0); " +
                      "INSERT INTO OrderDetails VALUES(10670,73,15,50,0); " +
                      "INSERT INTO OrderDetails VALUES(10670,75,7.75,25,0); " +
                      "INSERT INTO OrderDetails VALUES(10671,16,17.45,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10671,62,49.3,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10671,65,21.05,12,0); " +
                      "INSERT INTO OrderDetails VALUES(10672,38,263.5,15,0.1); " +
                      "INSERT INTO OrderDetails VALUES(10672,71,21.5,12,0); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                 "INSERT INTO OrderDetails VALUES(10673,16,17.45,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10673,42,14,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10673,43,46,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10674,23,9,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10675,14,23.25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10675,53,32.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10675,58,13.25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10676,10,31,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10676,19,9.2,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10676,44,19.45,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10677,26,31.23,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10677,33,2.5,8,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10678,12,38,100,0); " +
                    "INSERT INTO OrderDetails VALUES(10678,33,2.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10678,41,9.65,120,0); " +
                    "INSERT INTO OrderDetails VALUES(10678,54,7.45,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10679,59,55,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10680,16,17.45,50,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10680,31,12.5,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10680,42,14,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10681,19,9.2,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10681,21,10,12,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10681,64,33.25,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10682,33,2.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10682,66,17,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10682,75,7.75,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10683,52,7,9,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10684,40,18.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10684,47,9.5,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10684,60,34,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10685,10,31,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10685,41,9.65,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10685,47,9.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10686,17,39,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10686,26,31.23,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10687,9,97,50,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10687,29,123.79,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10687,36,19,6,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10688,10,31,18,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10688,28,45.6,60,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10688,34,14,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10689,1,18,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10690,56,38,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10690,77,13,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10691,1,18,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10691,29,123.79,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10691,43,46,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10691,44,19.45,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10691,62,49.3,48,0); " +
                    "INSERT INTO OrderDetails VALUES(10692,63,43.9,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10693,9,97,6,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10693,54,7.45,60,0.15); " +
                   "INSERT INTO OrderDetails VALUES(10693,69,36,30,0.15); " +
                   "INSERT INTO OrderDetails VALUES(10693,73,15,15,0.15); " +
                   "INSERT INTO OrderDetails VALUES(10694,7,30,90,0); " +
                   "INSERT INTO OrderDetails VALUES(10694,59,55,25,0); " +
                   "INSERT INTO OrderDetails VALUES(10694,70,15,50,0); " +
                   "INSERT INTO OrderDetails VALUES(10695,8,40,10,0); " +
                   "INSERT INTO OrderDetails VALUES(10695,12,38,4,0); " +
                   "INSERT INTO OrderDetails VALUES(10695,24,4.5,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10696,17,39,20,0); " +
                   "INSERT INTO OrderDetails VALUES(10696,46,12,18,0); " +
                   "INSERT INTO OrderDetails VALUES(10697,19,9.2,7,0.25); " +
                   "INSERT INTO OrderDetails VALUES(10697,35,18,9,0.25); " +
                   "INSERT INTO OrderDetails VALUES(10697,58,13.25,30,0.25); " +
                   "INSERT INTO OrderDetails VALUES(10697,70,15,30,0.25); " +
                   "INSERT INTO OrderDetails VALUES(10698,11,21,15,0); " +
                   "INSERT INTO OrderDetails VALUES(10698,17,39,8,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10698,29,123.79,12,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10698,65,21.05,65,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10698,70,15,8,0.05); " +
                   "INSERT INTO OrderDetails VALUES(10699,47,9.5,12,0); " +
                   "INSERT INTO OrderDetails VALUES(10700,1,18,5,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10700,34,14,12,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10700,68,12.5,40,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10700,71,21.5,60,0.2); " +
                   "INSERT INTO OrderDetails VALUES(10701,59,55,42,0.15); " +
                   "INSERT INTO OrderDetails VALUES(10701,71,21.5,20,0.15); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10701,76,18,35,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10702,3,10,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10702,76,18,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10703,2,19,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10703,59,55,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10703,73,15,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10704,4,22,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10704,24,4.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10704,48,12.75,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10705,31,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10705,32,32,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10706,16,17.45,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10706,43,46,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10706,59,55,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10707,55,24,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10707,57,19.5,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10707,70,15,28,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10708,5,21.35,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10708,36,19,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10709,8,40,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10709,51,53,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10709,60,34,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10710,19,9.2,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10710,47,9.5,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10711,19,9.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10711,41,9.65,42,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10711,53,32.8,120,0); " +
                    "INSERT INTO OrderDetails VALUES(10712,53,32.8,3,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10712,56,38,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10713,10,31,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10713,26,31.23,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10713,45,9.5,110,0); " +
                    "INSERT INTO OrderDetails VALUES(10713,46,12,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10714,2,19,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10714,17,39,27,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10714,47,9.5,50,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10714,56,38,18,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10714,58,13.25,12,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10715,10,31,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10715,71,21.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10716,21,10,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10716,51,53,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10716,61,28.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10717,21,10,32,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10717,54,7.45,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10717,69,36,25,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10718,12,38,36,0); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10718,16,17.45,20,0); " +
                     "INSERT INTO OrderDetails VALUES(10718,36,19,40,0); " +
                     "INSERT INTO OrderDetails VALUES(10718,62,49.3,20,0); " +
                     "INSERT INTO OrderDetails VALUES(10719,18,62.5,12,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10719,30,25.89,3,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10719,54,7.45,40,0.25); " +
                     "INSERT INTO OrderDetails VALUES(10720,35,18,21,0); " +
                     "INSERT INTO OrderDetails VALUES(10720,71,21.5,8,0); " +
                     "INSERT INTO OrderDetails VALUES(10721,44,19.45,50,0.05); " +
                     "INSERT INTO OrderDetails VALUES(10722,2,19,3,0); " +
                     "INSERT INTO OrderDetails VALUES(10722,31,12.5,50,0); " +
                     "INSERT INTO OrderDetails VALUES(10722,68,12.5,45,0); " +
                     "INSERT INTO OrderDetails VALUES(10722,75,7.75,42,0); " +
                     "INSERT INTO OrderDetails VALUES(10723,26,31.23,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10724,10,31,16,0); " +
                     "INSERT INTO OrderDetails VALUES(10724,61,28.5,5,0); " +
                     "INSERT INTO OrderDetails VALUES(10725,41,9.65,12,0); " +
                     "INSERT INTO OrderDetails VALUES(10725,52,7,4,0); " +
                     "INSERT INTO OrderDetails VALUES(10725,55,24,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10726,4,22,25,0); " +
                     "INSERT INTO OrderDetails VALUES(10726,11,21,5,0); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10727,17,39,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10727,56,38,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10727,59,55,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10728,30,25.89,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10728,40,18.4,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10728,55,24,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10728,60,34,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10729,1,18,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10729,21,10,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10729,50,16.25,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10730,16,17.45,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10730,31,12.5,3,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10730,65,21.05,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10731,21,10,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10731,51,53,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10732,76,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10733,14,23.25,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10733,28,45.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10733,52,7,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10734,6,25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10734,30,25.89,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10734,76,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10735,61,28.5,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10735,77,13,2,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10736,65,21.05,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10736,75,7.75,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10737,13,6,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10737,41,9.65,12,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10738,16,17.45,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10739,36,19,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10739,52,7,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10740,28,45.6,5,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10740,35,18,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10740,45,9.5,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10740,56,38,14,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10741,2,19,15,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10742,3,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10742,60,34,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10742,72,34.8,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10743,46,12,28,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10744,40,18.4,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10745,18,62.5,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10745,44,19.45,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10745,59,55,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10745,72,34.8,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10746,13,6,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10746,42,14,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10746,62,49.3,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10746,69,36,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10747,31,12.5,8,0); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10747,41,9.65,35,0); " +
                     "INSERT INTO OrderDetails VALUES(10747,63,43.9,9,0); " +
                     "INSERT INTO OrderDetails VALUES(10747,69,36,30,0); " +
                     "INSERT INTO OrderDetails VALUES(10748,23,9,44,0); " +
                     "INSERT INTO OrderDetails VALUES(10748,40,18.4,40,0); " +
                     "INSERT INTO OrderDetails VALUES(10748,56,38,28,0); " +
                     "INSERT INTO OrderDetails VALUES(10749,56,38,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10749,59,55,6,0); " +
                     "INSERT INTO OrderDetails VALUES(10749,76,18,10,0); " +
                     "INSERT INTO OrderDetails VALUES(10750,14,23.25,5,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10750,45,9.5,40,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10750,59,55,25,0.15); " +
                     "INSERT INTO OrderDetails VALUES(10751,26,31.23,12,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10751,30,25.89,30,0); " +
                     "INSERT INTO OrderDetails VALUES(10751,50,16.25,20,0.1); " +
                     "INSERT INTO OrderDetails VALUES(10751,73,15,15,0); " +
                     "INSERT INTO OrderDetails VALUES(10752,1,18,8,0); " +
                     "INSERT INTO OrderDetails VALUES(10752,69,36,3,0); " +
                     "INSERT INTO OrderDetails VALUES(10753,45,9.5,4,0); " +
                     "INSERT INTO OrderDetails VALUES(10753,74,10,5,0); " +
                     "INSERT INTO OrderDetails VALUES(10754,40,18.4,3,0); " +
                     "INSERT INTO OrderDetails VALUES(10755,47,9.5,30,0.25); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10755,56,38,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10755,57,19.5,14,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10755,69,36,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10756,18,62.5,21,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10756,36,19,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10756,68,12.5,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10756,69,36,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10757,34,14,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10757,59,55,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10757,62,49.3,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10757,64,33.25,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10758,26,31.23,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10758,52,7,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10758,70,15,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10759,32,32,10,0); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                  "INSERT INTO OrderDetails VALUES(10760,25,14,12,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10760,27,43.9,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10760,43,46,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10761,25,14,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10761,75,7.75,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10762,39,18,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10762,47,9.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10762,51,53,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10762,56,38,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10763,21,10,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10763,22,21,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10763,24,4.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10764,3,10,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10764,39,18,130,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10765,65,21.05,80,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10766,2,19,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10766,7,30,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10766,68,12.5,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10767,42,14,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10768,22,21,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10768,31,12.5,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10768,60,34,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10768,71,21.5,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10769,41,9.65,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10769,52,7,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10769,61,28.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10769,62,49.3,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10770,11,21,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10771,71,21.5,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10772,29,123.79,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10772,59,55,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10773,17,39,33,0); " +
                    "INSERT INTO OrderDetails VALUES(10773,31,12.5,70,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10773,75,7.75,7,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10774,31,12.5,2,0.25); ";
              cmd.ExecuteNonQuery();
              cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10774,66,17,50,0); " +
                      "INSERT INTO OrderDetails VALUES(10775,10,31,6,0); " +
                      "INSERT INTO OrderDetails VALUES(10775,67,14,3,0); " +
                      "INSERT INTO OrderDetails VALUES(10776,31,12.5,16,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10776,42,14,12,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10776,45,9.5,27,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10776,51,53,120,0.05); " +
                      "INSERT INTO OrderDetails VALUES(10777,42,14,20,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10778,41,9.65,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10779,16,17.45,20,0); " +
                      "INSERT INTO OrderDetails VALUES(10779,62,49.3,20,0); " +
                      "INSERT INTO OrderDetails VALUES(10780,70,15,35,0); " +
                      "INSERT INTO OrderDetails VALUES(10780,77,13,15,0); " +
                      "INSERT INTO OrderDetails VALUES(10781,54,7.45,3,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10781,56,38,20,0.2); " +
                      "INSERT INTO OrderDetails VALUES(10781,74,10,35,0); " +
                      "INSERT INTO OrderDetails VALUES(10782,31,12.5,1,0); " +
                      "INSERT INTO OrderDetails VALUES(10783,31,12.5,10,0); " +
                      "INSERT INTO OrderDetails VALUES(10783,38,263.5,5,0); " +
                      "INSERT INTO OrderDetails VALUES(10784,36,19,30,0); " +
                      "INSERT INTO OrderDetails VALUES(10784,39,18,2,0.15); " +
                      "INSERT INTO OrderDetails VALUES(10784,72,34.8,30,0.15); " +
                      "INSERT INTO OrderDetails VALUES(10785,10,31,10,0); ";
              cmd.ExecuteNonQuery();
            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10785,75,7.75,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10786,8,40,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10786,30,25.89,15,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10786,75,7.75,42,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10787,2,19,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10787,29,123.79,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10788,19,9.2,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10788,75,7.75,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10789,18,62.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10789,35,18,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10789,63,43.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10789,68,12.5,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10790,7,30,3,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10790,56,38,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10791,29,123.79,14,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10791,41,9.65,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10792,2,19,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10792,54,7.45,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10792,68,12.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10793,41,9.65,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10793,52,7,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10794,14,23.25,15,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10794,54,7.45,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10795,16,17.45,65,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10795,17,39,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10796,26,31.23,21,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10796,44,19.45,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10796,64,33.25,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10796,69,36,24,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10797,11,21,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10798,62,49.3,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10798,72,34.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10799,13,6,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10799,24,4.5,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10799,59,55,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10800,11,21,50,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10800,51,53,10,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10800,54,7.45,7,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10801,17,39,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10801,29,123.79,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10802,30,25.89,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10802,51,53,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10802,55,24,60,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10802,62,49.3,5,0.25); ";
               cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10803,19,9.2,24,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10803,25,14,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10803,59,55,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10804,10,31,36,0); " +
                    "INSERT INTO OrderDetails VALUES(10804,28,45.6,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10804,49,20,4,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10805,34,14,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10805,38,263.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10806,2,19,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10806,65,21.05,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10806,74,10,15,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10807,40,18.4,1,0); " +
                    "INSERT INTO OrderDetails VALUES(10808,56,38,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10808,76,18,50,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10809,52,7,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10810,13,6,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10810,25,14,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10810,70,15,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10811,19,9.2,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10811,23,9,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10811,40,18.4,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10812,31,12.5,16,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10812,72,34.8,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10812,77,13,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10813,2,19,12,0.2); " ;
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10813,46,12,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10814,41,9.65,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10814,43,46,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10814,48,12.75,8,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10814,61,28.5,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10815,33,2.5,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10816,38,263.5,30,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10816,62,49.3,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10817,26,31.23,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10817,38,263.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10817,40,18.4,60,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10817,62,49.3,25,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10818,32,32,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10818,41,9.65,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10819,43,46,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10819,75,7.75,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10820,56,38,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10821,35,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10821,51,53,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10822,62,49.3,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10822,70,15,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10823,11,21,20,0.1); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10823,57,19.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10823,59,55,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10823,77,13,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10824,41,9.65,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10824,70,15,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10825,26,31.23,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10825,53,32.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10826,31,12.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10826,57,19.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10827,10,31,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10827,39,18,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10828,20,81,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10828,38,263.5,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10829,2,19,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10829,8,40,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10829,13,6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10829,60,34,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10830,6,25,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10830,39,18,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10830,60,34,30,0); " ;
             cmd.ExecuteNonQuery();

           cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10830,68,12.5,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10831,19,9.2,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10831,35,18,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10831,38,263.5,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10831,43,46,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10832,13,6,3,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10832,25,14,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10832,44,19.45,16,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10832,64,33.25,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10833,7,30,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10833,31,12.5,9,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10833,53,32.8,9,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10834,29,123.79,8,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10834,30,25.89,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10835,59,55,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10835,77,13,2,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10836,22,21,52,0); " +
                    "INSERT INTO OrderDetails VALUES(10836,35,18,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10836,57,19.5,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10836,60,34,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10836,64,33.25,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10837,13,6,6,0); " ;
             cmd.ExecuteNonQuery();

            cmd.CommandText = 
                   "INSERT INTO OrderDetails VALUES(10837,40,18.4,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10837,47,9.5,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10837,76,18,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10838,1,18,4,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10838,18,62.5,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10838,36,19,50,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10839,58,13.25,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10839,72,34.8,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10840,25,14,6,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10840,39,18,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10841,10,31,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10841,56,38,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10841,59,55,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10841,77,13,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10842,11,21,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10842,43,46,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10842,68,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10842,70,15,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10843,51,53,4,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10844,22,21,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10845,23,9,70,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10845,35,18,25,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10845,42,14,42,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10845,58,13.25,60,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10845,64,33.25,48,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10846,4,22,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10846,70,15,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10846,74,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10847,1,18,80,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10847,19,9.2,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10847,37,26,60,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10847,45,9.5,36,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10847,60,34,45,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10847,71,21.5,55,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10848,5,21.35,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10848,9,97,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10849,3,10,49,0); " +
                    "INSERT INTO OrderDetails VALUES(10849,26,31.23,18,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10850,25,14,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10850,33,2.5,4,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10850,70,15,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10851,2,19,5,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10851,25,14,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10851,57,19.5,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10851,59,55,42,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10852,2,19,15,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                 "INSERT INTO OrderDetails VALUES(10852,17,39,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10852,62,49.3,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10853,18,62.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10854,10,31,100,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10854,13,6,65,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10855,16,17.45,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10855,31,12.5,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10855,56,38,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10855,65,21.05,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10856,2,19,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10856,42,14,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10857,3,10,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10857,26,31.23,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10857,29,123.79,10,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10858,7,30,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10858,27,43.9,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10858,70,15,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10859,24,4.5,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10859,54,7.45,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10859,64,33.25,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10860,51,53,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10860,76,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10861,17,39,42,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                   "INSERT INTO OrderDetails VALUES(10861,18,62.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10861,21,10,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10861,33,2.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10861,62,49.3,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10862,11,21,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10862,52,7,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10863,1,18,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10863,58,13.25,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10864,35,18,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10864,67,14,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10865,38,263.5,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10865,39,18,80,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10866,2,19,21,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10866,24,4.5,6,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10866,30,25.89,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10867,53,32.8,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10868,26,31.23,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10868,35,18,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10868,49,20,42,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10869,1,18,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10869,11,21,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10869,23,9,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10869,68,12.5,20,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10870,35,18,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10870,51,53,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10871,6,25,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10871,16,17.45,12,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10871,17,39,16,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10872,55,24,10,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10872,62,49.3,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10872,64,33.25,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10872,65,21.05,21,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10873,21,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10873,28,45.6,3,0); " +
                    "INSERT INTO OrderDetails VALUES(10874,10,31,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10875,19,9.2,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10875,47,9.5,21,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10875,49,20,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10876,46,12,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10876,64,33.25,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10877,16,17.45,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10877,18,62.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10878,20,81,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10879,40,18.4,12,0); " ;
         cmd.ExecuteNonQuery();

         cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10879,65,21.05,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10879,76,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10880,23,9,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10880,61,28.5,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10880,70,15,50,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10881,73,15,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10882,42,14,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10882,49,20,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10882,54,7.45,32,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10883,24,4.5,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10884,21,10,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10884,56,38,21,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10884,65,21.05,12,0.05); ";
         cmd.ExecuteNonQuery();

          cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10885,2,19,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10885,24,4.5,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10885,70,15,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10885,77,13,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10886,10,31,70,0); " +
                    "INSERT INTO OrderDetails VALUES(10886,31,12.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10886,77,13,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10887,25,14,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10888,2,19,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10888,68,12.5,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10889,11,21,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10889,38,263.5,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10890,17,39,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10890,34,14,10,0); " ;
          cmd.ExecuteNonQuery();

          cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10890,41,9.65,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10891,30,25.89,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10892,59,55,40,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10893,8,40,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10893,24,4.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10893,29,123.79,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10893,30,25.89,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10893,36,19,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10894,13,6,28,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10894,69,36,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10894,75,7.75,120,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10895,24,4.5,110,0); " +
                    "INSERT INTO OrderDetails VALUES(10895,39,18,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10895,40,18.4,91,0); " +
                    "INSERT INTO OrderDetails VALUES(10895,60,34,100,0); " +
                    "INSERT INTO OrderDetails VALUES(10896,45,9.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10896,56,38,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10897,29,123.79,80,0); " +
                    "INSERT INTO OrderDetails VALUES(10897,30,25.89,36,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10898,13,6,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10899,39,18,8,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10900,70,15,3,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10901,41,9.65,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10901,71,21.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10902,55,24,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10902,62,49.3,6,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10903,13,6,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10903,65,21.05,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10903,68,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10904,58,13.25,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10904,62,49.3,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10905,1,18,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10906,61,28.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10907,75,7.75,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10908,7,30,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10908,52,7,14,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10909,7,30,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10909,16,17.45,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10909,41,9.65,5,0); " ;
               cmd.ExecuteNonQuery();

             cmd.CommandText =
                "INSERT INTO OrderDetails VALUES(10910,19,9.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10910,49,20,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10910,61,28.5,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10911,1,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10911,17,39,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10911,67,14,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10912,11,21,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10912,29,123.79,60,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10913,4,22,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10913,33,2.5,40,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10913,58,13.25,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10914,71,21.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10915,17,39,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10915,33,2.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10915,54,7.45,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10916,16,17.45,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10916,32,32,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10916,57,19.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10917,30,25.89,1,0); " +
                    "INSERT INTO OrderDetails VALUES(10917,60,34,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10918,1,18,60,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10918,60,34,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10919,16,17.45,24,0); " ;
             cmd.ExecuteNonQuery();

              cmd.CommandText =
                 "INSERT INTO OrderDetails VALUES(10919,25,14,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10919,40,18.4,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10920,50,16.25,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10921,35,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10921,63,43.9,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10922,17,39,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10922,24,4.5,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10923,42,14,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10923,43,46,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10923,67,14,24,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10924,10,31,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10924,28,45.6,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10924,75,7.75,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10925,36,19,25,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10925,52,7,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10926,11,21,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10926,13,6,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10926,19,9.2,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10926,72,34.8,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10927,20,81,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10927,52,7,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10927,76,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10928,47,9.5,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10928,76,18,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10929,21,10,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10929,75,7.75,49,0); " +
                    "INSERT INTO OrderDetails VALUES(10929,77,13,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10930,21,10,36,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10930,27,43.9,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10930,55,24,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10930,58,13.25,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10931,13,6,42,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10931,57,19.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10932,16,17.45,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10932,62,49.3,14,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10932,72,34.8,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10932,75,7.75,20,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10933,53,32.8,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10933,61,28.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10934,6,25,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10935,1,18,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10935,18,62.5,4,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10935,23,9,8,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10936,36,19,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10937,28,45.6,8,0); " ;
          cmd.ExecuteNonQuery();

          cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10937,34,14,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10938,13,6,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10938,43,46,24,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10938,60,34,49,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10938,71,21.5,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10939,2,19,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10939,67,14,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10940,7,30,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10940,13,6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10941,31,12.5,44,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10941,62,49.3,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10941,68,12.5,80,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10941,72,34.8,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10942,49,20,28,0); " +
                    "INSERT INTO OrderDetails VALUES(10943,13,6,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10943,22,21,21,0); " +
                    "INSERT INTO OrderDetails VALUES(10943,46,12,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10944,11,21,5,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10944,44,19.45,18,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10944,56,38,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10945,13,6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10945,31,12.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10946,10,31,25,0); " ;
             cmd.ExecuteNonQuery();

            cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10946,24,4.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(10946,77,13,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10947,59,55,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10948,50,16.25,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10948,51,53,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10948,55,24,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10949,6,25,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10949,10,31,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10949,17,39,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10949,62,49.3,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10950,4,22,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10951,33,2.5,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10951,41,9.65,6,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10951,75,7.75,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10952,6,25,16,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10952,28,45.6,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10953,20,81,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10953,31,12.5,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10954,16,17.45,28,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10954,31,12.5,25,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10954,45,9.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10954,60,34,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10955,75,7.75,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10956,21,10,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10956,47,9.5,14,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(10956,51,53,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10957,30,25.89,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10957,35,18,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10957,64,33.25,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10958,5,21.35,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10958,7,30,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10958,72,34.8,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10959,75,7.75,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10960,24,4.5,10,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10960,41,9.65,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10961,52,7,6,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10961,76,18,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10962,7,30,45,0); " +
                    "INSERT INTO OrderDetails VALUES(10962,13,6,77,0); " +
                    "INSERT INTO OrderDetails VALUES(10962,53,32.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10962,69,36,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10962,76,18,44,0); " +
                    "INSERT INTO OrderDetails VALUES(10963,60,34,2,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10964,18,62.5,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10964,38,263.5,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10964,69,36,10,0); " ;
           cmd.ExecuteNonQuery();

           cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10965,51,53,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10966,37,26,8,0); " +
                    "INSERT INTO OrderDetails VALUES(10966,56,38,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10966,62,49.3,12,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10967,19,9.2,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10967,49,20,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10968,12,38,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10968,24,4.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10968,64,33.25,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10969,46,12,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10970,52,7,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10971,29,123.79,14,0); " +
                    "INSERT INTO OrderDetails VALUES(10972,17,39,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10972,33,2.5,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10973,26,31.23,5,0); " +
                    "INSERT INTO OrderDetails VALUES(10973,41,9.65,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10973,75,7.75,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10974,63,43.9,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10975,8,40,16,0); " +
                    "INSERT INTO OrderDetails VALUES(10975,75,7.75,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10976,28,45.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10977,39,18,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10977,47,9.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10977,51,53,10,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(10977,63,43.9,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10978,8,40,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10978,21,10,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10978,40,18.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10978,44,19.45,6,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10979,7,30,18,0); " +
                    "INSERT INTO OrderDetails VALUES(10979,12,38,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10979,24,4.5,80,0); " +
                    "INSERT INTO OrderDetails VALUES(10979,27,43.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10979,31,12.5,24,0); " +
                    "INSERT INTO OrderDetails VALUES(10979,63,43.9,35,0); " +
                    "INSERT INTO OrderDetails VALUES(10980,75,7.75,40,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10981,38,263.5,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10982,7,30,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10982,43,46,9,0); " +
                    "INSERT INTO OrderDetails VALUES(10983,13,6,84,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10983,57,19.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10984,16,17.45,55,0); " +
                    "INSERT INTO OrderDetails VALUES(10984,24,4.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10984,36,19,40,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10985,16,17.45,36,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10985,18,62.5,8,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10985,32,32,35,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10986,11,21,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10986,20,81,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10986,76,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(10986,77,13,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10987,7,30,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10987,43,46,6,0); " +
                    "INSERT INTO OrderDetails VALUES(10987,72,34.8,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10988,7,30,60,0); " +
                    "INSERT INTO OrderDetails VALUES(10988,62,49.3,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(10989,6,25,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10989,11,21,15,0); " +
                    "INSERT INTO OrderDetails VALUES(10989,41,9.65,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10990,21,10,65,0); " +
                    "INSERT INTO OrderDetails VALUES(10990,34,14,60,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10990,55,24,65,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10990,61,28.5,66,0.15); " +
                    "INSERT INTO OrderDetails VALUES(10991,2,19,50,0.2); " ;
         cmd.ExecuteNonQuery();

         cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(10991,70,15,20,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10991,76,18,90,0.2); " +
                    "INSERT INTO OrderDetails VALUES(10992,72,34.8,2,0); " +
                    "INSERT INTO OrderDetails VALUES(10993,29,123.79,50,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10993,41,9.65,35,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10994,59,55,18,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10995,51,53,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10995,60,34,4,0); " +
                    "INSERT INTO OrderDetails VALUES(10996,42,14,40,0); " +
                    "INSERT INTO OrderDetails VALUES(10997,32,32,50,0); " +
                    "INSERT INTO OrderDetails VALUES(10997,46,12,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10997,52,7,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(10998,24,4.5,12,0); " +
                    "INSERT INTO OrderDetails VALUES(10998,61,28.5,7,0); " +
                    "INSERT INTO OrderDetails VALUES(10998,74,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(10998,75,7.75,30,0); " +
                    "INSERT INTO OrderDetails VALUES(10999,41,9.65,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10999,51,53,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(10999,77,13,21,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11000,4,22,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11000,24,4.5,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11000,77,13,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11001,7,30,60,0); " ;
          cmd.ExecuteNonQuery();

          cmd.CommandText = 
                    "INSERT INTO OrderDetails VALUES(11001,22,21,25,0); " +
                    "INSERT INTO OrderDetails VALUES(11001,46,12,25,0); " +
                    "INSERT INTO OrderDetails VALUES(11001,55,24,6,0); " +
                    "INSERT INTO OrderDetails VALUES(11002,13,6,56,0); " +
                    "INSERT INTO OrderDetails VALUES(11002,35,18,15,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11002,42,14,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11002,55,24,40,0); " +
                    "INSERT INTO OrderDetails VALUES(11003,1,18,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11003,40,18.4,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11003,52,7,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11004,26,31.23,6,0); " +
                    "INSERT INTO OrderDetails VALUES(11004,76,18,6,0); " +
                    "INSERT INTO OrderDetails VALUES(11005,1,18,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11005,59,55,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11006,1,18,8,0); " +
                    "INSERT INTO OrderDetails VALUES(11006,29,123.79,2,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11007,8,40,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11007,29,123.79,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11007,42,14,14,0); " +
                    "INSERT INTO OrderDetails VALUES(11008,28,45.6,70,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11008,34,14,90,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11008,71,21.5,21,0); " +
                    "INSERT INTO OrderDetails VALUES(11009,24,4.5,12,0); " +
                    "INSERT INTO OrderDetails VALUES(11009,36,19,18,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11009,60,34,9,0); " +
                    "INSERT INTO OrderDetails VALUES(11010,7,30,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11010,24,4.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11011,58,13.25,40,0.05); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(11011,71,21.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11012,19,9.2,50,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11012,60,34,36,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11012,71,21.5,60,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11013,23,9,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11013,42,14,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11013,45,9.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11013,68,12.5,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11014,41,9.65,28,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11015,30,25.89,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11015,77,13,18,0); " +
                    "INSERT INTO OrderDetails VALUES(11016,31,12.5,15,0); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(11016,36,19,16,0); " +
                    "INSERT INTO OrderDetails VALUES(11017,3,10,25,0); " +
                    "INSERT INTO OrderDetails VALUES(11017,59,55,110,0); " +
                    "INSERT INTO OrderDetails VALUES(11017,70,15,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11018,12,38,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11018,18,62.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11018,56,38,5,0); " +
                    "INSERT INTO OrderDetails VALUES(11019,46,12,3,0); " +
                    "INSERT INTO OrderDetails VALUES(11019,49,20,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11020,10,31,24,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11021,2,19,11,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11021,20,81,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11021,26,31.23,63,0); " +
                    "INSERT INTO OrderDetails VALUES(11021,51,53,44,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11021,72,34.8,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11022,19,9.2,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11022,69,36,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11023,7,30,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11023,43,46,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11024,26,31.23,12,0); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                     "INSERT INTO OrderDetails VALUES(11024,33,2.5,30,0); " +
                     "INSERT INTO OrderDetails VALUES(11024,65,21.05,21,0); " +
                     "INSERT INTO OrderDetails VALUES(11024,71,21.5,50,0); " +
                     "INSERT INTO OrderDetails VALUES(11025,1,18,10,0.1); " +
                     "INSERT INTO OrderDetails VALUES(11025,13,6,20,0.1); " +
                     "INSERT INTO OrderDetails VALUES(11026,18,62.5,8,0); " +
                     "INSERT INTO OrderDetails VALUES(11026,51,53,10,0); " +
                     "INSERT INTO OrderDetails VALUES(11027,24,4.5,30,0.25); " +
                     "INSERT INTO OrderDetails VALUES(11027,62,49.3,21,0.25); " +
                     "INSERT INTO OrderDetails VALUES(11028,55,24,35,0); " +
                     "INSERT INTO OrderDetails VALUES(11028,59,55,24,0); " +
                     "INSERT INTO OrderDetails VALUES(11029,56,38,20,0); " +
                     "INSERT INTO OrderDetails VALUES(11029,63,43.9,12,0); " +
                     "INSERT INTO OrderDetails VALUES(11030,2,19,100,0.25); " +
                     "INSERT INTO OrderDetails VALUES(11030,5,21.35,70,0); " +
                     "INSERT INTO OrderDetails VALUES(11030,29,123.79,60,0.25); " +
                     "INSERT INTO OrderDetails VALUES(11030,59,55,100,0.25); ";
             cmd.ExecuteNonQuery();

             cmd.CommandText =
                 "INSERT INTO OrderDetails VALUES(11031,1,18,45,0); " +
                    "INSERT INTO OrderDetails VALUES(11031,13,6,80,0); " +
                    "INSERT INTO OrderDetails VALUES(11031,24,4.5,21,0); " +
                    "INSERT INTO OrderDetails VALUES(11031,64,33.25,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11031,71,21.5,16,0); " +
                    "INSERT INTO OrderDetails VALUES(11032,36,19,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11032,38,263.5,25,0); " +
                    "INSERT INTO OrderDetails VALUES(11032,59,55,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11033,53,32.8,70,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11033,69,36,36,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11034,21,10,15,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11034,44,19.45,12,0); " +
                    "INSERT INTO OrderDetails VALUES(11034,61,28.5,6,0); " +
                    "INSERT INTO OrderDetails VALUES(11035,1,18,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11035,35,18,60,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(11035,42,14,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11035,54,7.45,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11036,13,6,7,0); " +
                    "INSERT INTO OrderDetails VALUES(11036,59,55,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11037,70,15,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11038,40,18.4,5,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11038,52,7,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11038,71,21.5,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11039,28,45.6,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11039,35,18,24,0); " +
                    "INSERT INTO OrderDetails VALUES(11039,49,20,60,0); " +
                    "INSERT INTO OrderDetails VALUES(11039,57,19.5,28,0); " +
                    "INSERT INTO OrderDetails VALUES(11040,21,10,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11041,2,19,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11041,63,43.9,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11042,44,19.45,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11042,61,28.5,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11043,11,21,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11044,62,49.3,12,0); " +
                    "INSERT INTO OrderDetails VALUES(11045,33,2.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11045,51,53,24,0); " +
                    "INSERT INTO OrderDetails VALUES(11046,12,38,20,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11046,32,32,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11046,35,18,18,0.05); " ;
          cmd.ExecuteNonQuery();

          cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(11047,1,18,25,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11047,5,21.35,30,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11048,68,12.5,42,0); " +
                    "INSERT INTO OrderDetails VALUES(11049,2,19,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11049,12,38,4,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11050,76,18,50,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11051,24,4.5,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11052,43,46,30,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11052,61,28.5,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11053,18,62.5,35,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11053,32,32,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11053,64,33.25,25,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11054,33,2.5,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11054,67,14,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11055,24,4.5,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11055,25,14,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11055,51,53,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11055,57,19.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11056,7,30,40,0); " +
                    "INSERT INTO OrderDetails VALUES(11056,55,24,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11056,60,34,50,0); " +
                    "INSERT INTO OrderDetails VALUES(11057,70,15,3,0); " +
                    "INSERT INTO OrderDetails VALUES(11058,21,10,3,0); " +
                    "INSERT INTO OrderDetails VALUES(11058,60,34,21,0); " +
                    "INSERT INTO OrderDetails VALUES(11058,61,28.5,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11059,13,6,30,0); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(11059,17,39,12,0); " +
                    "INSERT INTO OrderDetails VALUES(11059,60,34,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11060,60,34,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11060,77,13,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11061,60,34,15,0); " +
                    "INSERT INTO OrderDetails VALUES(11062,53,32.8,10,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11062,70,15,12,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11063,34,14,30,0); " +
                    "INSERT INTO OrderDetails VALUES(11063,40,18.4,40,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11063,41,9.65,30,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11064,17,39,77,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11064,41,9.65,12,0); " +
                    "INSERT INTO OrderDetails VALUES(11064,53,32.8,25,0.1); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(11064,55,24,4,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11064,68,12.5,55,0); " +
                    "INSERT INTO OrderDetails VALUES(11065,30,25.89,4,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11065,54,7.45,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11066,16,17.45,3,0); " +
                    "INSERT INTO OrderDetails VALUES(11066,19,9.2,42,0); " +
                    "INSERT INTO OrderDetails VALUES(11066,34,14,35,0); " +
                    "INSERT INTO OrderDetails VALUES(11067,41,9.65,9,0); " +
                    "INSERT INTO OrderDetails VALUES(11068,28,45.6,8,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11068,43,46,36,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11068,77,13,28,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11069,39,18,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11070,1,18,40,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11070,2,19,20,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11070,16,17.45,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11070,31,12.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11071,7,30,15,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11071,13,6,10,0.05); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO OrderDetails VALUES(11072,2,19,8,0); " +
                    "INSERT INTO OrderDetails VALUES(11072,41,9.65,40,0); " +
                    "INSERT INTO OrderDetails VALUES(11072,50,16.25,22,0); " +
                    "INSERT INTO OrderDetails VALUES(11072,64,33.25,130,0); " +
                    "INSERT INTO OrderDetails VALUES(11073,11,21,10,0); " +
                    "INSERT INTO OrderDetails VALUES(11073,24,4.5,20,0); " +
                    "INSERT INTO OrderDetails VALUES(11074,16,17.45,14,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11075,2,19,10,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11075,46,12,30,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11075,76,18,2,0.15); " +
                    "INSERT INTO OrderDetails VALUES(11076,6,25,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11076,14,23.25,20,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11076,19,9.2,10,0.25); " +
                    "INSERT INTO OrderDetails VALUES(11077,2,19,24,0.2); " +
                    "INSERT INTO OrderDetails VALUES(11077,3,10,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,4,22,1,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,6,25,1,0.02); " +
                    "INSERT INTO OrderDetails VALUES(11077,7,30,1,0.05); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO OrderDetails VALUES(11077,8,40,2,0.1); " +
                    "INSERT INTO OrderDetails VALUES(11077,10,31,1,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,12,38,2,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11077,13,6,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,14,23.25,1,0.03); " +
                    "INSERT INTO OrderDetails VALUES(11077,16,17.45,2,0.03); " +
                    "INSERT INTO OrderDetails VALUES(11077,20,81,1,0.04); " +
                    "INSERT INTO OrderDetails VALUES(11077,23,9,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,32,32,1,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,39,18,2,0.05); " +
                    "INSERT INTO OrderDetails VALUES(11077,41,9.65,3,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,46,12,3,0.02); " +
                    "INSERT INTO OrderDetails VALUES(11077,52,7,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,55,24,2,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,60,34,2,0.06); " +
                    "INSERT INTO OrderDetails VALUES(11077,64,33.25,2,0.03); " +
                    "INSERT INTO OrderDetails VALUES(11077,66,17,1,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,73,15,2,0.01); " +
                    "INSERT INTO OrderDetails VALUES(11077,75,7.75,4,0); " +
                    "INSERT INTO OrderDetails VALUES(11077,77,13,2,0); " ;
            cmd.ExecuteNonQuery();
         }

        static private void LoadEmployees(TdCommand cmd)
        {
            cmd.CommandText =
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Davolio', 'Nancy', 'Sales Representative', 'Ms.',DATE '1948-12-08',DATE '1992-05-01', '507 - 20th Ave. E.Apt. 2A', 'Seattle', 'WA', '98122', 'USA', '(206) 555-9857', '5467', NULL, 'Education includes a BA in psychology from Colorado State University in 1970.  She also completed The Art of the Cold Call.  Nancy is a member of Toastmasters International.','http://accweb/emmployees/davolio.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Fuller', 'Andrew', 'Vice President,Sales', 'Dr.',DATE '1952-02-19',DATE '1992-08-14', '908 W. Capital Way', 'Tacoma', 'WA', '98401', 'USA', '(206) 555-9482', '3457', NULL, 'Andrew received his BTS commercial in 1974 and a Ph.D. in international marketing from the University of Dallas in 1981. He is fluent in French and Italian and reads German. He joined the company as a sales representative,was promoted to sales manager in January 1992 and to vice president of sales in March 1993. Andrew is a member of the Sales Management Roundtable,the Seattle Chamber of Commerce,and the Pacific Rim Importers Association.','http://accweb/emmployees/fuller.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Leverling', 'Janet', 'Sales Representative', 'Ms.',DATE '1963-08-30',DATE '1992-04-01', '722 Moss Bay Blvd.', 'Kirkland', 'WA', '98033', 'USA', '(206) 555-3412', '3355', NULL, 'Janet has a BS degree in chemistry from Boston College (1984). She has also completed a certificate program in food retailing management. Janet was hired as a sales associate in 1991 and promoted to sales representative in February 1992.','http://accweb/emmployees/leverling.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Peacock', 'Margaret', 'Sales Representative', 'Mrs.',DATE '1937-09-19',DATE '1993-05-03', '4110 Old Redmond Rd.', 'Redmond', 'WA', '98052', 'USA', '(206) 555-8122', '5176', NULL, 'Margaret holds a BA in English literature from Concordia College (1958) and an MA from the American Institute of Culinary Arts (1966). She was assigned to the London office temporarily from July through November 1992.','http://accweb/emmployees/peacock.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Buchanan', 'Steven', 'Sales Manager', 'Mr.',DATE '1955-03-04',DATE '1993-10-17', '14 Garrett Hill', 'London',NULL,'SW1 8JR', 'UK', '(71) 555-4848', '3453', NULL, 'Steven Buchanan graduated from St. Andrews University,Scotland,with a BSC degree in 1976. Upon joining the company as a sales representative in 1992,he spent 6 months in an orientation program at the Seattle office and then returned to his permanent post in London. He was promoted to sales manager in March 1993. Mr. Buchanan has completed the courses Successful Telemarketing and International Sales Management. He is fluent in French.','http://accweb/emmployees/buchanan.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Suyama', 'Michael', 'Sales Representative', 'Mr.',DATE '1963-07-02',DATE '1993-10-17', 'Coventry House Miner Rd.', 'London',NULL,'EC2 7JR', 'UK', '(71) 555-7773', '428', NULL, 'Michael is a graduate of Sussex University (MA, economics, 1983) and the University of California at Los Angeles (MBA, marketing, 1986).  He has also taken the courses Multi-Cultural Selling and Time Management for the Sales Professional.  He is fluent in Japanese and can read and write French, Portuguese, and Spanish.','http://accweb/emmployees/davolio.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('King', 'Robert', 'Sales Representative', 'Mr.',DATE '1960-05-29',DATE '1994-01-02', 'Edgeham HollowWinchester Way', 'London',NULL,'RG1 9SP', 'UK', '(71) 555-5598', '465', NULL, 'Robert King served in the Peace Corps and traveled extensively before completing his degree in English at the University of Michigan in 1992, the year he joined the company.  After completing a course entitled Selling in Europe, he was transferred to the London office in March 1993.','http://accweb/emmployees/davolio.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Callahan', 'Laura', 'Inside Sales Coordinator', 'Ms.',DATE '1958-01-09',DATE '1994-03-05', '4726 - 11th Ave. N.E.', 'Seattle', 'WA', '98105', 'USA', '(206) 555-1189', '2344', NULL, 'Laura received a BA in psychology from the University of Washington. She has also completed a course in business French. She reads and writes French.','http://accweb/emmployees/davolio.bmp'); " +
                "INSERT INTO Employees(LastName,FirstName,\"Title\",TitleOfCourtesy,BirthDate,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,Notes,PhotoPath) VALUES('Dodsworth', 'Anne', 'Sales Representative', 'Ms.',DATE '1966-01-27',DATE '1994-11-15', '7 Houndstooth Rd.', 'London',NULL,'WG2 7LT', 'UK', '(71) 555-4444', '452', NULL, 'Anne has a BA degree in English from St. Lawrence College. She is fluent in French and German.','http://accweb/emmployees/davolio.bmp');";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO PreviousEmployees SELECT * from Employees WHERE EmployeeID = 7;";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "DELETE FROM Employees WHERE EmployeeID = 7;";
            cmd.ExecuteNonQuery();

        }

        static private void LoadShippers(TdCommand cmd)
        {
            cmd.CommandText =
                "INSERT INTO Shippers(CompanyName,Phone) VALUES('Speedy Express', '(503) 555-9831'); " +
                "INSERT INTO Shippers(CompanyName,Phone) VALUES('United Package', '(503) 555-3199');" +
                "INSERT INTO Shippers(CompanyName,Phone) VALUES('Federal Shipping', '(503) 555-9931');";
            cmd.ExecuteNonQuery();

        }

       static  private void LoadRegions(TdCommand cmd)
        {
            cmd.CommandText = "INSERT INTO Regions Values (1,'Eastern'); " +
                               "INSERT INTO Regions Values (2,'Western'); " +
                               "INSERT INTO Regions Values (3,'Northern'); " +
                               "INSERT INTO Regions Values (4,'Southern'); ";
            cmd.ExecuteNonQuery();

        }

        static private void LoadEmployeeTerritories(TdCommand cmd)
        {
            cmd.CommandText =
                    "INSERT INTO EmployeesTerritories Values (1,'06897'); " +
                    "INSERT INTO EmployeesTerritories Values (1,'19713'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'01581'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'01730'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'01833'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'02116'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'02139'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'02184'); " +
                    "INSERT INTO EmployeesTerritories Values (2,'40222'); " +
                    "INSERT INTO EmployeesTerritories Values (3,'30346'); " +
                    "INSERT INTO EmployeesTerritories Values (3,'31406'); " +
                    "INSERT INTO EmployeesTerritories Values (3,'32859'); " +
                    "INSERT INTO EmployeesTerritories Values (3,'33607'); " +
                    "INSERT INTO EmployeesTerritories Values (4,'20852'); " +
                    "INSERT INTO EmployeesTerritories Values (4,'27403'); " +
                    "INSERT INTO EmployeesTerritories Values (4,'27511'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'02903'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO EmployeesTerritories Values (5,'07960'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'08837'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'10019'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'10038'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'11747'); " +
                    "INSERT INTO EmployeesTerritories Values (5,'14450'); " +
                    "INSERT INTO EmployeesTerritories Values (6,'85014'); " +
                    "INSERT INTO EmployeesTerritories Values (6,'85251'); " +
                    "INSERT INTO EmployeesTerritories Values (6,'98004'); " +
                    "INSERT INTO EmployeesTerritories Values (6,'98052'); " +
                    "INSERT INTO EmployeesTerritories Values (6,'98104'); " +
                    "INSERT INTO EmployeesTerritories Values (8,'19428'); " +
                    "INSERT INTO EmployeesTerritories Values (8,'44122'); " +
                    "INSERT INTO EmployeesTerritories Values (8,'45839'); " +
                    "INSERT INTO EmployeesTerritories Values (8,'53404'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'03049'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'03801'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'48075'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'48084'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'48304'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'55113'); " +
                    "INSERT INTO EmployeesTerritories Values (9,'55439'); ";
            cmd.ExecuteNonQuery();

        }

        static private void LoadTerritories(TdCommand cmd)
        {
            cmd.CommandText =
                               "INSERT INTO Territories Values ('01581', 'Westboro',1); " +
                               "INSERT INTO Territories Values ('01730', 'Bedford',1); " +
                               "INSERT INTO Territories Values ('01833', 'Georgetow',1); " +
                               "INSERT INTO Territories Values ('02116', 'Boston',1); " +
                               "INSERT INTO Territories Values ('02139', 'Cambridge',1); " +
                               "INSERT INTO Territories Values ('02184', 'Braintree',1); " +
                               "INSERT INTO Territories Values ('02903', 'Providence',1); " +
                               "INSERT INTO Territories Values ('03049', 'Hollis',3); " +
                               "INSERT INTO Territories Values ('03801', 'Portsmouth',3); " +
                               "INSERT INTO Territories Values ('06897', 'Wilton',1); " +
                               "INSERT INTO Territories Values ('07960', 'Morristown',1); " +
                               "INSERT INTO Territories Values ('08837', 'Edison',1); " +
                               "INSERT INTO Territories Values ('10019', 'New York',1); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                              "INSERT INTO Territories Values ('10038', 'New York',1); " +
                               "INSERT INTO Territories Values ('11747', 'Mellvile',1); " +
                               "INSERT INTO Territories Values ('14450', 'Fairport',1); " +
                               "INSERT INTO Territories Values ('19428', 'Philadelphia',3); " +
                               "INSERT INTO Territories Values ('19713', 'Neward',1); " +
                               "INSERT INTO Territories Values ('20852', 'Rockville',1); " +
                               "INSERT INTO Territories Values ('27403', 'Greensboro',1); " +
                               "INSERT INTO Territories Values ('27511', 'Cary',1); " +
                               "INSERT INTO Territories Values ('29202', 'Columbia',4); " +
                               "INSERT INTO Territories Values ('30346', 'Atlanta',4); " +
                               "INSERT INTO Territories Values ('31406', 'Savannah',4); " +
                               "INSERT INTO Territories Values ('32859', 'Orlando',4); " +
                               "INSERT INTO Territories Values ('33607', 'Tampa',4); " +
                               "INSERT INTO Territories Values ('40222', 'Louisville',1); " +
                               "INSERT INTO Territories Values ('44122', 'Beachwood',3); " +
                               "INSERT INTO Territories Values ('45839', 'Findlay',3); " +
                               "INSERT INTO Territories Values ('48075', 'Southfield',3);";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                               "INSERT INTO Territories Values ('48084', 'Troy',3);  " +
                               "INSERT INTO Territories Values ('48304', 'Bloomfield Hills',3); " +
                               "INSERT INTO Territories Values ('53404', 'Racine',3); " +
                               "INSERT INTO Territories Values ('55113', 'Roseville',3); " +
                               "INSERT INTO Territories Values ('55439', 'Minneapolis',3); " +
                               "INSERT INTO Territories Values ('60179', 'Hoffman Estates',2); " +
                               "INSERT INTO Territories Values ('60601', 'Chicago',2); " +
                               "INSERT INTO Territories Values ('72716', 'Bentonville',4); " +
                               "INSERT INTO Territories Values ('75234', 'Dallas',4); " +
                               "INSERT INTO Territories Values ('78759', 'Austin',4); " +
                               "INSERT INTO Territories Values ('80202', 'Denver',2); " +
                               "INSERT INTO Territories Values ('80909', 'Colorado Springs',2); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                               "INSERT INTO Territories Values ('85014', 'Phoenix',2); " +
                               "INSERT INTO Territories Values ('85251', 'Scottsdale',2); " +
                               "INSERT INTO Territories Values ('90405', 'Santa Monica',2); " +
                               "INSERT INTO Territories Values ('94025', 'Menlo Park',2); " +
                               "INSERT INTO Territories Values ('94105', 'San Francisco',2); " +
                               "INSERT INTO Territories Values ('95008', 'Campbell',2); " +
                               "INSERT INTO Territories Values ('95054', 'Santa Clara',2); " +
                               "INSERT INTO Territories Values ('95060', 'Santa Cruz',2); " +
                               "INSERT INTO Territories Values ('98004', 'Bellevue',2); " +
                               "INSERT INTO Territories Values ('98052', 'Redmond',2); " +
                               "INSERT INTO Territories Values ('98104', 'Seattle',2); ";
            cmd.ExecuteNonQuery();
        }

        static private void LoadSupliers(TdCommand cmd)
        {
            cmd.CommandText =
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Exotic Liquids', 'Charlotte Cooper', 'Purchasing Manager', '49 Gilbert St.', 'London',NULL,'EC1 4SD', 'UK', '(171) 555-2222',NULL,NULL); " +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('New Orleans Cajun Delights', 'Shelley Burke', 'Order Administrator', 'P.O. Box 78934', 'New Orleans', 'LA', '70117', 'USA', '(100) 555-4822',NULL,'#CAJUN.HTM#');" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Grandma Kelly''s Homestead', 'Regina Murphy', 'Sales Representative', '707 Oxford Rd.', 'Ann Arbor', 'MI', '48104', 'USA', '(313) 555-5735', '(313) 555-3349',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Tokyo Traders', 'Yoshi Nagase', 'Marketing Manager', '9-8 Sekimai Musashino-shi', 'Tokyo',NULL,'100', 'Japan', '(03) 3555-5011',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Cooperativa de Quesos ''Las Cabras''', 'Antonio del Valle Saavedra', 'Export Administrator', 'Calle del Rosal 4', 'Oviedo', 'Asturias', '33007', 'Spain', '(98) 598 76 54',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Mayumi''s', 'Mayumi Ohno', 'Marketing Representative', '92 Setsuko Chuo-ku', 'Osaka',NULL,'545', 'Japan', '(06) 431-7877',NULL,'Mayumi''s (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/mayumi.htm#');" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Pavlova,Ltd.', 'Ian Devling', 'Marketing Manager', '74 Rose St. Moonie Ponds', 'Melbourne', 'Victoria', '3058', 'Australia', '(03) 444-2343', '(03) 444-6588',NULL);";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
               "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Specialty Biscuits,Ltd.', 'Peter Wilson', 'Sales Representative', '29 King''s Way', 'Manchester',NULL,'M14 GSD', 'UK', '(161) 555-4448',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('PB Knäckebröd AB', 'Lars Peterson', 'Sales Agent', 'Kaloadagatan 13', 'Göteborg',NULL,'S-345 67', 'Sweden', '031-987 65 43', '031-987 65 91',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Refrescos Americanas LTDA', 'Carlos Diaz', 'Marketing Manager', 'Av. das Americanas 12.890', 'Sao Paulo',NULL,'5442', 'Brazil', '(11) 555 4640',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Heli Süßwaren GmbH & Co. KG', 'Petra Winkler', 'Sales Manager', 'Tiergartenstraße 5', 'Berlin',NULL,'10785', 'Germany', '(010) 9984510',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Plutzer Lebensmittelgroßmärkte AG', 'Martin Bein', 'International Marketing Mgr.', 'Bogenallee 51', 'Frankfurt',NULL,'60439', 'Germany', '(069) 992755',NULL,'Plutzer (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/plutzer.htm#');" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Nord-Ost-Fisch Handelsgesellschaft mbH', 'Sven Petersen', 'Coordinator Foreign Markets', 'Frahmredder 112a', 'Cuxhaven',NULL,'27478', 'Germany', '(04721) 8713', '(04721) 8714',NULL);" ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Formaggi Fortini s.r.l.', 'Elio Rossi', 'Sales Representative', 'Viale Dante,75', 'Ravenna',NULL,'48100', 'Italy', '(0544) 60323', '(0544) 60603', '#FORMAGGI.HTM#');" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Norske Meierier', 'Beate Vileid', 'Marketing Manager', 'Hatlevegen 5', 'Sandvika',NULL,'1320', 'Norway', '(0)2-953010',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Bigfoot Breweries', 'Cheryl Saylor', 'Regional Account Rep.', '3400 - 8th Avenue Suite 210', 'Bend', 'OR', '97101', 'USA', '(503) 555-9931',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Svensk Sjöföda AB', 'Michael Björn', 'Sales Representative', 'Brovallavägen 231', 'Stockholm',NULL,'S-123 45', 'Sweden', '08-123 45 67',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Aux joyeux ecclésiastiques', 'Guylène Nodier', 'Sales Manager', '203,Rue des Francs-Bourgeois', 'Paris',NULL,'75004', 'France', '(1) 03.83.00.68', '(1) 03.83.00.62',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('New England Seafood Cannery', 'Robb Merchant', 'Wholesale Account Agent', 'Order Processing Dept. 2100 Paul Revere Blvd.', 'Boston', 'MA', '02134', 'USA', '(617) 555-3267', '(617) 555-3389',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Leka Trading', 'Chandra Leka', 'Owner', '471 Serangoon Loop,Suite #402', 'Singapore',NULL,'0512', 'Singapore', '555-8787',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Lyngbysild', 'Niels Petersen', 'Sales Manager', 'Lyngbysild Fiskebakken 10', 'Lyngby',NULL,'2800', 'Denmark', '43844108', '43844115',NULL);";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
               "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Zaanse Snoepfabriek', 'Dirk Luchte', 'Accounting Manager', 'Verkoop Rijnweg 22', 'Zaandam',NULL,'9999 ZZ', 'Netherlands', '(12345) 1212', '(12345) 1210',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Karkki Oy', 'Anne Heikkonen', 'Product Manager', 'Valtakatu 12', 'Lappeenranta',NULL,'53120', 'Finland', '(953) 10956',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('G''day,Mate', 'Wendy Mackenzie', 'Sales Representative', '170 Prince Edward Parade Hunter''s Hill', 'Sydney', 'NSW', '2042', 'Australia', '(02) 555-5914', '(02) 555-4873', 'G''day Mate (on the World Wide Web)#http://www.microsoft.com/accessdev/sampleapps/gdaymate.htm#');" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Ma Maison', 'Jean-Guy Lauzon', 'Marketing Manager', '2960 Rue St. Laurent', 'Montréal', 'Québec', 'H1J 1C3', 'Canada', '(514) 555-9022',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Pasta Buttini s.r.l.', 'Giovanni Giudici', 'Order Administrator', 'Via dei Gelsomini,153', 'Salerno',NULL,'84100', 'Italy', '(089) 6547665', '(089) 6547667',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Escargots Nouveaux', 'Marie Delamare', 'Sales Manager', '22,rue H. Voiron', 'Montceau',NULL,'71300', 'France', '85.57.00.07',NULL,NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Gai pâturage', 'Eliane Noz', 'Sales Representative', 'Bat. B 3,rue des Alpes', 'Annecy',NULL,'74000', 'France', '38.76.98.06', '38.76.98.58',NULL);" +
                "INSERT INTO Suppliers(CompanyName,ContactName,ContactTitle,Address,City,Region,PostalCode,Country,Phone,Fax,HomePage) VALUES('Forêts d''érables', 'Chantal Goulet', 'Accounting Manager', '148 rue Chasseur', 'Ste-Hyacinthe', 'Québec', 'J2S 7S8', 'Canada', '(514) 555-2955', '(514) 555-2921',NULL);" ;
            cmd.ExecuteNonQuery();
        }

        static private void LoadCategories(TdCommand cmd)
        {
            cmd.CommandText =
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Beverages', 'Soft drinks,coffees,teas,beers,and ales', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Condiments', 'Sweet and savory sauces,relishes,spreads,and seasonings', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Confections', 'Desserts,candies,and sweet breads', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Dairy Products', 'Cheeses', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Grains/Cereals', 'Breads,crackers,pasta,and cereal', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Meat/Poultry', 'Prepared meats', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Produce', 'Dried fruit and bean curd', NULL); " +
                "INSERT INTO Categories(CategoryName,Description,Picture) VALUES('Seafood', 'Seaweed and fish', NULL); ";
            cmd.ExecuteNonQuery();
        }

        static private void LoadProducts(TdCommand cmd)
        {
            cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chai',1,1,'10 boxes x 20 bags',18,39,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chang',1,1,'24 - 12 oz bottles',19,17,40,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Aniseed Syrup',1,2,'12 - 550 ml bottles',10,13,70,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chef Anton''s Cajun Seasoning',2,2,'48 - 6 oz jars',22,53,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chef Anton''s Gumbo Mix',2,2,'36 boxes',21.35,0,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Grandma''s Boysenberry Spread',3,2,'12 - 8 oz jars',25,120,0,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Uncle Bob''s Organic Dried Pears',3,7,'12 - 1 lb pkgs.',30,15,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Northwoods Cranberry Sauce',3,2,'12 - 12 oz jars',40,6,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Mishi Kobe Niku',4,6,'18 - 500 g pkgs.',97,29,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Ikura',4,8,'12 - 200 ml jars',31,31,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Queso Cabrales',5,4,'1 kg pkg.',21,22,30,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Queso Manchego La Pastora',5,4,'10 - 500 g pkgs.',38,86,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Konbu',6,8,'2 kg box',6,24,0,5,0,NULL); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Tofu',6,7,'40 - 100 g pkgs.',23.25,35,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Genen Shouyu',6,2,'24 - 250 ml bottles',15.5,39,0,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Pavlova',7,3,'32 - 500 g boxes',17.45,29,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Alice Mutton',7,6,'20 - 1 kg tins',39,0,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Carnarvon Tigers',7,8,'16 kg pkg.',62.5,42,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Teatime Chocolate Biscuits',8,3,'10 boxes x 12 pieces',9.2,25,0,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Sir Rodney''s Marmalade',8,3,'30 gift boxes',81,40,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Sir Rodney''s Scones',8,3,'24 pkgs. x 4 pieces',10,3,40,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gustaf''s Knäckebröd',9,5,'24 - 500 g pkgs.',21,104,0,25,0,NULL); ";
            cmd.ExecuteNonQuery();

               cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Tunnbröd',9,5,'12 - 250 g pkgs.',9,61,0,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Guaraná Fantástica',10,1,'12 - 355 ml cans',4.5,20,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('NuNuCa Nuß-Nougat-Creme',11,3,'20 - 450 g glasses',14,76,0,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gumbär Gummibärchen',11,3,'100 - 250 g bags',31.23,15,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Schoggi Schokolade',11,3,'100 - 100 g pieces',43.9,49,0,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Rössle Sauerkraut',12,7,'25 - 825 g cans',45.6,26,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Thüringer Rostbratwurst',12,6,'50 bags x 30 sausgs.',123.79,0,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Nord-Ost Matjeshering',13,8,'10 - 200 g glasses',25.89,10,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gorgonzola Telino',14,4,'12 - 100 g pkgs',12.5,0,70,20,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Mascarpone Fabioli',14,4,'24 - 200 g pkgs.',32,9,40,25,0,NULL); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Geitost',15,4,'500 g',2.5,112,0,20,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Sasquatch Ale',16,1,'24 - 12 oz bottles',14,111,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Steeleye Stout',16,1,'24 - 12 oz bottles',18,20,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Inlagd Sill',17,8,'24 - 250 g jars',19,112,0,20,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gravad lax',17,8,'12 - 500 g pkgs.',26,11,50,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Côte de Blaye',18,1,'12 - 75 cl bottles',263.5,17,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chartreuse verte',18,1,'750 cc per bottle',18,69,0,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Boston Crab Meat',19,8,'24 - 4 oz tins',18.4,123,0,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Jack''s New England Clam Chowder',19,8,'12 - 12 oz cans',9.65,85,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Singaporean Hokkien Fried Mee',20,5,'32 - 1 kg pkgs.',14,26,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Ipoh Coffee',20,1,'16 - 500 g tins',46,17,10,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gula Malacca',20,2,'20 - 2 kg bags',19.45,27,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Rogede sild',21,8,'1k pkg.',9.5,5,70,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Spegesild',21,8,'4 - 450 g glasses',12,95,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Zaanse koeken',22,3,'10 - 4 oz boxes',9.5,36,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Chocolade',22,3,'10 pkgs.',12.75,15,70,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Maxilaku',23,3,'24 - 50 g pkgs.',20,10,60,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Valkoinen suklaa',23,3,'12 - 100 g bars',16.25,65,0,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Manjimup Dried Apples',24,7,'50 - 300 g pkgs.',53,20,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Filo Mix',24,5,'16 - 2 kg boxes',7,38,0,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Perth Pasties',24,6,'48 pieces',32.8,0,0,0,1, TIMESTAMP '1996-07-04 00:00:00.000'); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Tourtière',25,6,'16 pies',7.45,21,0,10,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Pâté chinois',25,6,'24 boxes x 2 pies',24,115,0,20,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gnocchi di nonna Alice',26,5,'24 - 250 g pkgs.',38,21,10,30,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Ravioli Angelo',26,5,'24 - 250 g pkgs.',19.5,36,0,20,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Escargots de Bourgogne',27,8,'24 pieces',13.25,62,0,20,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Raclette Courdavault',28,4,'5 kg pkg.',55,79,0,0,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Camembert Pierrot',28,4,'15 - 300 g rounds',34,19,0,0,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Sirop d''érable',29,2,'24 - 500 ml bottles',28.5,113,0,25,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Tarte au sucre',29,3,'48 pies',49.3,17,0,0,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Vegie-spread',7,2,'15 - 625 g jars',43.9,24,0,5,0,NULL); " +
                   "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Wimmers gute Semmelknödel',12,5,'20 bags x 4 pieces',33.25,22,80,30,0,NULL); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Louisiana Fiery Hot Pepper Sauce',2,2,'32 - 8 oz bottles',21.05,76,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Louisiana Hot Spiced Okra',2,2,'24 - 8 oz jars',17,4,100,20,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Laughing Lumberjack Lager',16,1,'24 - 12 oz bottles',14,52,0,10,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Scottish Longbreads',8,3,'10 boxes x 8 pieces',12.5,6,10,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Gudbrandsdalsost',15,4,'10 kg pkg.',36,26,0,15,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Outback Lager',7,1,'24 - 355 ml bottles',15,15,10,30,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Flotemysost',15,4,'10 - 500 g pkgs.',21.5,26,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Mozzarella di Giovanni',14,4,'24 - 200 g pkgs.',34.8,14,0,0,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Röd Kaviar',17,8,'24 - 150 g jars',15,101,0,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Longlife Tofu',4,7,'5 kg pkg.',10,4,20,5,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Rhönbräu Klosterbier',12,1,'24 - 0.5 l bottles',7.75,125,0,25,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Lakkalikööri',23,1,'500 ml',18,57,0,20,0,NULL); " +
                    "INSERT INTO Products(ProductName,SupplierID,CategoryID,QuantityPerUnit,UnitPrice,UnitsInStock,UnitsOnOrder,ReorderLevel,Discontinued, DiscontinuedDate) VALUES ('Original Frankfurter grüne Soße',12,2,'12 boxes',13,32,0,15,0,NULL); ";
            cmd.ExecuteNonQuery();

        }

        static private void LoadInternationalOrders(TdCommand cmd)
        {
            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10318, 'Lakkalikööri and other products for personal use', 109.8305); " +
                    "INSERT INTO InternationalOrders Values (10461, 'Sir Rodney''s Scones and other products for personal use', 937.3054); " +
                    "INSERT INTO InternationalOrders Values (10930, 'Sir Rodney''s Scones and other products for personal use', 1121.6050); " +
                    "INSERT INTO InternationalOrders Values (10522, 'Northwoods Cranberry Sauce and other products for personal use', 1214.2573); " +
                    "INSERT INTO InternationalOrders Values (10583, 'Thüringer Rostbratwurst and other products for personal use', 1102.8278); " +
                    "INSERT INTO InternationalOrders Values (10257, 'Schoggi Schokolade and other products for personal use', 511.6438); " +
                    "INSERT INTO InternationalOrders Values (10848, 'Mishi Kobe Niku and other products for personal use', 425.5703); " +
                    "INSERT INTO InternationalOrders Values (10379, 'Vegie-spread and other products for personal use', 438.2255); " +
                    "INSERT INTO InternationalOrders Values (10726, 'Queso Cabrales and other products for personal use', 299.2470); " +
                    "INSERT INTO InternationalOrders Values (10623, 'Tofu and other products for personal use', 653.2036); " +
                    "INSERT INTO InternationalOrders Values (10991, 'Outback Lager and other products for personal use', 1311.2042); " +
                    "INSERT INTO InternationalOrders Values (11052, 'Sirop d''érable and other products for personal use', 760.6812); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10909, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 306.0999); " +
                    "INSERT INTO InternationalOrders Values (10501, 'Tourtière and other products for personal use', 68.0730); " +
                    "INSERT INTO InternationalOrders Values (10644, 'Spegesild and other products for personal use', 649.6629); " +
                    "INSERT INTO InternationalOrders Values (10724, 'Sirop d''érable and other products for personal use', 291.7087); " +
                    "INSERT INTO InternationalOrders Values (10888, 'Scottish Longbreads and other products for personal use', 276.4037); " +
                    "INSERT INTO InternationalOrders Values (10787, 'Thüringer Rostbratwurst and other products for personal use', 1261.3145); " +
                    "INSERT INTO InternationalOrders Values (10827, 'Ikura and other products for personal use', 385.1377); " +
                    "INSERT INTO InternationalOrders Values (10705, 'Mascarpone Fabioli and other products for personal use', 172.6952); " +
                    "INSERT INTO InternationalOrders Values (10297, 'Mozzarella di Giovanni and other products for personal use', 648.7491); " +
                    "INSERT INTO InternationalOrders Values (10970, 'Filo Mix and other products for personal use', 127.9224); " +
                    "INSERT INTO InternationalOrders Values (10438, 'Teatime Chocolate Biscuits and other products for personal use', 259.2712); " +
                    "INSERT INTO InternationalOrders Values (10480, 'Zaanse koeken and other products for personal use', 345.3904); " +
                    "INSERT INTO InternationalOrders Values (10562, 'Tarte au sucre and other products for personal use', 248.0780); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10663, 'Singaporean Hokkien Fried Mee and other products for personal use', 928.3509); " +
                   "INSERT INTO InternationalOrders Values (10745, 'Raclette Courdavault and other products for personal use', 2069.5097); " +
                   "INSERT INTO InternationalOrders Values (10766, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1055.3595); " +
                   "INSERT INTO InternationalOrders Values (10358, 'Sasquatch Ale and other products for personal use', 206.5032); " +
                   "INSERT INTO InternationalOrders Values (10764, 'Chartreuse verte and other products for personal use', 1160.4386); " +
                   "INSERT INTO InternationalOrders Values (10337, 'Tunnbröd and other products for personal use', 1127.0874); " +
                   "INSERT INTO InternationalOrders Values (10602, 'Original Frankfurter grüne Soße and other products for personal use', 29.6963); " +
                   "INSERT INTO InternationalOrders Values (10459, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 771.1891); " +
                   "INSERT INTO InternationalOrders Values (11010, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 294.6783); " +
                   "INSERT INTO InternationalOrders Values (10419, 'Gudbrandsdalsost and other products for personal use', 1008.7592); " +
                   "INSERT INTO InternationalOrders Values (10684, 'Zaanse koeken and other products for personal use', 807.7383); " +
                   "INSERT INTO InternationalOrders Values (11029, 'Vegie-spread and other products for personal use', 587.8946); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10377, 'Rössle Sauerkraut and other products for personal use', 464.1754); " +
                    "INSERT INTO InternationalOrders Values (11071, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 233.0014); " +
                    "INSERT INTO InternationalOrders Values (10255, 'Raclette Courdavault and other products for personal use', 1137.8237); " +
                    "INSERT INTO InternationalOrders Values (10928, 'Zaanse koeken and other products for personal use', 62.8190); " +
                    "INSERT INTO InternationalOrders Values (10276, 'Konbu and other products for personal use', 191.8835); " +
                    "INSERT INTO InternationalOrders Values (10949, 'Tarte au sucre and other products for personal use', 2020.2596); " +
                    "INSERT INTO InternationalOrders Values (10621, 'Tunnbröd and other products for personal use', 346.5325); " +
                    "INSERT INTO InternationalOrders Values (10703, 'Röd Kaviar and other products for personal use', 1162.7229); " +
                    "INSERT INTO InternationalOrders Values (10499, 'Rössle Sauerkraut and other products for personal use', 645.0942); " +
                    "INSERT INTO InternationalOrders Values (10520, 'Perth Pasties and other products for personal use', 91.3731); " +
                    "INSERT INTO InternationalOrders Values (10907, 'Rhönbräu Klosterbier and other products for personal use', 49.5699); " +
                    "INSERT INTO InternationalOrders Values (10581, 'Rhönbräu Klosterbier and other products for personal use', 177.0354); " +
                    "INSERT INTO InternationalOrders Values (10541, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 988.1089); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10457, 'Raclette Courdavault and other products for personal use', 723.6751); " +
                    "INSERT INTO InternationalOrders Values (10968, 'Wimmers gute Semmelknödel and other products for personal use', 643.2667); " +
                    "INSERT INTO InternationalOrders Values (10417, 'Spegesild and other products for personal use', 5154.9057); " +
                    "INSERT INTO InternationalOrders Values (10785, 'Rhönbräu Klosterbier and other products for personal use', 177.0354); " +
                    "INSERT INTO InternationalOrders Values (10560, 'Tarte au sucre and other products for personal use', 574.4171); " +
                    "INSERT INTO InternationalOrders Values (11050, 'Lakkalikööri and other products for personal use', 411.1790); " +
                    "INSERT INTO InternationalOrders Values (10806, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 261.3728); " +
                    "INSERT INTO InternationalOrders Values (10436, 'Wimmers gute Semmelknödel and other products for personal use', 1010.0384); " +
                    "INSERT INTO InternationalOrders Values (10295, 'Gnocchi di nonna Alice and other products for personal use', 55.5549); " +
                    "INSERT INTO InternationalOrders Values (10478, 'Ikura and other products for personal use', 226.6053); " +
                    "INSERT INTO InternationalOrders Values (10682, 'Rhönbräu Klosterbier and other products for personal use', 171.5530); " +
                    "INSERT INTO InternationalOrders Values (10356, 'Pâté chinois and other products for personal use', 505.4761); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10642, 'Sirop d''érable and other products for personal use', 397.4731); " +
                    "INSERT INTO InternationalOrders Values (10989, 'Queso Cabrales and other products for personal use', 618.4132); " +
                    "INSERT INTO InternationalOrders Values (10293, 'Vegie-spread and other products for personal use', 387.7418); " +
                    "INSERT INTO InternationalOrders Values (11008, 'Sasquatch Ale and other products for personal use', 2240.2404); " +
                    "INSERT INTO InternationalOrders Values (10743, 'Spegesild and other products for personal use', 153.5068); " +
                    "INSERT INTO InternationalOrders Values (10947, 'Raclette Courdavault and other products for personal use', 100.5104); " +
                    "INSERT INTO InternationalOrders Values (10825, 'Perth Pasties and other products for personal use', 470.9188); " +
                    "INSERT INTO InternationalOrders Values (10274, 'Mozzarella di Giovanni and other products for personal use', 246.0678); " +
                    "INSERT INTO InternationalOrders Values (10846, 'Outback Lager and other products for personal use', 508.0345); " +
                    "INSERT INTO InternationalOrders Values (10476, 'Pâté chinois and other products for personal use', 83.3323); " +
                    "INSERT INTO InternationalOrders Values (10926, 'Teatime Chocolate Biscuits and other products for personal use', 235.0117); " +
                    "INSERT INTO InternationalOrders Values (10539, 'Sir Rodney''s Scones and other products for personal use', 162.4157); " +
                    "INSERT INTO InternationalOrders Values (11069, 'Chartreuse verte and other products for personal use', 164.4716); " +
                    "INSERT INTO InternationalOrders Values (10886, 'Original Frankfurter grüne Soße and other products for personal use', 1428.8471); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10335, 'Mascarpone Fabioli and other products for personal use', 1162.8143); " +
                    "INSERT INTO InternationalOrders Values (10396, 'Tunnbröd and other products for personal use', 869.7807); " +
                    "INSERT INTO InternationalOrders Values (10741, 'Chang and other products for personal use', 130.2067); " +
                    "INSERT INTO InternationalOrders Values (10354, 'Thüringer Rostbratwurst and other products for personal use', 259.8651); " +
                    "INSERT INTO InternationalOrders Values (10865, 'Côte de Blaye and other products for personal use', 7880.9312); " +
                    "INSERT INTO InternationalOrders Values (10537, 'Röd Kaviar and other products for personal use', 833.2314); " +
                    "INSERT INTO InternationalOrders Values (10253, 'Maxilaku and other products for personal use', 660.0794); " +
                    "INSERT INTO InternationalOrders Values (10804, 'Rössle Sauerkraut and other products for personal use', 1046.4049); " +
                    "INSERT INTO InternationalOrders Values (10661, 'Escargots de Bourgogne and other products for personal use', 321.2907); " +
                    "INSERT INTO InternationalOrders Values (10333, 'Tofu and other products for personal use', 435.8498); " +
                    "INSERT INTO InternationalOrders Values (10823, 'Ravioli Angelo and other products for personal use', 1419.7098); " +
                    "INSERT INTO InternationalOrders Values (10783, 'Gorgonzola Telino and other products for personal use', 659.0286); " +
                    "INSERT INTO InternationalOrders Values (10373, 'Flotemysost and other products for personal use', 780.3264); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10518, 'Gula Malacca and other products for personal use', 1896.0150); " +
                    "INSERT INTO InternationalOrders Values (10291, 'Manjimup Dried Apples and other products for personal use', 252.5553); " +
                    "INSERT INTO InternationalOrders Values (10987, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1266.4314); " +
                    "INSERT INTO InternationalOrders Values (10802, 'Tarte au sucre and other products for personal use', 1792.6263); " +
                    "INSERT INTO InternationalOrders Values (10863, 'Escargots de Bourgogne and other products for personal use', 237.1132); " +
                    "INSERT INTO InternationalOrders Values (11048, 'Scottish Longbreads and other products for personal use', 239.8544); " +
                    "INSERT INTO InternationalOrders Values (10434, 'Queso Cabrales and other products for personal use', 164.4716); " +
                    "INSERT INTO InternationalOrders Values (10497, 'Original Frankfurter grüne Soße and other products for personal use', 630.7486); " +
                    "INSERT INTO InternationalOrders Values (10760, 'Schoggi Schokolade and other products for personal use', 1509.4839); " +
                    "INSERT INTO InternationalOrders Values (10844, 'Gustaf''s Knäckebröd and other products for personal use', 335.7962); " +
                    "INSERT INTO InternationalOrders Values (11067, 'Jack''s New England Clam Chowder and other products for personal use', 39.6788); " +
                    "INSERT INTO InternationalOrders Values (10720, 'Steeleye Stout and other products for personal use', 251.2761); " +
                    "INSERT INTO InternationalOrders Values (10640, 'Outback Lager and other products for personal use', 431.7380); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10699, 'Zaanse koeken and other products for personal use', 52.0827); " +
                    "INSERT INTO InternationalOrders Values (10762, 'Zaanse koeken and other products for personal use', 1981.4260); " +
                    "INSERT INTO InternationalOrders Values (10556, 'Mozzarella di Giovanni and other products for personal use', 381.5741); " +
                    "INSERT INTO InternationalOrders Values (10701, 'Raclette Courdavault and other products for personal use', 1539.6370); " +
                    "INSERT INTO InternationalOrders Values (10781, 'Tourtière and other products for personal use', 517.3317); " +
                    "INSERT INTO InternationalOrders Values (10985, 'Pavlova and other products for personal use', 1027.1252); " +
                    "INSERT INTO InternationalOrders Values (10905, 'Chai and other products for personal use', 164.4716); " +
                    "INSERT INTO InternationalOrders Values (10964, 'Gudbrandsdalsost and other products for personal use', 937.7166); " +
                    "INSERT INTO InternationalOrders Values (11027, 'Tarte au sucre and other products for personal use', 534.6698); " +
                    "INSERT INTO InternationalOrders Values (11025, 'Konbu and other products for personal use', 137.0597); " +
                    "INSERT INTO InternationalOrders Values (10966, 'Tarte au sucre and other products for personal use', 573.6404); " +
                    "INSERT INTO InternationalOrders Values (10474, 'Tofu and other products for personal use', 570.6708); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10312, 'Rössle Sauerkraut and other products for personal use', 737.7465); " +
                    "INSERT INTO InternationalOrders Values (10455, 'Sirop d''érable and other products for personal use', 1226.2272); " +
                    "INSERT INTO InternationalOrders Values (10352, 'Tourtière and other products for personal use', 70.3573); " +
                    "INSERT INTO InternationalOrders Values (10619, 'Sir Rodney''s Scones and other products for personal use', 575.6506); " +
                    "INSERT INTO InternationalOrders Values (10922, 'Guaraná Fantástica and other products for personal use', 339.2227); " +
                    "INSERT INTO InternationalOrders Values (10558, 'Zaanse koeken and other products for personal use', 979.0173); " +
                    "INSERT INTO InternationalOrders Values (10331, 'Tourtière and other products for personal use', 40.4326); " +
                    "INSERT INTO InternationalOrders Values (10943, 'Spegesild and other products for personal use', 324.8314); " +
                    "INSERT INTO InternationalOrders Values (10251, 'Ravioli Angelo and other products for personal use', 306.4654); " +
                    "INSERT INTO InternationalOrders Values (10779, 'Tarte au sucre and other products for personal use', 609.9155); " +
                    "INSERT INTO InternationalOrders Values (10945, 'Konbu and other products for personal use', 111.9321); " +
                    "INSERT INTO InternationalOrders Values (10840, 'NuNuCa Nuß-Nougat-Creme and other products for personal use', 120.6125); " +
                    "INSERT INTO InternationalOrders Values (10659, 'Outback Lager and other products for personal use', 590.0876); " +
                    "INSERT INTO InternationalOrders Values (10800, 'Tourtière and other products for personal use', 745.6732); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10392, 'Gudbrandsdalsost and other products for personal use', 657.8864); " +
                    "INSERT INTO InternationalOrders Values (10516, 'Singaporean Hokkien Fried Mee and other products for personal use', 1194.4751); " +
                    "INSERT INTO InternationalOrders Values (11044, 'Tarte au sucre and other products for personal use', 270.2817); " +
                    "INSERT INTO InternationalOrders Values (10924, 'Rössle Sauerkraut and other products for personal use', 929.4930); " +
                    "INSERT INTO InternationalOrders Values (10493, 'Louisiana Hot Spiced Okra and other products for personal use', 308.8411); " +
                    "INSERT INTO InternationalOrders Values (10413, 'Tarte au sucre and other products for personal use', 970.0170); " +
                    "INSERT INTO InternationalOrders Values (11065, 'Tourtière and other products for personal use', 115.3860); " +
                    "INSERT INTO InternationalOrders Values (10249, 'Tofu and other products for personal use', 851.3233); " +
                    "INSERT INTO InternationalOrders Values (11046, 'Steeleye Stout and other products for personal use', 714.5378); " +
                    "INSERT INTO InternationalOrders Values (10901, 'Jack''s New England Clam Chowder and other products for personal use', 426.9409); " +
                    "INSERT INTO InternationalOrders Values (10842, 'Scottish Longbreads and other products for personal use', 445.4439); " +
                    "INSERT INTO InternationalOrders Values (11063, 'Sasquatch Ale and other products for personal use', 660.3992); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10739, 'Inlagd Sill and other products for personal use', 109.6477); " +
                    "INSERT INTO InternationalOrders Values (10453, 'Outback Lager and other products for personal use', 206.9601); " +
                    "INSERT INTO InternationalOrders Values (10575, 'Vegie-spread and other products for personal use', 981.0731); " +
                    "INSERT INTO InternationalOrders Values (10495, 'Tunnbröd and other products for personal use', 127.0086); " +
                    "INSERT INTO InternationalOrders Values (10697, 'Teatime Chocolate Biscuits and other products for personal use', 490.6279); " +
                    "INSERT INTO InternationalOrders Values (10638, 'Rogede sild and other products for personal use', 1242.6972); " +
                    "INSERT INTO InternationalOrders Values (10512, 'Zaanse koeken and other products for personal use', 282.3429); " +
                    "INSERT INTO InternationalOrders Values (11004, 'Lakkalikööri and other products for personal use', 134.9490); " +
                    "INSERT INTO InternationalOrders Values (10962, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1637.4062); " +
                    "INSERT INTO InternationalOrders Values (11023, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 685.2984); " +
                    "INSERT INTO InternationalOrders Values (10758, 'Outback Lager and other products for personal use', 751.3611); " +
                    "INSERT INTO InternationalOrders Values (10289, 'Wimmers gute Semmelknödel and other products for personal use', 219.0214); " +
                    "INSERT INTO InternationalOrders Values (10903, 'Scottish Longbreads and other products for personal use', 425.8216); " +
                    "INSERT INTO InternationalOrders Values (10266, 'Queso Manchego La Pastora and other products for personal use', 166.6646); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10718, 'Tarte au sucre and other products for personal use', 1582.1255); " +
                    "INSERT INTO InternationalOrders Values (10819, 'Rhönbräu Klosterbier and other products for personal use', 217.9249); " +
                    "INSERT INTO InternationalOrders Values (10350, 'Valkoinen suklaa and other products for personal use', 325.9279); " +
                    "INSERT INTO InternationalOrders Values (10472, 'Manjimup Dried Apples and other products for personal use', 480.2571); " +
                    "INSERT INTO InternationalOrders Values (10554, 'Tunnbröd and other products for personal use', 831.2669); " +
                    "INSERT INTO InternationalOrders Values (10270, 'Ipoh Coffee and other products for personal use', 628.6470); " +
                    "INSERT INTO InternationalOrders Values (10918, 'Chai and other products for personal use', 881.7506); " +
                    "INSERT INTO InternationalOrders Values (10411, 'Raclette Courdavault and other products for personal use', 552.1221); " +
                    "INSERT INTO InternationalOrders Values (10777, 'Singaporean Hokkien Fried Mee and other products for personal use', 127.9224); " +
                    "INSERT INTO InternationalOrders Values (10615, 'Pâté chinois and other products for personal use', 54.8239); " +
                    "INSERT INTO InternationalOrders Values (10533, 'Röd Kaviar and other products for personal use', 1048.5979); " +
                    "INSERT INTO InternationalOrders Values (10390, 'Steeleye Stout and other products for personal use', 1039.4606); " +
                    "INSERT INTO InternationalOrders Values (10535, 'Ravioli Angelo and other products for personal use', 985.2306); " +
                    "INSERT INTO InternationalOrders Values (10571, 'Tofu and other products for personal use', 295.9347); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10268, 'Thüringer Rostbratwurst and other products for personal use', 503.1004); " +
                    "INSERT INTO InternationalOrders Values (10491, 'Original Frankfurter grüne Soße and other products for personal use', 139.4811); " +
                    "INSERT INTO InternationalOrders Values (10880, 'Tunnbröd and other products for personal use', 856.6230); " +
                    "INSERT INTO InternationalOrders Values (10798, 'Tarte au sucre and other products for personal use', 204.0362); " +
                    "INSERT INTO InternationalOrders Values (10451, 'Wimmers gute Semmelknödel and other products for personal use', 1954.1968); " +
                    "INSERT INTO InternationalOrders Values (10514, 'Sir Rodney''s Marmalade and other products for personal use', 3939.7575); " +
                    "INSERT INTO InternationalOrders Values (10958, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 356.8120); " +
                    "INSERT INTO InternationalOrders Values (10716, 'Sirop d''érable and other products for personal use', 322.5471); " +
                    "INSERT INTO InternationalOrders Values (10348, 'Tunnbröd and other products for personal use', 180.9188); " +
                    "INSERT INTO InternationalOrders Values (10695, 'Queso Manchego La Pastora and other products for personal use', 293.3077); " +
                    "INSERT INTO InternationalOrders Values (10960, 'Jack''s New England Clam Chowder and other products for personal use', 126.3690); " +
                    "INSERT INTO InternationalOrders Values (10981, 'Côte de Blaye and other products for personal use', 7223.0448); " +
                    "INSERT INTO InternationalOrders Values (10371, 'Inlagd Sill and other products for personal use', 41.6661); " +
                    "INSERT INTO InternationalOrders Values (10754, 'Boston Crab Meat and other products for personal use', 25.2190); " +
                    "INSERT INTO InternationalOrders Values (10308, 'Outback Lager and other products for personal use', 40.5697); " +
                    "INSERT INTO InternationalOrders Values (10817, 'Tarte au sucre and other products for personal use', 5249.7053); " +
                    "INSERT INTO InternationalOrders Values (10409, 'Tofu and other products for personal use', 145.8315); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10857, 'Thüringer Rostbratwurst and other products for personal use', 1201.9905); " +
                    "INSERT INTO InternationalOrders Values (10634, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 2277.7033); " +
                    "INSERT INTO InternationalOrders Values (10636, 'Escargots de Bourgogne and other products for personal use', 287.5969); " +
                    "INSERT INTO InternationalOrders Values (10550, 'Teatime Chocolate Biscuits and other products for personal use', 342.1923); " +
                    "INSERT INTO InternationalOrders Values (10573, 'Sasquatch Ale and other products for personal use', 951.1941); " +
                    "INSERT INTO InternationalOrders Values (10674, 'Tunnbröd and other products for personal use', 20.5590); " +
                    "INSERT INTO InternationalOrders Values (10878, 'Sir Rodney''s Marmalade and other products for personal use', 740.1222); " +
                    "INSERT INTO InternationalOrders Values (10632, 'Geitost and other products for personal use', 283.2567); " +
                    "INSERT INTO InternationalOrders Values (10531, 'Raclette Courdavault and other products for personal use', 50.2552); " +
                    "INSERT INTO InternationalOrders Values (10676, 'Teatime Chocolate Biscuits and other products for personal use', 244.3546); " +
                    "INSERT INTO InternationalOrders Values (10468, 'Nord-Ost Matjeshering and other products for personal use', 327.8467); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (11042, 'Sirop d''érable and other products for personal use', 185.3732); " +
                    "INSERT INTO InternationalOrders Values (10939, 'Laughing Lumberjack Lager and other products for personal use', 342.6492); " +
                    "INSERT INTO InternationalOrders Values (10470, 'Wimmers gute Semmelknödel and other products for personal use', 831.8608); " +
                    "INSERT INTO InternationalOrders Values (10897, 'Thüringer Rostbratwurst and other products for personal use', 4950.2482); " +
                    "INSERT INTO InternationalOrders Values (10327, 'Queso Cabrales and other products for personal use', 1033.6584); " +
                    "INSERT INTO InternationalOrders Values (10737, 'Konbu and other products for personal use', 63.8698); " +
                    "INSERT INTO InternationalOrders Values (10916, 'Ravioli Angelo and other products for personal use', 313.7296); " +
                    "INSERT INTO InternationalOrders Values (10430, 'Sir Rodney''s Scones and other products for personal use', 2647.9929); " +
                    "INSERT INTO InternationalOrders Values (10979, 'Vegie-spread and other products for personal use', 2199.1225); " +
                    "INSERT INTO InternationalOrders Values (10592, 'Gumbär Gummibärchen and other products for personal use', 248.3750); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10937, 'Sasquatch Ale and other products for personal use', 294.5869); " +
                    "INSERT INTO InternationalOrders Values (10796, 'Wimmers gute Semmelknödel and other products for personal use', 1314.8957); " +
                    "INSERT INTO InternationalOrders Values (10859, 'Wimmers gute Semmelknödel and other products for personal use', 657.0869); " +
                    "INSERT INTO InternationalOrders Values (10712, 'Perth Pasties and other products for personal use', 565.7823); " +
                    "INSERT INTO InternationalOrders Values (11021, 'Sir Rodney''s Marmalade and other products for personal use', 3171.3279); " +
                    "INSERT INTO InternationalOrders Values (10836, 'Wimmers gute Semmelknödel and other products for personal use', 2149.7810); " +
                    "INSERT INTO InternationalOrders Values (10653, 'Pavlova and other products for personal use', 549.8377); " +
                    "INSERT INTO InternationalOrders Values (10977, 'Zaanse koeken and other products for personal use', 1020.1808); " +
                    "INSERT INTO InternationalOrders Values (10306, 'Tourtière and other products for personal use', 227.7475); " +
                    "INSERT INTO InternationalOrders Values (10655, 'Jack''s New England Clam Chowder and other products for personal use', 88.1751); " +
                    "INSERT INTO InternationalOrders Values (11038, 'Flotemysost and other products for personal use', 343.1061); " +
                    "INSERT INTO InternationalOrders Values (10613, 'Rhönbräu Klosterbier and other products for personal use', 163.5579); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10264, 'Jack''s New England Clam Chowder and other products for personal use', 330.9991); " +
                    "INSERT INTO InternationalOrders Values (10367, 'Tourtière and other products for personal use', 381.1173); " +
                    "INSERT INTO InternationalOrders Values (10283, 'Teatime Chocolate Biscuits and other products for personal use', 646.3734); " +
                    "INSERT INTO InternationalOrders Values (10611, 'Chang and other products for personal use', 369.1474); " +
                    "INSERT INTO InternationalOrders Values (10920, 'Valkoinen suklaa and other products for personal use', 178.1776); " +
                    "INSERT INTO InternationalOrders Values (10630, 'Pâté chinois and other products for personal use', 419.4026); " +
                    "INSERT INTO InternationalOrders Values (10449, 'Tarte au sucre and other products for personal use', 839.8103); " +
                    "INSERT INTO InternationalOrders Values (10529, 'Scottish Longbreads and other products for personal use', 432.1948); " +
                    "INSERT INTO InternationalOrders Values (10590, 'Original Frankfurter grüne Soße and other products for personal use', 520.8268); " +
                    "INSERT INTO InternationalOrders Values (10609, 'Sir Rodney''s Scones and other products for personal use', 193.7110); " +
                    "INSERT INTO InternationalOrders Values (10876, 'Wimmers gute Semmelknödel and other products for personal use', 418.9457); " +
                    "INSERT INTO InternationalOrders Values (10838, 'Inlagd Sill and other products for personal use', 1180.7691); " +
                    "INSERT INTO InternationalOrders Values (10691, 'Thüringer Rostbratwurst and other products for personal use', 4643.9472); " +
                    "INSERT INTO InternationalOrders Values (10428, 'Spegesild and other products for personal use', 87.7182); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10794, 'Tourtière and other products for personal use', 179.7538); " +
                    "INSERT INTO InternationalOrders Values (10447, 'Teatime Chocolate Biscuits and other products for personal use', 417.7579); " +
                    "INSERT INTO InternationalOrders Values (10527, 'Inlagd Sill and other products for personal use', 762.9655); " +
                    "INSERT INTO InternationalOrders Values (10998, 'Sirop d''érable and other products for personal use', 313.4098); " +
                    "INSERT INTO InternationalOrders Values (10899, 'Chartreuse verte and other products for personal use', 65.7886); " +
                    "INSERT INTO InternationalOrders Values (10384, 'Sir Rodney''s Marmalade and other products for personal use', 1015.3381); " +
                    "INSERT INTO InternationalOrders Values (10285, 'Perth Pasties and other products for personal use', 995.6015); " +
                    "INSERT INTO InternationalOrders Values (10508, 'Konbu and other products for personal use', 109.6477); " +
                    "INSERT INTO InternationalOrders Values (10895, 'Guaraná Fantástica and other products for personal use', 2914.5283); " +
                    "INSERT INTO InternationalOrders Values (10649, 'Rössle Sauerkraut and other products for personal use', 655.1452); " +
                    "INSERT INTO InternationalOrders Values (10426, 'Wimmers gute Semmelknödel and other products for personal use', 154.5119); " +
                    "INSERT INTO InternationalOrders Values (10287, 'Spegesild and other products for personal use', 422.1438); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10853, 'Carnarvon Tigers and other products for personal use', 285.5410); " +
                    "INSERT INTO InternationalOrders Values (10733, 'Tofu and other products for personal use', 666.5669); " +
                    "INSERT INTO InternationalOrders Values (10834, 'Thüringer Rostbratwurst and other products for personal use', 689.0081); " +
                    "INSERT INTO InternationalOrders Values (10487, 'Tourtière and other products for personal use', 422.6463); " +
                    "INSERT INTO InternationalOrders Values (10914, 'Flotemysost and other products for personal use', 245.5652); " +
                    "INSERT INTO InternationalOrders Values (10548, 'Sasquatch Ale and other products for personal use', 125.6837); " +
                    "INSERT INTO InternationalOrders Values (10552, 'Rhönbräu Klosterbier and other products for personal use', 402.2701); " +
                    "INSERT INTO InternationalOrders Values (10302, 'Rössle Sauerkraut and other products for personal use', 1237.5575); " +
                    "INSERT INTO InternationalOrders Values (10325, 'Tofu and other products for personal use', 683.9278); " +
                    "INSERT INTO InternationalOrders Values (10956, 'Zaanse koeken and other products for personal use', 309.2980); " +
                    "INSERT INTO InternationalOrders Values (10752, 'Gudbrandsdalsost and other products for personal use', 115.1301); " +
                    "INSERT INTO InternationalOrders Values (10975, 'Rhönbräu Klosterbier and other products for personal use', 327.8011); " +
                    "INSERT INTO InternationalOrders Values (10935, 'Tunnbröd and other products for personal use', 319.8059); " +
                    "INSERT INTO InternationalOrders Values (10388, 'Rogede sild and other products for personal use', 582.0467); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (11036, 'Raclette Courdavault and other products for personal use', 773.0166); " +
                    "INSERT INTO InternationalOrders Values (11059, 'Konbu and other products for personal use', 839.7189); " +
                    "INSERT INTO InternationalOrders Values (10874, 'Ikura and other products for personal use', 141.6283); " +
                    "INSERT INTO InternationalOrders Values (10405, 'Aniseed Syrup and other products for personal use', 182.7462); " +
                    "INSERT INTO InternationalOrders Values (10912, 'Thüringer Rostbratwurst and other products for personal use', 3777.0905); " +
                    "INSERT INTO InternationalOrders Values (10771, 'Flotemysost and other products for personal use', 157.1618); " +
                    "INSERT INTO InternationalOrders Values (10489, 'Queso Cabrales and other products for personal use', 229.4379); " +
                    "INSERT INTO InternationalOrders Values (10628, 'Chai and other products for personal use', 205.5895); " +
                    "INSERT INTO InternationalOrders Values (10773, 'Rhönbräu Klosterbier and other products for personal use', 1012.5283); " +
                    "INSERT INTO InternationalOrders Values (10281, 'Teatime Chocolate Biscuits and other products for personal use', 39.5189); " +
                    "INSERT INTO InternationalOrders Values (10670, 'Tunnbröd and other products for personal use', 1051.5903); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10361, 'Chartreuse verte and other products for personal use', 1038.7296); " +
                    "INSERT INTO InternationalOrders Values (10567, 'Raclette Courdavault and other products for personal use', 1420.3951); " +
                    "INSERT INTO InternationalOrders Values (11019, 'Spegesild and other products for personal use', 34.7218); " +
                    "INSERT INTO InternationalOrders Values (10689, 'Chai and other products for personal use', 287.8253); " +
                    "INSERT INTO InternationalOrders Values (10466, 'Spegesild and other products for personal use', 98.6830); " +
                    "INSERT INTO InternationalOrders Values (10546, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1284.7060); " +
                    "INSERT INTO InternationalOrders Values (10996, 'Singaporean Hokkien Fried Mee and other products for personal use', 255.8447); " +
                    "INSERT INTO InternationalOrders Values (10626, 'Perth Pasties and other products for personal use', 686.9431); " +
                    "INSERT INTO InternationalOrders Values (10832, 'Wimmers gute Semmelknödel and other products for personal use', 259.9337); " +
                    "INSERT INTO InternationalOrders Values (10407, 'Queso Cabrales and other products for personal use', 545.4975); " +
                    "INSERT INTO InternationalOrders Values (11015, 'Original Frankfurter grüne Soße and other products for personal use', 284.3303); " +
                    "INSERT INTO InternationalOrders Values (10731, 'Sir Rodney''s Scones and other products for personal use', 909.1625); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10872, 'Wimmers gute Semmelknödel and other products for personal use', 989.9363); " +
                    "INSERT INTO InternationalOrders Values (10710, 'Zaanse koeken and other products for personal use', 42.7169); " +
                    "INSERT INTO InternationalOrders Values (10605, 'Raclette Courdavault and other products for personal use', 1976.4005); " +
                    "INSERT INTO InternationalOrders Values (10893, 'Thüringer Rostbratwurst and other products for personal use', 2513.7247); " +
                    "INSERT INTO InternationalOrders Values (10672, 'Flotemysost and other products for personal use', 1923.6325); " +
                    "INSERT INTO InternationalOrders Values (10525, 'Inlagd Sill and other products for personal use', 386.5083); " +
                    "INSERT INTO InternationalOrders Values (10323, 'NuNuCa Nuß-Nougat-Creme and other products for personal use', 75.1087); " +
                    "INSERT INTO InternationalOrders Values (10260, 'Tarte au sucre and other products for personal use', 797.7787); " +
                    "INSERT INTO InternationalOrders Values (10750, 'Tofu and other products for personal use', 854.9097); " +
                    "INSERT INTO InternationalOrders Values (10870, 'Steeleye Stout and other products for personal use', 73.0985); " +
                    "INSERT INTO InternationalOrders Values (10973, 'Rhönbräu Klosterbier and other products for personal use', 133.1992); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10386, 'Sasquatch Ale and other products for personal use', 75.8397); " +
                    "INSERT INTO InternationalOrders Values (10994, 'Raclette Courdavault and other products for personal use', 452.2969); " +
                    "INSERT INTO InternationalOrders Values (10792, 'Tourtière and other products for personal use', 182.6777); " +
                    "INSERT INTO InternationalOrders Values (10729, 'Valkoinen suklaa and other products for personal use', 845.2013); " +
                    "INSERT INTO InternationalOrders Values (10342, 'Pâté chinois and other products for personal use', 1051.1563); " +
                    "INSERT INTO InternationalOrders Values (10727, 'Raclette Courdavault and other products for personal use', 781.2401); " +
                    "INSERT INTO InternationalOrders Values (10952, 'Rössle Sauerkraut and other products for personal use', 224.4124); " +
                    "INSERT INTO InternationalOrders Values (10651, 'Teatime Chocolate Biscuits and other products for personal use', 242.3215); " +
                    "INSERT INTO InternationalOrders Values (10586, 'Filo Mix and other products for personal use', 12.7922); " +
                    "INSERT INTO InternationalOrders Values (10588, 'Singaporean Hokkien Fried Mee and other products for personal use', 1781.7758); " +
                    "INSERT INTO InternationalOrders Values (10851, 'Ravioli Angelo and other products for personal use', 1251.8117); " +
                    "INSERT INTO InternationalOrders Values (10464, 'Ipoh Coffee and other products for personal use', 844.2876); " +
                    "INSERT INTO InternationalOrders Values (10277, 'Tarte au sucre and other products for personal use', 548.6042); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10258, 'Mascarpone Fabioli and other products for personal use', 922.2289); " +
                    "INSERT INTO InternationalOrders Values (10304, 'Raclette Courdavault and other products for personal use', 436.0325); " +
                    "INSERT INTO InternationalOrders Values (10830, 'Scottish Longbreads and other products for personal use', 901.8527); " +
                    "INSERT INTO InternationalOrders Values (11057, 'Outback Lager and other products for personal use', 20.5590); " +
                    "INSERT INTO InternationalOrders Values (10443, 'Rössle Sauerkraut and other products for personal use', 245.610); " +
                    "INSERT INTO InternationalOrders Values (10790, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 388.3357); " +
                    "INSERT INTO InternationalOrders Values (10868, 'Steeleye Stout and other products for personal use', 915.8327); " +
                    "INSERT INTO InternationalOrders Values (10788, 'Teatime Chocolate Biscuits and other products for personal use', 351.7865); " +
                    "INSERT INTO InternationalOrders Values (10365, 'Queso Cabrales and other products for personal use', 184.2082); " +
                    "INSERT INTO InternationalOrders Values (10687, 'Thüringer Rostbratwurst and other products for personal use', 2833.4346); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10445, 'Tourtière and other products for personal use', 79.9058); " +
                    "INSERT INTO InternationalOrders Values (10891, 'Nord-Ost Matjeshering and other products for personal use', 177.4237); " +
                    "INSERT INTO InternationalOrders Values (11055, 'Ravioli Angelo and other products for personal use', 789.2353); " +
                    "INSERT INTO InternationalOrders Values (10664, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 692.4940); " +
                    "INSERT INTO InternationalOrders Values (10380, 'Perth Pasties and other products for personal use', 648.6578); " +
                    "INSERT INTO InternationalOrders Values (11017, 'Raclette Courdavault and other products for personal use', 3083.8427); " +
                    "INSERT INTO InternationalOrders Values (10809, 'Filo Mix and other products for personal use', 63.9612); " +
                    "INSERT INTO InternationalOrders Values (10485, 'Pâté chinois and other products for personal use', 804.0834); " +
                    "INSERT INTO InternationalOrders Values (10279, 'Alice Mutton and other products for personal use', 213.8131); " +
                    "INSERT INTO InternationalOrders Values (10647, 'Teatime Chocolate Biscuits and other products for personal use', 290.5665); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                 "INSERT INTO InternationalOrders Values (10929, 'Sir Rodney''s Scones and other products for personal use', 536.7028); " +
                    "INSERT INTO InternationalOrders Values (10849, 'Gumbär Gummibärchen and other products for personal use', 480.6866); " +
                    "INSERT INTO InternationalOrders Values (10813, 'Spegesild and other products for personal use', 296.0489); " +
                    "INSERT INTO InternationalOrders Values (10666, 'Thüringer Rostbratwurst and other products for personal use', 2132.1642); " +
                    "INSERT INTO InternationalOrders Values (10954, 'Rogede sild and other products for personal use', 869.0040); " +
                    "INSERT INTO InternationalOrders Values (10910, 'Teatime Chocolate Biscuits and other products for personal use', 206.9144); " +
                    "INSERT INTO InternationalOrders Values (10422, 'Gumbär Gummibärchen and other products for personal use', 22.7519); " +
                    "INSERT INTO InternationalOrders Values (10439, 'Wimmers gute Semmelknödel and other products for personal use', 492.5011); " +
                    "INSERT INTO InternationalOrders Values (10645, 'Inlagd Sill and other products for personal use', 701.2887); " +
                    "INSERT INTO InternationalOrders Values (10506, 'Outback Lager and other products for personal use', 211.0719); " +
                    "INSERT INTO InternationalOrders Values (10523, 'Sir Rodney''s Marmalade and other products for personal use', 1240.8012); " +
                    "INSERT INTO InternationalOrders Values (10811, 'Tunnbröd and other products for personal use', 389.2495); " +
                    "INSERT INTO InternationalOrders Values (10298, 'Tarte au sucre and other products for personal use', 1428.6187); " +
                    "INSERT INTO InternationalOrders Values (11013, 'Tunnbröd and other products for personal use', 164.9285); " +
                    "INSERT INTO InternationalOrders Values (10908, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 318.8922); " +
                    "INSERT INTO InternationalOrders Values (11072, 'Wimmers gute Semmelknödel and other products for personal use', 2383.9246); " +
                    "INSERT INTO InternationalOrders Values (10363, 'Rhönbräu Klosterbier and other products for personal use', 204.3103); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10584, 'Gorgonzola Telino and other products for personal use', 285.5410); " +
                    "INSERT INTO InternationalOrders Values (11076, 'Tofu and other products for personal use', 482.9069); " +
                    "INSERT INTO InternationalOrders Values (10563, 'Inlagd Sill and other products for personal use', 440.8753); " +
                    "INSERT INTO InternationalOrders Values (10462, 'Tunnbröd and other products for personal use', 71.2710); " +
                    "INSERT INTO InternationalOrders Values (10704, 'Guaraná Fantástica and other products for personal use', 272.0635); " +
                    "INSERT INTO InternationalOrders Values (10460, 'Scottish Longbreads and other products for personal use', 107.2720); " +
                    "INSERT INTO InternationalOrders Values (10424, 'Steeleye Stout and other products for personal use', 5250.8475); " +
                    "INSERT INTO InternationalOrders Values (10971, 'Thüringer Rostbratwurst and other products for personal use', 791.7755); " +
                    "INSERT INTO InternationalOrders Values (10769, 'Tarte au sucre and other products for personal use', 778.4989); " +
                    "INSERT INTO InternationalOrders Values (10746, 'Tarte au sucre and other products for personal use', 1056.1362); " +
                    "INSERT INTO InternationalOrders Values (10319, 'Rössle Sauerkraut and other products for personal use', 544.2183); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10744, 'Boston Crab Meat and other products for personal use', 420.3163); " +
                    "INSERT INTO InternationalOrders Values (10969, 'Spegesild and other products for personal use', 49.3415); " +
                    "INSERT INTO InternationalOrders Values (10403, 'Pavlova and other products for personal use', 459.5611); " +
                    "INSERT INTO InternationalOrders Values (10420, 'Röd Kaviar and other products for personal use', 866.9481); " +
                    "INSERT INTO InternationalOrders Values (10340, 'Jack''s New England Clam Chowder and other products for personal use', 1171.5861); " +
                    "INSERT INTO InternationalOrders Values (11011, 'Flotemysost and other products for personal use', 438.5910); " +
                    "INSERT INTO InternationalOrders Values (10502, 'Rogede sild and other products for personal use', 372.9394); " +
                    "INSERT INTO InternationalOrders Values (10336, 'Chef Anton''s Cajun Seasoning and other products for personal use', 144.7350); " +
                    "INSERT INTO InternationalOrders Values (10275, 'Raclette Courdavault and other products for personal use', 140.3491); " +
                    "INSERT INTO InternationalOrders Values (10668, 'Wimmers gute Semmelknödel and other products for personal use', 317.4074); " +
                    "INSERT INTO InternationalOrders Values (10685, 'Zaanse koeken and other products for personal use', 365.9950); " +
                    "INSERT INTO InternationalOrders Values (11074, 'Pavlova and other products for personal use', 111.6123); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10256, 'Perth Pasties and other products for personal use', 236.5650); " +
                    "INSERT INTO InternationalOrders Values (10767, 'Singaporean Hokkien Fried Mee and other products for personal use', 12.7922); " +
                    "INSERT INTO InternationalOrders Values (10580, 'Tofu and other products for personal use', 487.5213); " +
                    "INSERT INTO InternationalOrders Values (10540, 'Scottish Longbreads and other products for personal use', 4656.2369); " +
                    "INSERT INTO InternationalOrders Values (10933, 'Sirop d''érable and other products for personal use', 420.5905); " +
                    "INSERT INTO InternationalOrders Values (10725, 'Pâté chinois and other products for personal use', 131.4859); " +
                    "INSERT INTO InternationalOrders Values (10931, 'Ravioli Angelo and other products for personal use', 382.3965); " +
                    "INSERT INTO InternationalOrders Values (10561, 'Manjimup Dried Apples and other products for personal use', 1299.5541); " +
                    "INSERT INTO InternationalOrders Values (10359, 'Pavlova and other products for personal use', 1669.5696); " +
                    "INSERT INTO InternationalOrders Values (10376, 'Gorgonzola Telino and other products for personal use', 191.8835); " +
                    "INSERT INTO InternationalOrders Values (10397, 'Sir Rodney''s Scones and other products for personal use', 385.2291); " +
                    "INSERT INTO InternationalOrders Values (10321, 'Steeleye Stout and other products for personal use', 65.7886); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (11051, 'Guaraná Fantástica and other products for personal use', 20.5590); " +
                    "INSERT INTO InternationalOrders Values (10828, 'Sir Rodney''s Marmalade and other products for personal use', 425.7987); " +
                    "INSERT INTO InternationalOrders Values (10418, 'Zaanse koeken and other products for personal use', 829.1197); " +
                    "INSERT INTO InternationalOrders Values (10542, 'Tourtière and other products for personal use', 225.6002); " +
                    "INSERT INTO InternationalOrders Values (10641, 'Chang and other products for personal use', 938.4019); " +
                    "INSERT INTO InternationalOrders Values (10559, 'Pâté chinois and other products for personal use', 250.2710); " +
                    "INSERT INTO InternationalOrders Values (10382, 'Thüringer Rostbratwurst and other products for personal use', 1324.9102); " +
                    "INSERT INTO InternationalOrders Values (10378, 'Flotemysost and other products for personal use', 47.1485); " +
                    "INSERT INTO InternationalOrders Values (10521, 'Steeleye Stout and other products for personal use', 103.0232); " +
                    "INSERT INTO InternationalOrders Values (10601, 'Raclette Courdavault and other products for personal use', 1043.9378); " +
                    "INSERT INTO InternationalOrders Values (10807, 'Boston Crab Meat and other products for personal use', 8.4063); " +
                    "INSERT INTO InternationalOrders Values (10620, 'Guaraná Fantástica and other products for personal use', 26.2698); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10355, 'Ravioli Angelo and other products for personal use', 219.2955); " +
                    "INSERT INTO InternationalOrders Values (10300, 'Scottish Longbreads and other products for personal use', 277.7743); " +
                    "INSERT INTO InternationalOrders Values (10296, 'Queso Cabrales and other products for personal use', 479.9830); " +
                    "INSERT INTO InternationalOrders Values (10786, 'Rhönbräu Klosterbier and other products for personal use', 874.3722); " +
                    "INSERT INTO InternationalOrders Values (10866, 'Nord-Ost Matjeshering and other products for personal use', 667.7547); " +
                    "INSERT INTO InternationalOrders Values (10990, 'Sirop d''érable and other products for personal use', 2252.8042); " +
                    "INSERT INTO InternationalOrders Values (10416, 'Teatime Chocolate Biscuits and other products for personal use', 328.9432); " +
                    "INSERT INTO InternationalOrders Values (10824, 'Outback Lager and other products for personal use', 114.5819); " +
                    "INSERT INTO InternationalOrders Values (10565, 'Wimmers gute Semmelknödel and other products for personal use', 324.8314); " +
                    "INSERT INTO InternationalOrders Values (10458, 'Rössle Sauerkraut and other products for personal use', 1777.6640); " +
                    "INSERT INTO InternationalOrders Values (10500, 'Rössle Sauerkraut and other products for personal use', 251.6416); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10315, 'Sasquatch Ale and other products for personal use', 236.1081); " +
                    "INSERT INTO InternationalOrders Values (10765, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 769.3616); " +
                    "INSERT INTO InternationalOrders Values (10885, 'Outback Lager and other products for personal use', 552.3505); " +
                    "INSERT INTO InternationalOrders Values (10477, 'Sir Rodney''s Scones and other products for personal use', 307.0137); " +
                    "INSERT INTO InternationalOrders Values (11053, 'Wimmers gute Semmelknödel and other products for personal use', 1671.5569); " +
                    "INSERT INTO InternationalOrders Values (10927, 'Sir Rodney''s Marmalade and other products for personal use', 365.4925); " +
                    "INSERT INTO InternationalOrders Values (10826, 'Ravioli Angelo and other products for personal use', 333.5119); " +
                    "INSERT INTO InternationalOrders Values (10906, 'Sirop d''érable and other products for personal use', 195.3100); " +
                    "INSERT INTO InternationalOrders Values (10357, 'Ikura and other products for personal use', 621.3372); " +
                    "INSERT INTO InternationalOrders Values (11007, 'Thüringer Rostbratwurst and other products for personal use', 1203.3383); " +
                    "INSERT INTO InternationalOrders Values (10946, 'Original Frankfurter grüne Soße and other products for personal use', 643.0383); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10481, 'Maxilaku and other products for personal use', 672.5061); " +
                    "INSERT INTO InternationalOrders Values (10519, 'Ikura and other products for personal use', 1076.3753); " +
                    "INSERT INTO InternationalOrders Values (10683, 'Filo Mix and other products for personal use', 28.7825); " +
                    "INSERT INTO InternationalOrders Values (10334, 'Scottish Longbreads and other products for personal use', 66.1541); " +
                    "INSERT INTO InternationalOrders Values (10254, 'Pâté chinois and other products for personal use', 285.6324); " +
                    "INSERT INTO InternationalOrders Values (10456, 'Sir Rodney''s Scones and other products for personal use', 299.7038); " +
                    "INSERT INTO InternationalOrders Values (10742, 'Mozzarella di Giovanni and other products for personal use', 1424.5069); " +
                    "INSERT INTO InternationalOrders Values (10950, 'Chef Anton''s Cajun Seasoning and other products for personal use', 50.2552); " +
                    "INSERT INTO InternationalOrders Values (10599, 'Tarte au sucre and other products for personal use', 225.2347); " +
                    "INSERT INTO InternationalOrders Values (10948, 'Valkoinen suklaa and other products for personal use', 1079.2307); " +
                    "INSERT INTO InternationalOrders Values (10313, 'Inlagd Sill and other products for personal use', 83.3323); " +
                    "INSERT INTO InternationalOrders Values (10845, 'Wimmers gute Semmelknödel and other products for personal use', 1854.4174); ";
            cmd.ExecuteNonQuery();

               cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10925, 'Inlagd Sill and other products for personal use', 255.3879); " +
                    "INSERT INTO InternationalOrders Values (10557, 'Wimmers gute Semmelknödel and other products for personal use', 526.5376); " +
                    "INSERT INTO InternationalOrders Values (10399, 'Scottish Longbreads and other products for personal use', 806.6419); " +
                    "INSERT INTO InternationalOrders Values (10252, 'Sir Rodney''s Marmalade and other products for personal use', 1704.1086); " +
                    "INSERT INTO InternationalOrders Values (10273, 'Lakkalikööri and other products for personal use', 978.7888); " +
                    "INSERT INTO InternationalOrders Values (10435, 'Mozzarella di Giovanni and other products for personal use', 288.5563); " +
                    "INSERT INTO InternationalOrders Values (10437, 'Perth Pasties and other products for personal use', 179.5482); " +
                    "INSERT INTO InternationalOrders Values (10782, 'Gorgonzola Telino and other products for personal use', 5.7108); " +
                    "INSERT INTO InternationalOrders Values (11026, 'Manjimup Dried Apples and other products for personal use', 470.5715); " +
                    "INSERT INTO InternationalOrders Values (10582, 'Ravioli Angelo and other products for personal use', 150.7656); " +
                    "INSERT INTO InternationalOrders Values (10292, 'Sir Rodney''s Marmalade and other products for personal use', 592.0978); " +
                    "INSERT INTO InternationalOrders Values (10538, 'Outback Lager and other products for personal use', 63.8698); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10353, 'Queso Cabrales and other products for personal use', 4907.4673); " +
                    "INSERT INTO InternationalOrders Values (11068, 'Rössle Sauerkraut and other products for personal use', 1089.5330); " +
                    "INSERT INTO InternationalOrders Values (11047, 'Chef Anton''s Gumbo Mix and other products for personal use', 498.2119); " +
                    "INSERT INTO InternationalOrders Values (10414, 'Teatime Chocolate Biscuits and other products for personal use', 105.7187); " +
                    "INSERT INTO InternationalOrders Values (10643, 'Spegesild and other products for personal use', 496.1560); " +
                    "INSERT INTO InternationalOrders Values (10637, 'Valkoinen suklaa and other products for personal use', 1323.1969); " +
                    "INSERT INTO InternationalOrders Values (10803, 'Teatime Chocolate Biscuits and other products for personal use', 573.7318); " +
                    "INSERT INTO InternationalOrders Values (10618, 'Scottish Longbreads and other products for personal use', 1232.3949); " +
                    "INSERT INTO InternationalOrders Values (10517, 'Raclette Courdavault and other products for personal use', 160.8167); " +
                    "INSERT INTO InternationalOrders Values (10332, 'Zaanse koeken and other products for personal use', 1020.4550); " +
                    "INSERT INTO InternationalOrders Values (10679, 'Raclette Courdavault and other products for personal use', 301.5313); " +
                    "INSERT INTO InternationalOrders Values (10622, 'Scottish Longbreads and other products for personal use', 276.4037); ";
            cmd.ExecuteNonQuery();

               cmd.CommandText =
                 "INSERT INTO InternationalOrders Values (10433, 'Gnocchi di nonna Alice and other products for personal use', 388.8840); " +
                    "INSERT INTO InternationalOrders Values (10864, 'Steeleye Stout and other products for personal use', 128.8361); " +
                    "INSERT INTO InternationalOrders Values (10944, 'Queso Cabrales and other products for personal use', 520.4156); " +
                    "INSERT INTO InternationalOrders Values (10374, 'Gorgonzola Telino and other products for personal use', 209.7013); " +
                    "INSERT INTO InternationalOrders Values (10597, 'Ravioli Angelo and other products for personal use', 365.5382); " +
                    "INSERT INTO InternationalOrders Values (10250, 'Manjimup Dried Apples and other products for personal use', 828.2973); " +
                    "INSERT INTO InternationalOrders Values (10887, 'NuNuCa Nuß-Nougat-Creme and other products for personal use', 31.9806); " +
                    "INSERT INTO InternationalOrders Values (10902, 'Tarte au sucre and other products for personal use', 464.0841); " +
                    "INSERT INTO InternationalOrders Values (10721, 'Gula Malacca and other products for personal use', 444.3018); " +
                    "INSERT INTO InternationalOrders Values (10658, 'Sir Rodney''s Scones and other products for personal use', 2132.6485); " +
                    "INSERT INTO InternationalOrders Values (10475, 'Louisiana Hot Spiced Okra and other products for personal use', 809.0176); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10454, 'Spegesild and other products for personal use', 189.1423); " +
                    "INSERT INTO InternationalOrders Values (10311, 'Singaporean Hokkien Fried Mee and other products for personal use', 122.8055); " +
                    "INSERT INTO InternationalOrders Values (11009, 'Inlagd Sill and other products for personal use', 320.7196); " +
                    "INSERT INTO InternationalOrders Values (10799, 'Raclette Courdavault and other products for personal use', 724.1319); " +
                    "INSERT INTO InternationalOrders Values (10986, 'Sir Rodney''s Marmalade and other products for personal use', 1014.2416); " +
                    "INSERT INTO InternationalOrders Values (10351, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 2593.9000); " +
                    "INSERT INTO InternationalOrders Values (11005, 'Raclette Courdavault and other products for personal use', 267.7232); " +
                    "INSERT INTO InternationalOrders Values (10923, 'Singaporean Hokkien Fried Mee and other products for personal use', 427.6262); " +
                    "INSERT INTO InternationalOrders Values (10576, 'Gula Malacca and other products for personal use', 383.0589); " +
                    "INSERT INTO InternationalOrders Values (11070, 'Pavlova and other products for personal use', 855.9377); " +
                    "INSERT INTO InternationalOrders Values (10717, 'Tourtière and other products for personal use', 608.4307); " +
                    "INSERT INTO InternationalOrders Values (10578, 'Steeleye Stout and other products for personal use', 217.9249); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10473, 'Geitost and other products for personal use', 105.2618); " +
                    "INSERT INTO InternationalOrders Values (10862, 'Queso Cabrales and other products for personal use', 265.4389); " +
                    "INSERT INTO InternationalOrders Values (11024, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 898.5678); " +
                    "INSERT INTO InternationalOrders Values (10372, 'Sir Rodney''s Marmalade and other products for personal use', 5610.8576); " +
                    "INSERT INTO InternationalOrders Values (10784, 'Mozzarella di Giovanni and other products for personal use', 753.8282); " +
                    "INSERT INTO InternationalOrders Values (10370, 'Wimmers gute Semmelknödel and other products for personal use', 536.3602); " +
                    "INSERT INTO InternationalOrders Values (10843, 'Manjimup Dried Apples and other products for personal use', 96.8555); " +
                    "INSERT INTO InternationalOrders Values (10942, 'Maxilaku and other products for personal use', 255.8447); " +
                    "INSERT INTO InternationalOrders Values (10534, 'Tourtière and other products for personal use', 236.3823); " +
                    "INSERT INTO InternationalOrders Values (10391, 'Konbu and other products for personal use', 39.4732); " +
                    "INSERT INTO InternationalOrders Values (10841, 'Raclette Courdavault and other products for personal use', 2092.9012); " +
                    "INSERT INTO InternationalOrders Values (11049, 'Queso Manchego La Pastora and other products for personal use', 156.2480); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10471, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 606.7175); " +
                    "INSERT INTO InternationalOrders Values (10536, 'Queso Manchego La Pastora and other products for personal use', 952.5647); " +
                    "INSERT INTO InternationalOrders Values (10330, 'Mozzarella di Giovanni and other products for personal use', 886.3192); " +
                    "INSERT INTO InternationalOrders Values (10860, 'Manjimup Dried Apples and other products for personal use', 237.1132); " +
                    "INSERT INTO InternationalOrders Values (10635, 'Gustaf''s Knäckebröd and other products for personal use', 630.5887); " +
                    "INSERT INTO InternationalOrders Values (10494, 'Gnocchi di nonna Alice and other products for personal use', 416.6614); " +
                    "INSERT INTO InternationalOrders Values (10702, 'Lakkalikööri and other products for personal use', 150.7656); " +
                    "INSERT INTO InternationalOrders Values (10940, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 164.4716); " +
                    "INSERT INTO InternationalOrders Values (10698, 'Thüringer Rostbratwurst and other products for personal use', 1645.0496); " +
                    "INSERT INTO InternationalOrders Values (10961, 'Lakkalikööri and other products for personal use', 512.6032); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10982, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 463.2617); " +
                    "INSERT INTO InternationalOrders Values (11022, 'Teatime Chocolate Biscuits and other products for personal use', 640.5255); " +
                    "INSERT INTO InternationalOrders Values (10759, 'Mascarpone Fabioli and other products for personal use', 146.1970); " +
                    "INSERT INTO InternationalOrders Values (10498, 'Singaporean Hokkien Fried Mee and other products for personal use', 262.6977); " +
                    "INSERT INTO InternationalOrders Values (10389, 'Tarte au sucre and other products for personal use', 837.3432); " +
                    "INSERT INTO InternationalOrders Values (10290, 'Thüringer Rostbratwurst and other products for personal use', 990.9414); " +
                    "INSERT INTO InternationalOrders Values (10654, 'Tourtière and other products for personal use', 305.5060); " +
                    "INSERT INTO InternationalOrders Values (10900, 'Outback Lager and other products for personal use', 20.5590); " +
                    "INSERT INTO InternationalOrders Values (10675, 'Tofu and other products for personal use', 650.1197); " +
                    "INSERT INTO InternationalOrders Values (10921, 'Vegie-spread and other products for personal use', 884.4918); " +
                    "INSERT INTO InternationalOrders Values (10967, 'Teatime Chocolate Biscuits and other products for personal use', 415.9304); " +
                    "INSERT INTO InternationalOrders Values (10858, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 296.5058); ";
           cmd.ExecuteNonQuery();

           cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10881, 'Röd Kaviar and other products for personal use', 68.5298); " +
                   "INSERT INTO InternationalOrders Values (10368, 'Wimmers gute Semmelknödel and other products for personal use', 837.9828); " +
                   "INSERT INTO InternationalOrders Values (10492, 'Singaporean Hokkien Fried Mee and other products for personal use', 409.3516); " +
                   "INSERT INTO InternationalOrders Values (11062, 'Perth Pasties and other products for personal use', 232.0877); " +
                   "INSERT INTO InternationalOrders Values (11043, 'Queso Cabrales and other products for personal use', 95.9418); " +
                   "INSERT INTO InternationalOrders Values (10763, 'Sir Rodney''s Scones and other products for personal use', 281.4292); " +
                   "INSERT INTO InternationalOrders Values (11020, 'Ikura and other products for personal use', 339.9080); " +
                   "INSERT INTO InternationalOrders Values (10738, 'Pavlova and other products for personal use', 23.9169); " +
                   "INSERT INTO InternationalOrders Values (10633, 'Tarte au sucre and other products for personal use', 2961.8824); " +
                   "INSERT INTO InternationalOrders Values (10818, 'Mascarpone Fabioli and other products for personal use', 380.5690); " +
                   "INSERT INTO InternationalOrders Values (10837, 'Zaanse koeken and other products for personal use', 572.9094); " +
                   "INSERT INTO InternationalOrders Values (10431, 'Zaanse koeken and other products for personal use', 1152.6719); ";
           cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (11028, 'Raclette Courdavault and other products for personal use', 986.8297); " +
                    "INSERT INTO InternationalOrders Values (10265, 'Outback Lager and other products for personal use', 537.2739); " +
                    "INSERT INTO InternationalOrders Values (10595, 'Steeleye Stout and other products for personal use', 2878.2532); " +
                    "INSERT INTO InternationalOrders Values (10694, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 2204.3764); " +
                    "INSERT INTO InternationalOrders Values (10572, 'Rhönbräu Klosterbier and other products for personal use', 715.2916); " +
                    "INSERT INTO InternationalOrders Values (10347, 'Rhönbräu Klosterbier and other products for personal use', 423.9713); " +
                    "INSERT INTO InternationalOrders Values (10267, 'Raclette Courdavault and other products for personal use', 1841.6252); " +
                    "INSERT INTO InternationalOrders Values (10395, 'Spegesild and other products for personal use', 1065.9588); " +
                    "INSERT INTO InternationalOrders Values (10448, 'Gumbär Gummibärchen and other products for personal use', 202.5742); " +
                    "INSERT INTO InternationalOrders Values (10248, 'Singaporean Hokkien Fried Mee and other products for personal use', 201.0209); " +
                    "INSERT INTO InternationalOrders Values (10490, 'Scottish Longbreads and other products for personal use', 1445.1572); " +
                    "INSERT INTO InternationalOrders Values (10286, 'Tarte au sucre and other products for personal use', 1377.9066); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10408, 'Tourtière and other products for personal use', 741.2187); " +
                    "INSERT INTO InternationalOrders Values (11001, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1265.0608); " +
                    "INSERT INTO InternationalOrders Values (10639, 'Carnarvon Tigers and other products for personal use', 228.4328); " +
                    "INSERT INTO InternationalOrders Values (10835, 'Raclette Courdavault and other products for personal use', 388.7926); " +
                    "INSERT INTO InternationalOrders Values (10839, 'Mozzarella di Giovanni and other products for personal use', 420.0879); " +
                    "INSERT INTO InternationalOrders Values (10959, 'Rhönbräu Klosterbier and other products for personal use', 70.8142); " +
                    "INSERT INTO InternationalOrders Values (10755, 'Zaanse koeken and other products for personal use', 1186.9368); " +
                    "INSERT INTO InternationalOrders Values (10734, 'Nord-Ost Matjeshering and other products for personal use', 684.5445); " +
                    "INSERT INTO InternationalOrders Values (10328, 'Scottish Longbreads and other products for personal use', 533.6190); " +
                    "INSERT INTO InternationalOrders Values (10496, 'Gorgonzola Telino and other products for personal use', 91.3731); " +
                    "INSERT INTO InternationalOrders Values (10631, 'Rhönbräu Klosterbier and other products for personal use', 28.3257); " +
                    "INSERT INTO InternationalOrders Values (10288, 'Tourtière and other products for personal use', 40.6610); " +
                    "INSERT INTO InternationalOrders Values (10551, 'Steeleye Stout and other products for personal use', 838.8052); " +
                    "INSERT INTO InternationalOrders Values (10877, 'Pavlova and other products for personal use', 953.0216); " +
                    "INSERT INTO InternationalOrders Values (10387, 'Rössle Sauerkraut and other products for personal use', 483.5465); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10511, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1370.5967); " +
                    "INSERT INTO InternationalOrders Values (10801, 'Thüringer Rostbratwurst and other products for personal use', 1843.8181); " +
                    "INSERT INTO InternationalOrders Values (10345, 'Teatime Chocolate Biscuits and other products for personal use', 1336.2404); " +
                    "INSERT INTO InternationalOrders Values (10553, 'Steeleye Stout and other products for personal use', 706.4512); " +
                    "INSERT INTO InternationalOrders Values (10999, 'Original Frankfurter grüne Soße and other products for personal use', 576.1075); " +
                    "INSERT INTO InternationalOrders Values (10530, 'Sirop d''érable and other products for personal use', 1909.6981); " +
                    "INSERT INTO InternationalOrders Values (10652, 'Singaporean Hokkien Fried Mee and other products for personal use', 151.5789); " +
                    "INSERT INTO InternationalOrders Values (10673, 'Singaporean Hokkien Fried Mee and other products for personal use', 188.3885); " +
                    "INSERT INTO InternationalOrders Values (10515, 'Schoggi Schokolade and other products for personal use', 4837.5212); " +
                    "INSERT INTO InternationalOrders Values (10793, 'Jack''s New England Clam Chowder and other products for personal use', 87.3070); " +
                    "INSERT INTO InternationalOrders Values (10410, 'Raclette Courdavault and other products for personal use', 366.4062); " +
                    "INSERT INTO InternationalOrders Values (10856, 'Singaporean Hokkien Fried Mee and other products for personal use', 301.5313); " +
                    "INSERT INTO InternationalOrders Values (10795, 'Pavlova and other products for personal use', 1141.8213); " +
                    "INSERT INTO InternationalOrders Values (10509, 'Rössle Sauerkraut and other products for personal use', 62.4992); " +
                    "INSERT INTO InternationalOrders Values (10938, 'Konbu and other products for personal use', 1664.1329); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10780, 'Outback Lager and other products for personal use', 328.9432); " +
                    "INSERT INTO InternationalOrders Values (10915, 'Tourtière and other products for personal use', 246.4790); " +
                    "INSERT INTO InternationalOrders Values (10593, 'Sir Rodney''s Marmalade and other products for personal use', 1138.9659); " +
                    "INSERT INTO InternationalOrders Values (10406, 'Sir Rodney''s Scones and other products for personal use', 922.0461); " +
                    "INSERT INTO InternationalOrders Values (10917, 'Nord-Ost Matjeshering and other products for personal use', 167.1625); " +
                    "INSERT INTO InternationalOrders Values (10978, 'Sir Rodney''s Scones and other products for personal use', 685.6182); " +
                    "INSERT INTO InternationalOrders Values (11060, 'Original Frankfurter grüne Soße and other products for personal use', 121.5262); " +
                    "INSERT INTO InternationalOrders Values (11045, 'Manjimup Dried Apples and other products for personal use', 598.2655); " +
                    "INSERT INTO InternationalOrders Values (10976, 'Rössle Sauerkraut and other products for personal use', 416.6614); " +
                    "INSERT INTO InternationalOrders Values (10450, 'Tourtière and other products for personal use', 242.7784); " +
                    "INSERT INTO InternationalOrders Values (10671, 'Tarte au sucre and other products for personal use', 420.3620); " +
                    "INSERT INTO InternationalOrders Values (10467, 'NuNuCa Nuß-Nougat-Creme and other products for personal use', 107.4548); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10774, 'Louisiana Hot Spiced Okra and other products for personal use', 399.7574); " +
                    "INSERT INTO InternationalOrders Values (10488, 'Röd Kaviar and other products for personal use', 712.7103); " +
                    "INSERT INTO InternationalOrders Values (10963, 'Camembert Pierrot and other products for personal use', 31.0669); " +
                    "INSERT INTO InternationalOrders Values (10568, 'Ikura and other products for personal use', 70.8142); " +
                    "INSERT INTO InternationalOrders Values (10919, 'Pavlova and other products for personal use', 512.9687); " +
                    "INSERT INTO InternationalOrders Values (10997, 'Spegesild and other products for personal use', 904.5938); " +
                    "INSERT INTO InternationalOrders Values (10732, 'Lakkalikööri and other products for personal use', 164.4716); " +
                    "INSERT INTO InternationalOrders Values (11039, 'Steeleye Stout and other products for personal use', 1411.7146); " +
                    "INSERT INTO InternationalOrders Values (10957, 'Wimmers gute Semmelknödel and other products for personal use', 805.3170); " +
                    "INSERT INTO InternationalOrders Values (10412, 'Tofu and other products for personal use', 169.9540); " +
                    "INSERT INTO InternationalOrders Values (10261, 'Steeleye Stout and other products for personal use', 204.6758); " +
                    "INSERT INTO InternationalOrders Values (10715, 'Ikura and other products for personal use', 592.0978); " +
                    "INSERT INTO InternationalOrders Values (10650, 'Tourtière and other products for personal use', 831.5867); " +
                    "INSERT INTO InternationalOrders Values (10772, 'Thüringer Rostbratwurst and other products for personal use', 1646.1872); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10692, 'Vegie-spread and other products for personal use', 401.1280); " +
                    "INSERT INTO InternationalOrders Values (10284, 'Schoggi Schokolade and other products for personal use', 663.3688); " +
                    "INSERT INTO InternationalOrders Values (10677, 'Gumbär Gummibärchen and other products for personal use', 437.1747); " +
                    "INSERT INTO InternationalOrders Values (10730, 'Pavlova and other products for personal use', 232.8872); " +
                    "INSERT INTO InternationalOrders Values (10898, 'Konbu and other products for personal use', 13.7060); " +
                    "INSERT INTO InternationalOrders Values (10833, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 460.3834); " +
                    "INSERT INTO InternationalOrders Values (11037, 'Outback Lager and other products for personal use', 27.4119); " +
                    "INSERT INTO InternationalOrders Values (10854, 'Konbu and other products for personal use', 1594.4609); " +
                    "INSERT INTO InternationalOrders Values (10753, 'Rogede sild and other products for personal use', 40.2042); " +
                    "INSERT INTO InternationalOrders Values (10513, 'Sirop d''érable and other products for personal use', 1109.0412); " +
                    "INSERT INTO InternationalOrders Values (11056, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 1708.6773); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10326, 'Rhönbräu Klosterbier and other products for personal use', 448.6420); " +
                    "INSERT INTO InternationalOrders Values (11016, 'Inlagd Sill and other products for personal use', 224.5494); " +
                    "INSERT INTO InternationalOrders Values (10629, 'Wimmers gute Semmelknödel and other products for personal use', 1267.8248); " +
                    "INSERT INTO InternationalOrders Values (10364, 'Gudbrandsdalsost and other products for personal use', 434.0223); " +
                    "INSERT INTO InternationalOrders Values (10303, 'Scottish Longbreads and other products for personal use', 567.4270); " +
                    "INSERT INTO InternationalOrders Values (10309, 'Singaporean Hokkien Fried Mee and other products for personal use', 804.9972); " +
                    "INSERT INTO InternationalOrders Values (10913, 'Geitost and other products for personal use', 438.0199); " +
                    "INSERT INTO InternationalOrders Values (10591, 'Uncle Bob''s Organic Dried Pears and other products for personal use', 371.2033); " +
                    "INSERT INTO InternationalOrders Values (10669, 'Inlagd Sill and other products for personal use', 260.4134); " +
                    "INSERT INTO InternationalOrders Values (10282, 'Ravioli Angelo and other products for personal use', 70.9969); " +
                    "INSERT INTO InternationalOrders Values (10486, 'Queso Cabrales and other products for personal use', 581.1330); " +
                    "INSERT INTO InternationalOrders Values (10425, 'Pâté chinois and other products for personal use', 219.2955); " +
                    "INSERT INTO InternationalOrders Values (10778, 'Jack''s New England Clam Chowder and other products for personal use', 44.0875); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10505, 'Tarte au sucre and other products for personal use', 67.5704); " +
                    "INSERT INTO InternationalOrders Values (10570, 'Queso Cabrales and other products for personal use', 1185.5662); " +
                    "INSERT INTO InternationalOrders Values (10831, 'Teatime Chocolate Biscuits and other products for personal use', 1226.4100); " +
                    "INSERT INTO InternationalOrders Values (10547, 'Mascarpone Fabioli and other products for personal use', 871.6995); " +
                    "INSERT INTO InternationalOrders Values (10751, 'Valkoinen suklaa and other products for personal use', 777.3385); " +
                    "INSERT INTO InternationalOrders Values (10648, 'Gustaf''s Knäckebröd and other products for personal use', 174.7511); " +
                    "INSERT INTO InternationalOrders Values (10614, 'Sir Rodney''s Scones and other products for personal use', 211.9856); " +
                    "INSERT INTO InternationalOrders Values (10566, 'Queso Cabrales and other products for personal use', 932.0058); " +
                    "INSERT INTO InternationalOrders Values (10427, 'Tofu and other products for personal use', 297.4195); " +
                    "INSERT INTO InternationalOrders Values (10423, 'Raclette Courdavault and other products for personal use', 466.0029); " +
                    "INSERT INTO InternationalOrders Values (10812, 'Original Frankfurter grüne Soße and other products for personal use', 846.1151); " +
                    "INSERT INTO InternationalOrders Values (10404, 'Singaporean Hokkien Fried Mee and other products for personal use', 765.2498); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10709, 'Northwoods Cranberry Sauce and other products for personal use', 1564.3077); " +
                    "INSERT INTO InternationalOrders Values (10879, 'Louisiana Fiery Hot Pepper Sauce and other products for personal use', 279.2819); " +
                    "INSERT INTO InternationalOrders Values (10892, 'Raclette Courdavault and other products for personal use', 1005.1043); " +
                    "INSERT INTO InternationalOrders Values (10610, 'Inlagd Sill and other products for personal use', 182.2894); " +
                    "INSERT INTO InternationalOrders Values (10688, 'Sasquatch Ale and other products for personal use', 1594.4609); " +
                    "INSERT INTO InternationalOrders Values (10873, 'Sir Rodney''s Scones and other products for personal use', 153.8723); " +
                    "INSERT INTO InternationalOrders Values (10526, 'Konbu and other products for personal use', 614.0273); " +
                    "INSERT INTO InternationalOrders Values (10301, 'Gnocchi di nonna Alice and other products for personal use', 344.9335); " +
                    "INSERT INTO InternationalOrders Values (10736, 'Rhönbräu Klosterbier and other products for personal use', 455.4950); " +
                    "INSERT INTO InternationalOrders Values (10484, 'Sir Rodney''s Scones and other products for personal use', 176.4415); " +
                    "INSERT INTO InternationalOrders Values (10875, 'Zaanse koeken and other products for personal use', 333.2834); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10728, 'Pâté chinois and other products for personal use', 592.4404); " +
                    "INSERT INTO InternationalOrders Values (10587, 'Steeleye Stout and other products for personal use', 368.8641); " +
                    "INSERT INTO InternationalOrders Values (10995, 'Manjimup Dried Apples and other products for personal use', 546.4112); " +
                    "INSERT INTO InternationalOrders Values (10770, 'Queso Cabrales and other products for personal use', 143.9127); " +
                    "INSERT INTO InternationalOrders Values (10532, 'Nord-Ost Matjeshering and other products for personal use', 363.8249); " +
                    "INSERT INTO InternationalOrders Values (11014, 'Jack''s New England Clam Chowder and other products for personal use', 123.4451); " +
                    "INSERT INTO InternationalOrders Values (10343, 'Wimmers gute Semmelknödel and other products for personal use', 724.5888); " +
                    "INSERT INTO InternationalOrders Values (10993, 'Thüringer Rostbratwurst and other products for personal use', 2982.0759); " +
                    "INSERT INTO InternationalOrders Values (10444, 'Steeleye Stout and other products for personal use', 471.3482); " +
                    "INSERT INTO InternationalOrders Values (10791, 'Thüringer Rostbratwurst and other products for personal use', 879.9505); " +
                    "INSERT INTO InternationalOrders Values (10585, 'Zaanse koeken and other products for personal use', 65.1033); ";
            cmd.ExecuteNonQuery();

              cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10797, 'Queso Cabrales and other products for personal use', 191.8835); " +
                    "INSERT INTO InternationalOrders Values (10606, 'Tarte au sucre and other products for personal use', 645.5511); " +
                    "INSERT INTO InternationalOrders Values (10608, 'Gnocchi di nonna Alice and other products for personal use', 486.1050); " +
                    "INSERT INTO InternationalOrders Values (10381, 'Longlife Tofu and other products for personal use', 51.1689); " +
                    "INSERT INTO InternationalOrders Values (10749, 'Raclette Courdavault and other products for personal use', 493.4148); " +
                    "INSERT INTO InternationalOrders Values (11035, 'Tourtière and other products for personal use', 801.5707); " +
                    "INSERT INTO InternationalOrders Values (10850, 'Outback Lager and other products for personal use', 338.0805); " +
                    "INSERT INTO InternationalOrders Values (10980, 'Rhönbräu Klosterbier and other products for personal use', 141.6283); " +
                    "INSERT INTO InternationalOrders Values (11075, 'Spegesild and other products for personal use', 267.7232); " +
                    "INSERT INTO InternationalOrders Values (10465, 'Valkoinen suklaa and other products for personal use', 1242.2175); " +
                    "INSERT INTO InternationalOrders Values (10421, 'Teatime Chocolate Biscuits and other products for personal use', 581.6813); ";
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10341, 'Raclette Courdavault and other products for personal use', 188.2286); " +
                    "INSERT INTO InternationalOrders Values (10789, 'Vegie-spread and other products for personal use', 1684.4634); " +
                    "INSERT INTO InternationalOrders Values (10972, 'Geitost and other products for personal use', 114.9017); " +
                    "INSERT INTO InternationalOrders Values (10776, 'Singaporean Hokkien Fried Mee and other products for personal use', 3190.9776); " +
                    "INSERT INTO InternationalOrders Values (10402, 'Vegie-spread and other products for personal use', 1239.7048); " +
                    "INSERT INTO InternationalOrders Values (10934, 'Grandma''s Boysenberry Spread and other products for personal use', 228.4328); " +
                    "INSERT INTO InternationalOrders Values (10667, 'Gudbrandsdalsost and other products for personal use', 877.6388); " +
                    "INSERT INTO InternationalOrders Values (11054, 'Laughing Lumberjack Lager and other products for personal use', 139.3440); " +
                    "INSERT INTO InternationalOrders Values (10829, 'Northwoods Cranberry Sauce and other products for personal use', 805.9109); " +
                    "INSERT INTO InternationalOrders Values (11041, 'Vegie-spread and other products for personal use', 862.1053); " +
                    "INSERT INTO InternationalOrders Values (10871, 'Pavlova and other products for personal use', 951.8337); " +
                    "INSERT INTO InternationalOrders Values (10322, 'Filo Mix and other products for personal use', 51.1689); ";
            cmd.ExecuteNonQuery();

             cmd.CommandText =
                   "INSERT INTO InternationalOrders Values (10932, 'Tarte au sucre and other products for personal use', 879.6947); " +
                    "INSERT INTO InternationalOrders Values (10503, 'Tofu and other products for personal use', 935.8891); " +
                    "INSERT INTO InternationalOrders Values (10400, 'Thüringer Rostbratwurst and other products for personal use', 1399.3793); " +
                    "INSERT INTO InternationalOrders Values (10429, 'Vegie-spread and other products for personal use', 798.8295); " +
                    "INSERT INTO InternationalOrders Values (10320, 'Flotemysost and other products for personal use', 235.7426); " +
                    "INSERT INTO InternationalOrders Values (10362, 'Tourtière and other products for personal use', 707.9589); " +
                    "INSERT INTO InternationalOrders Values (10524, 'Tourtière and other products for personal use', 1458.6119); " +
                    "INSERT INTO InternationalOrders Values (10278, 'Vegie-spread and other products for personal use', 680.1815); " +
                    "INSERT INTO InternationalOrders Values (10366, 'Original Frankfurter grüne Soße and other products for personal use', 62.1337); " +
                    "INSERT INTO InternationalOrders Values (10707, 'Ravioli Angelo and other products for personal use', 778.4989); " +
                    "INSERT INTO InternationalOrders Values (10953, 'Sir Rodney''s Marmalade and other products for personal use', 2135.8466); " +
                    "INSERT INTO InternationalOrders Values (10299, 'Teatime Chocolate Biscuits and other products for personal use', 159.6745); " ;
            cmd.ExecuteNonQuery();

            cmd.CommandText =
                    "INSERT INTO InternationalOrders Values (10747, 'Vegie-spread and other products for personal use', 873.9153); " +
                    "INSERT INTO InternationalOrders Values (10896, 'Rogede sild and other products for personal use', 342.8776); " +
                    "INSERT INTO InternationalOrders Values (10768, 'Gustaf''s Knäckebröd and other products for personal use', 674.7905); " +
                    "INSERT INTO InternationalOrders Values (10646, 'Original Frankfurter grüne Soße and other products for personal use', 880.8368); " +
                    "INSERT INTO InternationalOrders Values (10890, 'Sasquatch Ale and other products for personal use', 392.9501); " +
                    "INSERT INTO InternationalOrders Values (10604, 'Lakkalikööri and other products for personal use', 117.1860); " +
                    "INSERT INTO InternationalOrders Values (10549, 'Rogede sild and other products for personal use', 1910.3834); " +
                    "INSERT INTO InternationalOrders Values (11033, 'Perth Pasties and other products for personal use', 1641.0612); " +
                    "INSERT INTO InternationalOrders Values (10911, 'Laughing Lumberjack Lager and other products for personal use', 391.9907); " +
                    "INSERT INTO InternationalOrders Values (10339, 'Tarte au sucre and other products for personal use', 1582.2169); " +
                    "INSERT INTO InternationalOrders Values (10869, 'Tunnbröd and other products for personal use', 744.6909); " +
                    "INSERT INTO InternationalOrders Values (10814, 'Sirop d''érable and other products for personal use', 945.7117); " +
                    "INSERT INTO InternationalOrders Values (10686, 'Gumbär Gummibärchen and other products for personal use', 748.5514); " +
                    "INSERT INTO InternationalOrders Values (10360, 'Tourtière and other products for personal use', 3376.3280); " +
                    "INSERT INTO InternationalOrders Values (10263, 'Pavlova and other products for personal use', 1126.0823); ";
             cmd.ExecuteNonQuery();

            cmd.CommandText =
                  "INSERT INTO InternationalOrders Values (10543, 'Tunnbröd and other products for personal use', 808.6521); " +
                    "INSERT INTO InternationalOrders Values (10625, 'Tofu and other products for personal use', 219.1813); " +
                    "INSERT INTO InternationalOrders Values (11058, 'Sirop d''érable and other products for personal use', 391.9907); " +
                    "INSERT INTO InternationalOrders Values (10951, 'Rhönbräu Klosterbier and other products for personal use', 220.6204); " +
                    "INSERT INTO InternationalOrders Values (10446, 'Teatime Chocolate Biscuits and other products for personal use', 124.9984); " +
                    "INSERT INTO InternationalOrders Values (11073, 'Queso Cabrales and other products for personal use', 137.0597); " +
                    "INSERT INTO InternationalOrders Values (10507, 'Ipoh Coffee and other products for personal use', 402.6128); " +
                    "INSERT INTO InternationalOrders Values (10690, 'Original Frankfurter grüne Soße and other products for personal use', 525.3954); " +
                    "INSERT INTO InternationalOrders Values (10955, 'Rhönbräu Klosterbier and other products for personal use', 42.4885); " +
                    "INSERT INTO InternationalOrders Values (10383, 'Valkoinen suklaa and other products for personal use', 410.7222); " +
                    "INSERT INTO InternationalOrders Values (10280, 'Rhönbräu Klosterbier and other products for personal use', 280.1500); " +
                    "INSERT INTO InternationalOrders Values (10810, 'Outback Lager and other products for personal use', 85.4339); " +
                    "INSERT INTO InternationalOrders Values (10463, 'Teatime Chocolate Biscuits and other products for personal use', 325.8822); " +
                    "INSERT INTO InternationalOrders Values (10259, 'Sir Rodney''s Scones and other products for personal use', 46.0521); " +
                    "INSERT INTO InternationalOrders Values (10442, 'Tourtière and other products for personal use', 818.7031); " +
                    "INSERT INTO InternationalOrders Values (11012, 'Teatime Chocolate Biscuits and other products for personal use', 1358.7182); ";
            cmd.ExecuteNonQuery();
        }
    }
}
